"use client";

import React from "react";
import { Calendar, Plus, CalendarDays, MoreVertical, Edit2 } from "lucide-react";

export default function CalendarPage() {
  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
         <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center">
               <Calendar className="w-5 h-5" />
            </div>
            <div>
               <h3 className="text-xl font-black text-slate-800">Academic Calendar</h3>
               <p className="text-sm font-medium text-slate-500">Define the academic year, terms, and standard holidays.</p>
            </div>
         </div>
         <button className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-xl text-sm font-bold shadow-sm hover:bg-slate-700 transition-colors">
            <Plus className="w-4 h-4" /> New Academic Year
         </button>
      </div>

      <div className="space-y-10">
         {/* Active Academic Year */}
         <div>
            <div className="flex items-center gap-3 mb-4">
               <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider">Active Year: 2026/2027</h4>
               <span className="bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded">Current</span>
            </div>

            <div className="bg-white border border-slate-200 rounded-3xl shadow-sm overflow-hidden">
               <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-slate-100">
                  {[
                     { name: "Term 1", dates: "Sep 2, 2026 - Dec 13, 2026", status: "Active", bg: "bg-emerald-50", color: "text-emerald-600" },
                     { name: "Term 2", dates: "Jan 6, 2027 - Apr 4, 2027", status: "Upcoming", bg: "bg-slate-50", color: "text-slate-500" },
                     { name: "Term 3", dates: "Apr 28, 2027 - Jul 11, 2027", status: "Upcoming", bg: "bg-slate-50", color: "text-slate-500" },
                  ].map((term, i) => (
                     <div key={i} className="p-6 relative group hover:bg-slate-50/50 transition-colors">
                        <div className="flex justify-between items-start mb-4">
                           <div className={`px-2 py-1 rounded-md text-[10px] font-black uppercase tracking-wider ${term.bg} ${term.color}`}>
                              {term.status}
                           </div>
                           <button className="text-slate-400 hover:text-slate-700 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Edit2 className="w-4 h-4" />
                           </button>
                        </div>
                        <h5 className="text-xl font-black text-slate-800 mb-1">{term.name}</h5>
                        <p className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
                           <CalendarDays className="w-3.5 h-3.5 text-slate-400" /> {term.dates}
                        </p>
                     </div>
                  ))}
               </div>
            </div>
         </div>

         {/* Holidays & Events */}
         <div>
            <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-2">
               <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider">Standard Holidays</h4>
               <button className="text-xs font-bold text-violet-600 hover:text-violet-800 flex items-center gap-1 transition-colors">
                  <Plus className="w-3 h-3" /> Add Holiday
               </button>
            </div>
            
            <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
               <table className="w-full text-left border-collapse">
                  <thead>
                     <tr className="bg-slate-50 border-b border-slate-100">
                        <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Date</th>
                        <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Holiday Name</th>
                        <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Type</th>
                        <th className="p-4 w-10"></th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                     {[
                        { date: "Oct 20, 2026", name: "Mashujaa Day", type: "National Holiday" },
                        { date: "Dec 12, 2026", name: "Jamhuri Day", type: "National Holiday" },
                        { date: "Dec 25, 2026", name: "Christmas Day", type: "Public Holiday" },
                        { date: "Feb 15, 2027", name: "Mid-Term Break", type: "School Holiday" },
                     ].map((holiday, i) => (
                        <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                           <td className="p-4 text-sm font-bold text-slate-700 whitespace-nowrap">{holiday.date}</td>
                           <td className="p-4 text-sm font-bold text-slate-800">{holiday.name}</td>
                           <td className="p-4">
                              <span className={`px-2 py-1 rounded text-[10px] font-black uppercase tracking-wider ${
                                 holiday.type === 'School Holiday' ? 'bg-violet-100 text-violet-700' : 'bg-slate-100 text-slate-600'
                              }`}>
                                 {holiday.type}
                              </span>
                           </td>
                           <td className="p-4 text-right">
                              <button className="text-slate-400 hover:text-slate-700 transition-colors">
                                 <MoreVertical className="w-4 h-4" />
                              </button>
                           </td>
                        </tr>
                     ))}
                  </tbody>
               </table>
            </div>
         </div>

      </div>
    </div>
  );
}
