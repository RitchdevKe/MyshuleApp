"use client";

import React from "react";
import { Search, Monitor, Smartphone, Globe, ShieldOff, LogOut } from "lucide-react";

export default function SessionsPage() {
  const sessions = [
    { id: 1, user: "Jane Wanjiku", role: "Super Admin", device: "Chrome 114 — Windows 11", ip: "192.168.1.45", location: "Nairobi, Kenya", lastActive: "Active now", isCurrent: true, type: "Desktop" },
    { id: 2, user: "Peter Kamau", role: "Admin", device: "Safari 16 — MacOS", ip: "197.232.14.88", location: "Nairobi, Kenya", lastActive: "Active now", isCurrent: false, type: "Desktop" },
    { id: 3, user: "Jane Wanjiku", role: "Super Admin", device: "MyShuleApp — Android 13", ip: "41.90.112.55", location: "Mombasa, Kenya", lastActive: "12 mins ago", isCurrent: false, type: "Mobile" },
    { id: 4, user: "Sarah Hassan", role: "Teacher", device: "Firefox 112 — Windows 10", ip: "192.168.1.112", location: "Nairobi, Kenya", lastActive: "1 hour ago", isCurrent: false, type: "Desktop" },
    { id: 5, user: "David Ochieng", role: "Finance", device: "Chrome 114 — MacOS", ip: "105.160.22.11", location: "Kisumu, Kenya", lastActive: "3 hours ago", isCurrent: false, type: "Desktop" },
  ];

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case "Desktop": return <Monitor className="w-4 h-4" />;
      case "Mobile": return <Smartphone className="w-4 h-4" />;
      default: return <Globe className="w-4 h-4" />;
    }
  };

  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden min-h-[500px]">
      <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50/50">
         <div className="flex items-center gap-2 w-full md:w-auto relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input type="text" placeholder="Search sessions by user or IP..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
         </div>
         <div className="flex gap-2">
            <button className="flex items-center gap-2 px-4 py-2 bg-rose-50 text-rose-600 hover:bg-rose-100 rounded-xl font-bold text-sm transition-all shadow-sm">
               <ShieldOff className="w-4 h-4" />
               Force Revoke All
            </button>
         </div>
      </div>

      <div className="p-6">
         <div className="overflow-x-auto">
           <table className="w-full text-left border-collapse">
             <thead>
               <tr className="bg-slate-50/50 border-b border-slate-200/60">
                 <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">User</th>
                 <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Device & Browser</th>
                 <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">IP Address & Location</th>
                 <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Last Active</th>
                 <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
               </tr>
             </thead>
             <tbody className="divide-y divide-slate-100">
               {sessions.map((sess) => (
                 <tr key={sess.id} className="hover:bg-slate-50/50 transition-colors">
                   <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                         <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center font-bold text-sm shrink-0">
                            {sess.user.charAt(0)}
                         </div>
                         <div>
                           <div className="font-bold text-sm text-slate-800 flex items-center gap-2">
                              {sess.user}
                              {sess.isCurrent && <span className="px-1.5 py-0.5 text-[9px] uppercase tracking-wider font-black bg-emerald-100 text-emerald-700 rounded">Current</span>}
                           </div>
                           <div className="text-xs font-medium text-slate-500 mt-0.5">{sess.role}</div>
                         </div>
                      </div>
                   </td>
                   <td className="py-4 px-6">
                      <div className="flex items-center gap-2 text-sm font-bold text-slate-700">
                         {getDeviceIcon(sess.type)}
                         {sess.device}
                      </div>
                   </td>
                   <td className="py-4 px-6">
                      <div className="text-sm font-bold text-slate-800 font-mono">{sess.ip}</div>
                      <div className="text-xs font-medium text-slate-500 mt-0.5">{sess.location}</div>
                   </td>
                   <td className="py-4 px-6">
                      <span className={`inline-flex items-center text-xs font-bold ${
                        sess.lastActive === 'Active now' ? 'text-emerald-600' : 'text-slate-500'
                      }`}>
                         {sess.lastActive === 'Active now' && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-2"></span>}
                         {sess.lastActive}
                      </span>
                   </td>
                   <td className="py-4 px-6 text-right">
                      {!sess.isCurrent && (
                        <button className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold bg-white border border-slate-200 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-200 text-slate-700 rounded-lg transition-colors">
                           <LogOut className="w-3.5 h-3.5" /> Revoke
                        </button>
                      )}
                   </td>
                 </tr>
               ))}
             </tbody>
           </table>
         </div>
      </div>
    </div>
  );
}
