"use client";

import React, { useState } from "react";
import { FileEdit, Trophy, LineChart, FileQuestion, BookMarked, Activity } from "lucide-react";

export default function AssessmentWorkspace() {
  const [activeTab, setActiveTab] = useState("overview");

  const tabs = [
    { id: "overview", label: "Overview", icon: Activity },
    { id: "examinations", label: "Examinations", icon: FileEdit },
    { id: "continuous", label: "Continuous Assessment", icon: LineChart },
    { id: "cbc-rubrics", label: "CBC Rubrics", icon: BookMarked },
    { id: "cbt", label: "CBT System", icon: FileQuestion },
    { id: "results", label: "Results & Grading", icon: Trophy },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Contextual Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-primary-900 p-5 rounded-3xl border border-primary-800 shadow-lg shadow-primary-900/20">
        <div>
          <h1 className="text-3xl font-black text-white tracking-tight">Assessment & Exams</h1>
          <p className="text-sm text-primary-100 font-medium mt-1">
            Exam management, CBC rubrics, Computer Based Testing, and grading scales.
          </p>
        </div>
      </div>

      {/* Dynamic Tab Navigation */}
      <div className="flex space-x-2 bg-white/40 p-1.5 rounded-2xl overflow-x-auto border border-white/60 backdrop-blur-md shadow-sm hide-scrollbar">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 text-sm font-bold rounded-xl whitespace-nowrap transition-all duration-300 ${
                isActive
                  ? "bg-white text-rose-700 shadow-sm border border-rose-100"
                  : "text-slate-500 hover:text-slate-800 hover:bg-white/50 border border-transparent"
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-rose-500' : 'text-slate-400'}`} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="bg-white/80 backdrop-blur-lg border border-slate-200/80 rounded-3xl shadow-sm min-h-[500px]">
        {activeTab === "overview" && (
          <div className="p-6">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-6">Upcoming Assessments</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-rose-50 border border-rose-100 rounded-2xl p-6 relative overflow-hidden group">
                <div className="absolute right-0 top-0 opacity-10">
                   <FileEdit className="w-24 h-24 -mt-4 -mr-4" />
                </div>
                <div className="text-xs font-black text-rose-600 uppercase tracking-wider mb-2">End of Term</div>
                <div className="text-xl font-black text-rose-900 mb-1">Term 2 Finals</div>
                <div className="text-sm font-bold text-slate-600">Starts in 14 days</div>
              </div>
              
              <div className="bg-white border border-slate-200 rounded-2xl p-6">
                <div className="text-xs font-black text-slate-500 uppercase tracking-wider mb-2">Active CBT</div>
                <div className="text-xl font-black text-slate-800 mb-1">Form 4 Mock (Math)</div>
                <div className="text-sm font-bold text-emerald-600">120/150 Completed</div>
              </div>
            </div>
          </div>
        )}

        {activeTab !== "overview" && (
          <div className="p-12 flex flex-col items-center justify-center text-center h-full min-h-[400px]">
            <div className="w-16 h-16 bg-slate-100 text-slate-400 rounded-2xl flex items-center justify-center mb-4">
              {React.createElement(tabs.find(t => t.id === activeTab)?.icon || Activity, { className: "w-8 h-8" })}
            </div>
            <h3 className="text-xl font-black text-slate-800">Coming Soon</h3>
            <p className="text-sm font-medium text-slate-500 max-w-md mt-2">
              The {tabs.find(t => t.id === activeTab)?.label} workspace is currently being built.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}