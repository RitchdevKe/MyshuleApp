"use client";

import React, { useState } from "react";
import { Map, Calendar, MapPin, Search, Plus } from "lucide-react";

export default function EventsPage() {
  const events = [
    { title: "National Museum Trip", group: "Grade 8 History", date: "Oct 15, 2026", location: "Nairobi National Museum", status: "Approved", cost: "$15" },
    { title: "Science Fair 2026", group: "All School", date: "Nov 02, 2026", location: "Main Hall", status: "Planning", cost: "Free" },
    { title: "Drama Club Retreat", group: "Drama Club", date: "Nov 12-14, 2026", location: "Naivasha Arts Center", status: "Pending Approval", cost: "$120" },
  ];

  return (
    <div className="p-8 space-y-6 bg-white/30 backdrop-blur-md rounded-3xl min-h-[600px]">
      
      {/* Header & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white/60 p-4 rounded-2xl border border-white/60 shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center">
            <Map className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-slate-800">Events & Trips</h2>
            <p className="text-xs font-bold text-slate-500">Coordinate off-campus trips and major school events</p>
          </div>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-amber-600 rounded-xl hover:bg-amber-700 transition-colors shadow-sm">
          <Plus className="w-4 h-4" /> Plan Event
        </button>
      </div>

      <div className="space-y-4">
        {events.map((evt, idx) => (
          <div key={idx} className="bg-white/80 border border-slate-200/60 rounded-3xl p-5 shadow-sm hover:shadow-md hover:border-amber-200 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 group cursor-pointer">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-amber-50 text-amber-500 rounded-2xl flex flex-col items-center justify-center border border-amber-100">
                <span className="text-[10px] font-black uppercase tracking-widest">{evt.date.split(" ")[0]}</span>
                <span className="text-xl font-black">{evt.date.split(" ")[1].replace(",", "")}</span>
              </div>
              <div>
                <h3 className="font-black text-slate-800 text-lg group-hover:text-amber-700 transition-colors">{evt.title}</h3>
                <div className="flex items-center gap-3 text-xs font-medium text-slate-500 mt-1">
                  <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" /> {evt.group}</span>
                  <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {evt.location}</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-6">
              <div className="text-right">
                <div className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Fee</div>
                <div className="text-sm font-bold text-slate-700">{evt.cost}</div>
              </div>
              <span className={`px-3 py-1.5 text-xs font-bold rounded-lg shadow-sm ${
                evt.status === 'Approved' ? 'bg-emerald-100 text-emerald-700' :
                evt.status === 'Planning' ? 'bg-indigo-100 text-indigo-700' :
                'bg-amber-100 text-amber-700'
              }`}>
                {evt.status}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
