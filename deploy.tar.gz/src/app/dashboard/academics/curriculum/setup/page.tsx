"use client";

import React, { useState } from "react";
import { Search, Filter, Plus, MoreHorizontal, Sparkles, Settings, FileSignature, CheckCircle2, AlertTriangle } from "lucide-react";

const initialData = [
  { id: "1", name: "Opener Exam 2026", term: "Term 1", weighting: "20%", status: "Completed" },
  { id: "2", name: "Mid Term 1 2026", term: "Term 1", weighting: "30%", status: "Completed" },
  { id: "3", name: "End Term 1 2026", term: "Term 1", weighting: "50%", status: "Completed" },
  { id: "4", name: "Opener Exam 2026", term: "Term 2", weighting: "20%", status: "Active" },
  { id: "5", name: "Mid Term 2 2026", term: "Term 2", weighting: "30%", status: "Upcoming" },
  { id: "6", name: "End Term 2 2026", term: "Term 2", weighting: "50%", status: "Draft" }
];

export default function SetupPage() {
  const [data, setData] = useState(initialData);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredData = data.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    item.term.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Assessments",  value: "6",    icon: FileSignature, color: "from-primary-600 to-primary-800" },
          { label: "Active Now",         value: "1",    icon: CheckCircle2,  color: "from-emerald-500 to-teal-600" },
          { label: "Upcoming",           value: "1",    icon: AlertTriangle, color: "from-amber-500 to-orange-500" },
          { label: "Settings Models",    value: "2",    icon: Settings,      color: "from-blue-500 to-indigo-600" },
        ].map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className={`bg-gradient-to-br ${c.color} rounded-2xl p-4 text-white shadow-md flex items-center gap-3 relative overflow-hidden group`}>
              <div className="absolute top-0 right-0 -mt-2 -mr-2 w-16 h-16 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700"></div>
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0 relative z-10">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div className="relative z-10">
                <p className="text-2xl font-black leading-tight">{c.value}</p>
                <p className="text-xs font-bold text-white/80">{c.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Table Card */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden flex flex-col min-h-[500px]">
        
        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search Exams..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-64 placeholder:text-slate-400"
            />
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm transition-colors">
              <Filter className="w-4 h-4" /> Filter
            </button>
            <button 
              onClick={() => {
                const newData = [...data, { id: `${data.length + 1}`, name: "New Exam", term: "TBD", weighting: "0%", status: "Draft" }];
                setData(newData);
              }}
              className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all"
            >
              <Plus className="w-4 h-4" /> Create Exam
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-gradient-to-r from-primary-900 to-primary-800 text-white">
              <tr>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Exam Name</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Term</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Weighting</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Status</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredData.map((row) => {
                const isActive = row.status === 'Active';
                return (
                  <tr key={row.id} className="hover:bg-primary-50/40 border-l-4 border-transparent hover:border-l-secondary-500 transition-all group">
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 border bg-slate-50 text-slate-600 border-slate-200">
                          <Settings className="w-5 h-5" />
                        </div>
                        <span className="font-bold text-slate-800">{row.name}</span>
                      </div>
                    </td>
                    <td className="px-5 py-4 font-bold text-slate-600">{row.term}</td>
                    <td className="px-5 py-4">
                      <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-black border bg-primary-50 border-primary-100 text-primary-700">
                        {row.weighting}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-black border ${
                        isActive ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 
                        row.status === 'Completed' ? 'bg-slate-50 text-slate-600 border-slate-200' :
                        row.status === 'Upcoming' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                        'bg-amber-50 text-amber-700 border-amber-200'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          isActive ? 'bg-emerald-500' : 
                          row.status === 'Completed' ? 'bg-slate-400' : 
                          row.status === 'Upcoming' ? 'bg-blue-500' :
                          'bg-amber-500'
                        }`}></span>
                        {row.status}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          
          {filteredData.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-slate-400">
              <Sparkles className="w-12 h-12 mb-3 opacity-20" />
              <p className="font-bold text-lg text-slate-500">No exams found</p>
              <p className="text-sm font-medium mt-1">Try adjusting your search criteria</p>
            </div>
          )}
        </div>
        
        {/* Footer */}
        <div className="px-5 py-3.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/60 mt-auto">
          <span className="font-bold">Showing <span className="text-primary-900">{filteredData.length}</span> records</span>
          <div className="flex gap-1">
            <button className="px-3 py-1.5 border border-slate-200 bg-white rounded-lg font-bold hover:bg-slate-50 disabled:opacity-40 transition-colors shadow-sm" disabled>Prev</button>
            <button className="px-3 py-1.5 border border-slate-200 bg-white rounded-lg font-bold hover:bg-slate-50 transition-colors shadow-sm">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
}