"use client";
import React from "react";
import { Search, Plus, MoreHorizontal, FileText, Download, CheckCircle2 } from "lucide-react";

const mockMaterials = [
  { id: "MAT-001", title: "Fractions Revision Notes", class: "Grade 4", subject: "Mathematics", uploadedBy: "Mr. John D.", date: "2026-08-01" },
  { id: "MAT-002", title: "Photosynthesis Diagram", class: "Grade 5", subject: "Science", uploadedBy: "Mrs. Sarah K.", date: "2026-08-03" },
  { id: "MAT-003", title: "Creative Writing Prompts", class: "Grade 6", subject: "English", uploadedBy: "Ms. Alice M.", date: "2026-08-05" },
  { id: "MAT-004", title: "Map Reading Basics", class: "Grade 4", subject: "Social Studies", uploadedBy: "Mr. James O.", date: "2026-08-08" },
];

export default function MaterialsPage() {
  return (
    <div className="bg-white/60 backdrop-blur-xl border border-white/60 rounded-3xl shadow-lg overflow-hidden flex flex-col min-h-[400px]">
      
      {/* Toolbar */}
      <div className="p-5 border-b border-slate-200/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative w-full sm:max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search study materials..." 
            className="w-full pl-10 pr-4 py-2.5 text-sm font-bold bg-white/80 border border-slate-200/60 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-900 focus:border-primary-900 transition-shadow"
          />
        </div>
        <div className="flex items-center gap-3">
          <select className="px-4 py-2.5 bg-white border border-slate-200/60 rounded-xl text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-900 cursor-pointer">
            <option>All Classes</option>
            <option>Grade 4</option>
            <option>Grade 5</option>
            <option>Grade 6</option>
          </select>
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-white bg-primary-900 rounded-xl hover:bg-primary-800 transition-colors shadow-sm">
            <Plus className="w-4 h-4" /> Upload Material
          </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-x-auto">
        <table className="w-full text-left text-sm text-slate-600">
          <thead className="bg-slate-50/50 text-[10px] uppercase font-black text-slate-500 border-b border-slate-200/60 tracking-wider">
            <tr>
              <th className="px-6 py-4">Title</th>
              <th className="px-6 py-4">Class & Subject</th>
              <th className="px-6 py-4">Uploaded By</th>
              <th className="px-6 py-4">Date Added</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200/60">
            {mockMaterials.map((row, i) => (
              <tr key={i} className="hover:bg-white/80 transition-colors group">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-primary-50 text-primary-900 rounded-lg group-hover:bg-primary-100 transition-colors">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div className="flex flex-col">
                      <span className="font-bold text-slate-800">{row.title}</span>
                      <span className="text-xs font-bold text-slate-400">{row.id}</span>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="font-bold text-slate-700">{row.class}</span>
                    <span className="text-xs font-bold text-slate-500">{row.subject}</span>
                  </div>
                </td>
                <td className="px-6 py-4 font-bold text-slate-700">{row.uploadedBy}</td>
                <td className="px-6 py-4 font-bold text-slate-600">{row.date}</td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-1.5 text-slate-400 hover:text-primary-900 hover:bg-slate-100 rounded-lg transition-colors">
                      <Download className="w-4 h-4" />
                    </button>
                    <button className="p-1.5 text-slate-400 hover:text-primary-900 hover:bg-slate-100 rounded-lg transition-colors">
                      <MoreHorizontal className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Footer */}
      <div className="p-4 border-t border-slate-200/60 flex items-center justify-between text-sm font-bold text-slate-500 bg-white/40 mt-auto">
        <span>Showing 4 of 156 materials</span>
        <div className="flex gap-2">
          <button className="px-4 py-2 border border-slate-200 bg-white rounded-xl hover:bg-slate-50 disabled:opacity-50 transition-colors shadow-sm" disabled>Prev</button>
          <button className="px-4 py-2 border border-slate-200 bg-white rounded-xl hover:bg-slate-50 transition-colors shadow-sm">Next</button>
        </div>
      </div>
    </div>
  );
}
