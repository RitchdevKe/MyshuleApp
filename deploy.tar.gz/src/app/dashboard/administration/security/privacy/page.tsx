"use client";

import React, { useState } from "react";
import { Database, FileText, Globe, Download, Trash2, CheckCircle2 } from "lucide-react";

export default function PrivacyPage() {
  const [retentionPeriod, setRetentionPeriod] = useState("5 Years");

  const privacyRequests = [
    { id: "REQ-091", user: "John Doe (Parent)", type: "Data Export (GDPR)", status: "Pending", date: "Aug 10, 2024" },
    { id: "REQ-090", user: "Sarah Smith (Teacher)", type: "Account Deletion", status: "Completed", date: "Aug 05, 2024" },
  ];

  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden min-h-[500px]">
      <div className="p-6 border-b border-slate-200/60 bg-slate-50/50">
         <h2 className="text-xl font-black text-slate-800">Privacy & Data Compliance</h2>
         <p className="text-sm font-medium text-slate-500 mt-1">Manage data retention, GDPR requests, and privacy policies.</p>
      </div>

      <div className="p-6 space-y-8">
         {/* Data Retention */}
         <div className="bg-white border border-slate-200/60 rounded-2xl p-6 shadow-sm flex flex-col md:flex-row gap-6 items-start justify-between">
            <div className="flex gap-4">
               <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl shrink-0 h-12 w-12 flex items-center justify-center">
                  <Database className="w-6 h-6" />
               </div>
               <div>
                  <h3 className="font-bold text-slate-800 text-lg">Data Retention Policy</h3>
                  <p className="text-sm text-slate-500 font-medium mt-1 max-w-xl">
                     Automatically purge inactive student records and logs after a specified period to comply with data minimization principles.
                  </p>
                  
                  <div className="mt-4 flex gap-4 items-center">
                     <span className="text-sm font-bold text-slate-700">Retain inactive data for:</span>
                     <select 
                        value={retentionPeriod}
                        onChange={(e) => setRetentionPeriod(e.target.value)}
                        className="bg-slate-50 border border-slate-200 text-sm font-bold text-slate-700 rounded-lg px-3 py-1.5 outline-none focus:border-primary-500"
                     >
                        <option>1 Year</option>
                        <option>3 Years</option>
                        <option>5 Years</option>
                        <option>Indefinitely (Not Recommended)</option>
                     </select>
                  </div>
               </div>
            </div>
         </div>

         {/* Privacy Requests (GDPR/CCPA) */}
         <div>
            <div className="flex justify-between items-center mb-4">
               <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider">Privacy Requests (GDPR / CCPA)</h3>
            </div>
            <div className="bg-white border border-slate-200/60 rounded-2xl shadow-sm overflow-hidden">
               <table className="w-full text-left border-collapse">
                  <thead>
                     <tr className="bg-slate-50/50 border-b border-slate-100">
                        <th className="py-3 px-5 text-xs font-bold text-slate-500 uppercase tracking-wider">Request ID & User</th>
                        <th className="py-3 px-5 text-xs font-bold text-slate-500 uppercase tracking-wider">Type</th>
                        <th className="py-3 px-5 text-xs font-bold text-slate-500 uppercase tracking-wider">Date</th>
                        <th className="py-3 px-5 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                        <th className="py-3 px-5 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Action</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                     {privacyRequests.map((req) => (
                        <tr key={req.id}>
                           <td className="py-3 px-5">
                              <div className="font-bold text-sm text-slate-800">{req.id}</div>
                              <div className="text-xs text-slate-500 font-medium">{req.user}</div>
                           </td>
                           <td className="py-3 px-5 text-sm font-bold text-slate-700">{req.type}</td>
                           <td className="py-3 px-5 text-sm font-medium text-slate-500">{req.date}</td>
                           <td className="py-3 px-5">
                              {req.status === 'Pending' ? (
                                 <span className="inline-flex items-center px-2 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg bg-amber-100 text-amber-700">Pending</span>
                              ) : (
                                 <span className="inline-flex items-center px-2 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg bg-emerald-100 text-emerald-700">Completed</span>
                              )}
                           </td>
                           <td className="py-3 px-5 text-right">
                              {req.status === 'Pending' ? (
                                 <div className="flex justify-end gap-2">
                                    <button className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg transition-colors" title="Export Data">
                                       <Download className="w-4 h-4" />
                                    </button>
                                    <button className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg transition-colors" title="Delete Data">
                                       <Trash2 className="w-4 h-4" />
                                    </button>
                                    <button className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-600 rounded-lg transition-colors" title="Mark as Resolved">
                                       <CheckCircle2 className="w-4 h-4" />
                                    </button>
                                 </div>
                              ) : (
                                 <span className="text-xs font-medium text-slate-400">Resolved</span>
                              )}
                           </td>
                        </tr>
                     ))}
                  </tbody>
               </table>
            </div>
         </div>

         {/* Legal Documents */}
         <div>
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4">Legal Agreements</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               <div className="bg-white border border-slate-200/60 rounded-xl p-4 flex items-center justify-between shadow-sm">
                  <div className="flex items-center gap-3">
                     <FileText className="w-5 h-5 text-slate-400" />
                     <div>
                        <div className="font-bold text-sm text-slate-800">Terms of Service</div>
                        <div className="text-xs text-slate-500">Last updated: Jan 15, 2024</div>
                     </div>
                  </div>
                  <button className="text-xs font-bold text-primary-600 hover:underline">Update URL</button>
               </div>
               
               <div className="bg-white border border-slate-200/60 rounded-xl p-4 flex items-center justify-between shadow-sm">
                  <div className="flex items-center gap-3">
                     <Globe className="w-5 h-5 text-slate-400" />
                     <div>
                        <div className="font-bold text-sm text-slate-800">Privacy Policy</div>
                        <div className="text-xs text-slate-500">Last updated: Mar 22, 2024</div>
                     </div>
                  </div>
                  <button className="text-xs font-bold text-primary-600 hover:underline">Update URL</button>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
}
