"use client";

import React from "react";
import { Plus, Edit2, Calculator } from "lucide-react";

export default function FeeStructuresPage() {
  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-black text-slate-800">Fee Structures</h3>
            <p className="text-sm font-medium text-slate-500">Define and manage tuition and auxiliary fees by grade.</p>
          </div>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-slate-800 rounded-xl hover:bg-slate-700 transition-colors shadow-sm">
          <Plus className="w-4 h-4" /> New Structure
        </button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm hover:border-slate-300 transition-colors">
          <div className="flex justify-between items-start mb-4">
            <h4 className="font-black text-slate-800 text-lg">Grade 1-3 (Day Scholar)</h4>
            <button className="text-slate-400 hover:text-emerald-600 transition-colors flex items-center gap-1 text-xs font-bold">
              <Edit2 className="w-3.5 h-3.5" /> Edit
            </button>
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-slate-50 border border-slate-100 rounded-xl hover:bg-white transition-colors">
              <div>
                <div className="text-sm font-bold text-slate-800">Tuition Fee</div>
                <div className="text-[10px] uppercase tracking-wider text-slate-500">Mandatory • Termly</div>
              </div>
              <div className="font-black text-emerald-700">KSh 25,000</div>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-slate-50 border border-slate-100 rounded-xl hover:bg-white transition-colors">
              <div>
                <div className="text-sm font-bold text-slate-800">Activity Fee</div>
                <div className="text-[10px] uppercase tracking-wider text-slate-500">Mandatory • Termly</div>
              </div>
              <div className="font-black text-emerald-700">KSh 3,000</div>
            </div>

            <div className="flex justify-between items-center p-3 bg-slate-50 border border-slate-100 rounded-xl hover:bg-white transition-colors">
              <div>
                <div className="text-sm font-bold text-slate-800">Transport (Zone A)</div>
                <div className="text-[10px] uppercase tracking-wider text-sky-600">Optional • Termly</div>
              </div>
              <div className="font-black text-slate-600">Variable</div>
            </div>
          </div>
          
          <div className="mt-4 pt-4 border-t border-slate-100 flex justify-between items-center">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Base Term Total</span>
              <span className="text-lg font-black text-slate-800">KSh 28,000</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm hover:border-slate-300 transition-colors">
          <div className="flex justify-between items-start mb-4">
            <h4 className="font-black text-slate-800 text-lg">Grade 8 (Boarder)</h4>
            <button className="text-slate-400 hover:text-emerald-600 transition-colors flex items-center gap-1 text-xs font-bold">
              <Edit2 className="w-3.5 h-3.5" /> Edit
            </button>
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-slate-50 border border-slate-100 rounded-xl hover:bg-white transition-colors">
              <div>
                <div className="text-sm font-bold text-slate-800">Tuition</div>
                <div className="text-[10px] uppercase tracking-wider text-slate-500">Mandatory • Termly</div>
              </div>
              <div className="font-black text-emerald-700">KSh 35,000</div>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-slate-50 border border-slate-100 rounded-xl hover:bg-white transition-colors">
              <div>
                <div className="text-sm font-bold text-slate-800">Boarding & Meals</div>
                <div className="text-[10px] uppercase tracking-wider text-sky-600">Mandatory • Termly</div>
              </div>
              <div className="font-black text-emerald-700">KSh 45,000</div>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-slate-50 border border-slate-100 rounded-xl hover:bg-white transition-colors">
              <div>
                <div className="text-sm font-bold text-slate-800">Activity Fee</div>
                <div className="text-[10px] uppercase tracking-wider text-slate-500">Mandatory • Termly</div>
              </div>
              <div className="font-black text-emerald-700">KSh 3,000</div>
            </div>
          </div>
          
          <div className="mt-4 pt-4 border-t border-slate-100 flex justify-between items-center">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Base Term Total</span>
              <span className="text-lg font-black text-slate-800">KSh 83,000</span>
          </div>
        </div>

      </div>
    </div>
  );
}
