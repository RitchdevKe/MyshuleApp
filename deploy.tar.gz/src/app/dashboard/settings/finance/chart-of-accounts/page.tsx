"use client";

import React, { useState } from "react";
import { BookOpen, Plus, Search, Filter, MoreVertical, FolderOpen, ArrowUpRight, ArrowDownRight } from "lucide-react";

export default function ChartOfAccountsPage() {
  const [activeTab, setActiveTab] = useState("all");

  const accounts = [
     { code: "1000", name: "Cash on Hand", type: "Asset", category: "Current Assets", status: "Active" },
     { code: "1100", name: "Main Bank Account", type: "Asset", category: "Bank", status: "Active" },
     { code: "1200", name: "Accounts Receivable", type: "Asset", category: "Current Assets", status: "Active" },
     { code: "2000", name: "Accounts Payable", type: "Liability", category: "Current Liabilities", status: "Active" },
     { code: "3000", name: "Retained Earnings", type: "Equity", category: "Equity", status: "Active" },
     { code: "4000", name: "Tuition Fees Revenue", type: "Revenue", category: "Operating Revenue", status: "Active" },
     { code: "4100", name: "Transport Fees Revenue", type: "Revenue", category: "Operating Revenue", status: "Active" },
     { code: "5000", name: "Teacher Salaries", type: "Expense", category: "Payroll", status: "Active" },
     { code: "5100", name: "Stationery & Supplies", type: "Expense", category: "Operating Expenses", status: "Active" },
     { code: "5200", name: "Electricity & Water", type: "Expense", category: "Utilities", status: "Active" },
  ];

  const filteredAccounts = activeTab === "all" ? accounts : accounts.filter(a => a.type.toLowerCase() === activeTab);

  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-black text-slate-800">Chart of Accounts</h3>
            <p className="text-sm font-medium text-slate-500">Manage your general ledger, account codes, and classifications.</p>
          </div>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-slate-800 rounded-xl hover:bg-slate-700 transition-colors shadow-sm">
          <Plus className="w-4 h-4" /> New Account
        </button>
      </div>

      {/* Toolbar & Filters */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
         <div className="flex space-x-1 bg-slate-100/50 p-1 rounded-xl border border-slate-200">
            {['all', 'asset', 'liability', 'equity', 'revenue', 'expense'].map((tab) => (
               <button 
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-1.5 text-xs font-bold rounded-lg capitalize transition-colors ${
                     activeTab === tab 
                        ? 'bg-white text-indigo-700 shadow-sm border border-slate-200/50' 
                        : 'text-slate-500 hover:text-slate-700'
                  }`}
               >
                  {tab}
               </button>
            ))}
         </div>
         
         <div className="flex items-center gap-3 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
               <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
               <input 
                  type="text" 
                  placeholder="Search accounts..." 
                  className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-sm font-medium text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm"
               />
            </div>
            <button className="flex items-center gap-2 px-3 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl font-bold text-sm hover:bg-slate-50 transition-colors shadow-sm">
               <Filter className="w-4 h-4" /> Filter
            </button>
         </div>
      </div>

      {/* Accounts Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
         <table className="w-full text-left border-collapse">
            <thead>
               <tr className="bg-slate-50/50 border-b border-slate-100">
                  <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider w-24">Code</th>
                  <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider">Account Name</th>
                  <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider">Type</th>
                  <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider">Category</th>
                  <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center w-24">Status</th>
                  <th className="p-4 w-12"></th>
               </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
               {filteredAccounts.map((account, idx) => {
                  let typeColor = "text-slate-500 bg-slate-100";
                  let Icon = FolderOpen;
                  if (account.type === "Asset") { typeColor = "text-sky-700 bg-sky-100"; Icon = FolderOpen; }
                  if (account.type === "Liability") { typeColor = "text-orange-700 bg-orange-100"; Icon = FolderOpen; }
                  if (account.type === "Equity") { typeColor = "text-purple-700 bg-purple-100"; Icon = FolderOpen; }
                  if (account.type === "Revenue") { typeColor = "text-emerald-700 bg-emerald-100"; Icon = ArrowUpRight; }
                  if (account.type === "Expense") { typeColor = "text-rose-700 bg-rose-100"; Icon = ArrowDownRight; }

                  return (
                     <tr key={idx} className="hover:bg-slate-50/50 transition-colors group cursor-pointer">
                        <td className="p-4">
                           <span className="font-mono text-sm font-bold text-slate-600 bg-slate-100 px-2 py-1 rounded">{account.code}</span>
                        </td>
                        <td className="p-4">
                           <div className="text-sm font-bold text-slate-800 group-hover:text-indigo-700 transition-colors">{account.name}</div>
                        </td>
                        <td className="p-4">
                           <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider ${typeColor}`}>
                              <Icon className="w-3 h-3" /> {account.type}
                           </div>
                        </td>
                        <td className="p-4">
                           <span className="text-xs font-bold text-slate-500">{account.category}</span>
                        </td>
                        <td className="p-4 text-center">
                           <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 shadow-sm shadow-emerald-500/20"></span>
                        </td>
                        <td className="p-4 text-right">
                           <button className="text-slate-400 hover:text-slate-700 transition-colors">
                              <MoreVertical className="w-4 h-4" />
                           </button>
                        </td>
                     </tr>
                  );
               })}
               
               {filteredAccounts.length === 0 && (
                  <tr>
                     <td colSpan={6} className="p-8 text-center text-slate-500 text-sm font-medium">
                        No accounts found matching the selected criteria.
                     </td>
                  </tr>
               )}
            </tbody>
         </table>
      </div>
    </div>
  );
}
