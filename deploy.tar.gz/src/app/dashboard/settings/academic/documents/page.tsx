"use client";

import React, { useState } from "react";
import { FileText, Plus, Eye, LayoutTemplate, MessageSquare, Award, CheckSquare, Target } from "lucide-react";

export default function DocumentsPage() {
  const [toggles, setToggles] = useState({
     showPrincipal: true,
     showClassTeacher: true,
     showAttendance: true,
     showExtracurricular: false,
     showBehavior: true,
  });

  const handleToggle = (key: keyof typeof toggles) => {
     setToggles(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="p-6 md:p-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
         <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-pink-50 text-pink-600 flex items-center justify-center">
               <FileText className="w-5 h-5" />
            </div>
            <div>
               <h3 className="text-xl font-black text-slate-800">Document Templates</h3>
               <p className="text-sm font-medium text-slate-500">Configure report cards, transcripts, and leaving certificates.</p>
            </div>
         </div>
         <button className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-xl text-sm font-bold shadow-sm hover:bg-slate-700 transition-colors">
            <Plus className="w-4 h-4" /> New Template
         </button>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
         
         {/* Template List */}
         <div className="lg:w-1/3 space-y-4">
            <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">Active Templates</h4>
            
            <div className="bg-pink-50 border border-pink-200 p-4 rounded-2xl cursor-pointer">
               <div className="flex justify-between items-start mb-2">
                  <h5 className="font-bold text-pink-900">Standard End of Term</h5>
                  <span className="bg-pink-200 text-pink-800 text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded">Default</span>
               </div>
               <p className="text-xs text-pink-700 font-medium">Used for end-of-term academic reports across all phases.</p>
            </div>

            <div className="bg-white border border-slate-200 p-4 rounded-2xl cursor-pointer hover:border-slate-300 transition-colors">
               <h5 className="font-bold text-slate-800 mb-1">Mid Term Progress</h5>
               <p className="text-xs text-slate-500 font-medium">Lighter template showing only CAT marks.</p>
            </div>

            <div className="bg-white border border-slate-200 p-4 rounded-2xl cursor-pointer hover:border-slate-300 transition-colors">
               <h5 className="font-bold text-slate-800 mb-1">School Leaving Certificate</h5>
               <p className="text-xs text-slate-500 font-medium">Official exit document.</p>
            </div>
         </div>

         {/* Configuration Pane */}
         <div className="lg:w-2/3">
            <div className="bg-white border border-slate-200 rounded-3xl shadow-sm overflow-hidden">
               <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                  <div className="flex items-center gap-3">
                     <LayoutTemplate className="w-5 h-5 text-slate-400" />
                     <h4 className="font-black text-slate-800 text-lg">Editing: Standard End of Term</h4>
                  </div>
                  <button className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors shadow-sm">
                     <Eye className="w-3.5 h-3.5" /> Preview PDF
                  </button>
               </div>
               
               <div className="p-6 space-y-6">
                  
                  <div>
                     <h5 className="text-sm font-bold text-slate-800 mb-3">Included Sections</h5>
                     <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        
                        <label className={`flex items-center justify-between p-4 rounded-xl border cursor-pointer transition-all ${toggles.showClassTeacher ? 'bg-pink-50/50 border-pink-200' : 'bg-slate-50 border-slate-200'}`}>
                           <div className="flex items-center gap-3">
                              <MessageSquare className={`w-4 h-4 ${toggles.showClassTeacher ? 'text-pink-500' : 'text-slate-400'}`} />
                              <span className="text-sm font-bold text-slate-700">Class Teacher Remarks</span>
                           </div>
                           <input type="checkbox" checked={toggles.showClassTeacher} onChange={() => handleToggle('showClassTeacher')} className="rounded text-pink-500 focus:ring-pink-500" />
                        </label>

                        <label className={`flex items-center justify-between p-4 rounded-xl border cursor-pointer transition-all ${toggles.showPrincipal ? 'bg-pink-50/50 border-pink-200' : 'bg-slate-50 border-slate-200'}`}>
                           <div className="flex items-center gap-3">
                              <Target className={`w-4 h-4 ${toggles.showPrincipal ? 'text-pink-500' : 'text-slate-400'}`} />
                              <span className="text-sm font-bold text-slate-700">Principal Remarks</span>
                           </div>
                           <input type="checkbox" checked={toggles.showPrincipal} onChange={() => handleToggle('showPrincipal')} className="rounded text-pink-500 focus:ring-pink-500" />
                        </label>

                        <label className={`flex items-center justify-between p-4 rounded-xl border cursor-pointer transition-all ${toggles.showAttendance ? 'bg-pink-50/50 border-pink-200' : 'bg-slate-50 border-slate-200'}`}>
                           <div className="flex items-center gap-3">
                              <CheckSquare className={`w-4 h-4 ${toggles.showAttendance ? 'text-pink-500' : 'text-slate-400'}`} />
                              <span className="text-sm font-bold text-slate-700">Attendance Summary</span>
                           </div>
                           <input type="checkbox" checked={toggles.showAttendance} onChange={() => handleToggle('showAttendance')} className="rounded text-pink-500 focus:ring-pink-500" />
                        </label>

                        <label className={`flex items-center justify-between p-4 rounded-xl border cursor-pointer transition-all ${toggles.showBehavior ? 'bg-pink-50/50 border-pink-200' : 'bg-slate-50 border-slate-200'}`}>
                           <div className="flex items-center gap-3">
                              <Award className={`w-4 h-4 ${toggles.showBehavior ? 'text-pink-500' : 'text-slate-400'}`} />
                              <span className="text-sm font-bold text-slate-700">Behavior & Conduct</span>
                           </div>
                           <input type="checkbox" checked={toggles.showBehavior} onChange={() => handleToggle('showBehavior')} className="rounded text-pink-500 focus:ring-pink-500" />
                        </label>
                     </div>
                  </div>

                  <div>
                     <h5 className="text-sm font-bold text-slate-800 mb-3">Footer Text (Disclaimer)</h5>
                     <textarea 
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 text-sm font-medium text-slate-600 focus:outline-none focus:border-pink-500 focus:ring-2 focus:ring-pink-500/20 transition-all resize-none h-24"
                        defaultValue="This report card is generated electronically and is valid without a signature. Any alterations to this document will render it invalid."
                     />
                  </div>
                  
               </div>
            </div>
         </div>

      </div>
    </div>
  );
}
