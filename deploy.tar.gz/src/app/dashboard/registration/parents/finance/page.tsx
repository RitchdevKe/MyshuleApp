"use client";

import React, { useState } from "react";
import { Search, Filter, Plus, MoreHorizontal, FileText, ChevronLeft, ChevronRight, DollarSign, Wallet, ArrowUpRight, CheckCircle2, Sparkles, GraduationCap } from "lucide-react";

const FINANCE_DATA = [
  { id: "ACC-001", parentName: "Grace Njenga",   linkedStudents: ["Samuel Njenga"], responsibility: "100%", balance: "KES 15,000", lastStatement: "Oct 1, 2026", status: "Overdue" },
  { id: "ACC-002", parentName: "Paul Kiprotich", linkedStudents: ["Mercy Kiprotich"], responsibility: "100%", balance: "KES 0",      lastStatement: "Oct 1, 2026", status: "Cleared" },
  { id: "ACC-003", parentName: "Jane Omondi",    linkedStudents: ["Liam Omondi", "Sue Omondi"], responsibility: "50%", balance: "KES 4,500", lastStatement: "Oct 1, 2026", status: "Pending" },
];

export default function FinancePage() {
  const [search, setSearch] = useState("");

  const filtered = FINANCE_DATA.filter(m => 
    m.parentName.toLowerCase().includes(search.toLowerCase()) || 
    m.id.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Outstanding", value: "KES 1.2M", icon: DollarSign,    color: "from-rose-500 to-rose-700" },
          { label: "Cleared Accounts",  value: "342",      icon: CheckCircle2,  color: "from-emerald-500 to-teal-600" },
          { label: "Pending Accounts",  value: "84",       icon: Wallet,        color: "from-amber-500 to-orange-500" },
          { label: "Statements Sent",   value: "426",      icon: FileText,      color: "from-primary-600 to-primary-800" },
        ].map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className={`bg-gradient-to-br ${c.color} rounded-2xl p-4 text-white shadow-md flex items-center gap-3 relative overflow-hidden group`}>
              <div className="absolute top-0 right-0 -mt-2 -mr-2 w-16 h-16 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700"></div>
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0 relative z-10">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div className="relative z-10">
                <p className="text-2xl font-black leading-tight">{c.value}</p>
                <p className="text-xs font-bold text-white/80">{c.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main card */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden flex flex-col min-h-[500px]">

        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search parents or accounts..."
              className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-64 placeholder:text-slate-400"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm transition-colors">
              <ArrowUpRight className="w-4 h-4" /> Send Reminders
            </button>
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm transition-colors">
              <Filter className="w-4 h-4" /> Filter
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all">
              <Plus className="w-4 h-4" /> Generate Statement
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-primary-900 to-primary-800 text-white">
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Account</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Linked Students</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Fee Responsibility</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Current Balance</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Last Statement</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((row) => {
                const isCleared = row.status === 'Cleared';
                const isOverdue = row.status === 'Overdue';

                return (
                  <tr key={row.id} className="hover:bg-primary-50/40 border-l-4 border-transparent hover:border-l-secondary-500 transition-all group">
                    <td className="px-5 py-4">
                      <div className="font-bold text-slate-800">{row.parentName}</div>
                      <div className="text-[10px] font-black text-primary-700 bg-primary-50 px-1.5 py-0.5 rounded mt-0.5 w-fit">{row.id}</div>
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex flex-col gap-1">
                        {row.linkedStudents.map((s, j) => (
                          <span key={j} className="flex items-center gap-1 text-[10px] font-bold text-slate-700 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-lg w-fit">
                            <GraduationCap className="w-2.5 h-2.5" /> {s}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-black border bg-primary-50 border-primary-100 text-primary-700">
                        {row.responsibility}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex flex-col items-start gap-1">
                        <span className={`font-black ${isOverdue ? 'text-rose-600' : isCleared ? 'text-emerald-600' : 'text-slate-700'}`}>
                          {row.balance}
                        </span>
                        <span className={`text-[9px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded ${
                          isCleared ? 'bg-emerald-50 text-emerald-700' : 
                          isOverdue ? 'bg-rose-50 text-rose-700' : 'bg-amber-50 text-amber-700'
                        }`}>
                          {row.status}
                        </span>
                      </div>
                    </td>
                    <td className="px-5 py-4 font-bold text-slate-600">
                      {row.lastStatement}
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          
          {filtered.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-slate-400">
              <Sparkles className="w-12 h-12 mb-3 opacity-20" />
              <p className="font-bold text-lg text-slate-500">No accounts found</p>
            </div>
          )}
        </div>

        {/* Pagination */}
        <div className="px-5 py-3.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/60 mt-auto">
          <span className="font-bold">Showing <span className="text-primary-900">{filtered.length}</span> accounts</span>
          <div className="flex items-center gap-1">
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg font-bold disabled:opacity-40" disabled>
              <ChevronLeft className="w-3.5 h-3.5" /> Prev
            </button>
            <button className="w-8 h-8 flex items-center justify-center rounded-lg bg-primary-900 text-white text-xs font-black">1</button>
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg font-bold">
              Next <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}