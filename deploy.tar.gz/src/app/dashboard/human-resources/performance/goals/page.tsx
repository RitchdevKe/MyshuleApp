"use client";

import React from "react";
import { Target, TrendingUp, Filter, Plus, Flag, AlertTriangle, Users } from "lucide-react";

export default function GoalsPage() {
  const goals = [
    { id: "G-101", title: "Improve Student Standardized Test Scores", owner: "Academic Dept", progress: 75, status: "On Track", type: "Department", dueDate: "Q3 2024" },
    { id: "G-102", title: "Complete Advanced Certification", owner: "Jane Doe", progress: 40, status: "At Risk", type: "Individual", dueDate: "Q4 2024" },
    { id: "G-103", title: "Implement New Science Curriculum", owner: "Science Dept", progress: 90, status: "On Track", type: "Department", dueDate: "Q3 2024" },
    { id: "G-104", title: "Reduce Equipment Downtime by 20%", owner: "Maintenance", progress: 15, status: "Off Track", type: "Department", dueDate: "Q4 2024" },
    { id: "G-105", title: "Host 3 Parent-Teacher Seminars", owner: "Sarah Connor", progress: 66, status: "On Track", type: "Individual", dueDate: "Q4 2024" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div>
           <h2 className="text-lg font-black text-slate-800">Goals & KPIs</h2>
           <p className="text-sm font-medium text-slate-500">Track department objectives and individual performance targets.</p>
        </div>
        <div className="flex gap-2">
           <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
              <Filter className="w-4 h-4" />
              Filter
           </button>
           <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
              <Plus className="w-4 h-4" />
              New Goal
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
         {goals.map((goal) => (
            <div key={goal.id} className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-6 hover:shadow-xl transition-all duration-300 group flex flex-col">
               <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-2">
                     <span className={`px-2 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg flex items-center gap-1 ${
                        goal.type === 'Department' ? 'bg-primary-50 text-primary-600' : 'bg-slate-100 text-slate-600'
                     }`}>
                        {goal.type === 'Department' ? <Users className="w-3 h-3" /> : <Target className="w-3 h-3" />}
                        {goal.type}
                     </span>
                  </div>
                  <div className="flex items-center gap-1">
                     <span className={`px-2 py-1 text-xs font-bold rounded-lg ${
                        goal.status === 'On Track' ? 'bg-emerald-50 text-emerald-600' :
                        goal.status === 'At Risk' ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'
                     }`}>
                        {goal.status}
                     </span>
                  </div>
               </div>
               
               <h3 className="font-black text-slate-800 mb-1 leading-snug">{goal.title}</h3>
               <p className="text-xs font-bold text-slate-400 mb-6">Owner: <span className="text-slate-600">{goal.owner}</span></p>

               <div className="mt-auto">
                  <div className="flex justify-between items-end mb-2">
                     <p className="text-xs font-bold text-slate-500">Progress</p>
                     <p className="text-lg font-black text-slate-800">{goal.progress}%</p>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden mb-4">
                     <div 
                        className={`h-full rounded-full ${
                           goal.status === 'On Track' ? 'bg-emerald-500' :
                           goal.status === 'At Risk' ? 'bg-amber-500' : 'bg-rose-500'
                        }`}
                        style={{ width: `${goal.progress}%` }}
                     ></div>
                  </div>
                  
                  <div className="flex justify-between items-center pt-3 border-t border-slate-100">
                     <div className="flex items-center gap-1.5 text-xs font-bold text-slate-500">
                        <Flag className="w-3.5 h-3.5 text-slate-400" />
                        Due: {goal.dueDate}
                     </div>
                     <button className="text-sm font-bold text-primary-600 hover:text-primary-800">
                        Update
                     </button>
                  </div>
               </div>
            </div>
         ))}
      </div>
    </div>
  );
}
