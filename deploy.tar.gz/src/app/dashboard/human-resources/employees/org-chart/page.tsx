"use client";

import React from "react";
import { Download, Users, Briefcase, GraduationCap, Building2 } from "lucide-react";

export default function OrgChartPage() {
  return (
    <div className="space-y-6">
       <div className="flex justify-between items-center bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-4">
          <h2 className="text-lg font-black text-slate-800 ml-2">Organizational Structure</h2>
          <div className="flex gap-2">
             <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
                <Download className="w-4 h-4" />
                Export PDF
             </button>
          </div>
       </div>

       <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-8 overflow-x-auto">
         
         {/* Principal Node */}
         <div className="flex flex-col items-center">
            <div className="w-64 bg-primary-900 rounded-2xl p-4 shadow-lg shadow-primary-900/20 text-center relative z-10">
               <div className="w-16 h-16 mx-auto bg-white/10 rounded-full flex items-center justify-center mb-3">
                  <span className="text-xl font-black text-white">SP</span>
               </div>
               <h3 className="text-lg font-black text-white">Sarah Palmer</h3>
               <p className="text-sm font-bold text-primary-200">School Principal</p>
            </div>
            {/* Connecting Line Down */}
            <div className="w-0.5 h-8 bg-slate-300"></div>
            {/* Horizontal Connecting Line */}
            <div className="w-[800px] h-0.5 bg-slate-300"></div>
         </div>

         {/* Department Heads Level */}
         <div className="flex justify-center gap-8 mt-0 relative">
            {/* Connecting Lines Down from Horizontal */}
            <div className="absolute top-0 w-full flex justify-between px-[140px]">
               <div className="w-0.5 h-8 bg-slate-300"></div>
               <div className="w-0.5 h-8 bg-slate-300"></div>
               <div className="w-0.5 h-8 bg-slate-300"></div>
            </div>

            {/* Dept 1: Academics */}
            <div className="flex flex-col items-center mt-8">
               <div className="w-64 bg-white border border-slate-200 shadow-sm rounded-2xl p-4 text-center relative z-10 hover:border-primary-500 transition-colors">
                  <div className="w-12 h-12 mx-auto bg-primary-50 text-primary-600 rounded-xl flex items-center justify-center mb-2">
                     <GraduationCap className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-black text-slate-800">David Mwangi</h3>
                  <p className="text-xs font-bold text-slate-500">Head of Academics</p>
               </div>
               <div className="w-0.5 h-8 bg-slate-200"></div>
               <div className="flex flex-col gap-2">
                  <div className="w-56 bg-slate-50 border border-slate-200 rounded-xl p-3 text-center text-sm font-medium text-slate-700">Senior Teachers (12)</div>
                  <div className="w-56 bg-slate-50 border border-slate-200 rounded-xl p-3 text-center text-sm font-medium text-slate-700">Junior Teachers (24)</div>
               </div>
            </div>

            {/* Dept 2: Operations */}
            <div className="flex flex-col items-center mt-8">
               <div className="w-64 bg-white border border-slate-200 shadow-sm rounded-2xl p-4 text-center relative z-10 hover:border-primary-500 transition-colors">
                  <div className="w-12 h-12 mx-auto bg-secondary-50 text-secondary-600 rounded-xl flex items-center justify-center mb-2">
                     <Building2 className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-black text-slate-800">Robert Kiprono</h3>
                  <p className="text-xs font-bold text-slate-500">Head of Operations</p>
               </div>
               <div className="w-0.5 h-8 bg-slate-200"></div>
               <div className="flex flex-col gap-2">
                  <div className="w-56 bg-slate-50 border border-slate-200 rounded-xl p-3 text-center text-sm font-medium text-slate-700">Transport Team (8)</div>
                  <div className="w-56 bg-slate-50 border border-slate-200 rounded-xl p-3 text-center text-sm font-medium text-slate-700">Maintenance (15)</div>
               </div>
            </div>

            {/* Dept 3: Administration */}
            <div className="flex flex-col items-center mt-8">
               <div className="w-64 bg-white border border-slate-200 shadow-sm rounded-2xl p-4 text-center relative z-10 hover:border-primary-500 transition-colors">
                  <div className="w-12 h-12 mx-auto bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center mb-2">
                     <Briefcase className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-black text-slate-800">Alice Wanjiku</h3>
                  <p className="text-xs font-bold text-slate-500">Head of Administration</p>
               </div>
               <div className="w-0.5 h-8 bg-slate-200"></div>
               <div className="flex flex-col gap-2">
                  <div className="w-56 bg-slate-50 border border-slate-200 rounded-xl p-3 text-center text-sm font-medium text-slate-700">HR & Finance (6)</div>
                  <div className="w-56 bg-slate-50 border border-slate-200 rounded-xl p-3 text-center text-sm font-medium text-slate-700">IT Support (3)</div>
               </div>
            </div>
         </div>

       </div>
    </div>
  );
}
