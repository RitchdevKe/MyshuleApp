"use client";

import React from "react";
import { Search, Download, Filter, UserCog, LogIn, FileWarning, ShieldAlert } from "lucide-react";

export default function AuditPage() {
  const auditLogs = [
    { id: "EVT-8921", date: "Aug 11, 2024 - 14:32", user: "Jane Wanjiku", action: "Policy Updated", resource: "Password Policy", status: "Success", ip: "192.168.1.45", icon: UserCog, color: "text-indigo-600 bg-indigo-50" },
    { id: "EVT-8920", date: "Aug 11, 2024 - 12:15", user: "Unknown", action: "Failed Login", resource: "Admin Portal", status: "Failed", ip: "45.22.11.8", icon: ShieldAlert, color: "text-rose-600 bg-rose-50" },
    { id: "EVT-8919", date: "Aug 11, 2024 - 09:00", user: "Peter Kamau", action: "Successful Login", resource: "Admin Portal", status: "Success", ip: "197.232.14.88", icon: LogIn, color: "text-emerald-600 bg-emerald-50" },
    { id: "EVT-8918", date: "Aug 10, 2024 - 16:45", user: "Jane Wanjiku", action: "Data Export", resource: "Student Records", status: "Success", ip: "192.168.1.45", icon: FileWarning, color: "text-amber-600 bg-amber-50" },
    { id: "EVT-8917", date: "Aug 10, 2024 - 11:20", user: "Sarah Hassan", action: "Role Modified", resource: "User: David Ochieng", status: "Success", ip: "192.168.1.112", icon: UserCog, color: "text-indigo-600 bg-indigo-50" },
  ];

  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden min-h-[500px]">
      <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50/50">
         <div className="flex items-center gap-2 w-full md:w-auto relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input type="text" placeholder="Search event logs..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
         </div>
         <div className="flex gap-2">
            <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
               <Filter className="w-4 h-4" />
               Filter
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
               <Download className="w-4 h-4" />
               Export CSV
            </button>
         </div>
      </div>

      <div className="p-6">
         <div className="overflow-x-auto">
           <table className="w-full text-left border-collapse">
             <thead>
               <tr className="bg-slate-50/50 border-b border-slate-200/60">
                 <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Event & Date</th>
                 <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Action & Resource</th>
                 <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">User & IP</th>
                 <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
               </tr>
             </thead>
             <tbody className="divide-y divide-slate-100">
               {auditLogs.map((log) => {
                  const Icon = log.icon;
                  return (
                 <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                   <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                         <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${log.color}`}>
                            <Icon className="w-4 h-4" />
                         </div>
                         <div>
                           <span className="font-bold text-sm text-slate-800 block">{log.id}</span>
                           <span className="text-xs font-medium text-slate-500 mt-0.5">{log.date}</span>
                         </div>
                      </div>
                   </td>
                   <td className="py-4 px-6">
                      <div className="text-sm font-bold text-slate-800">{log.action}</div>
                      <div className="text-xs font-medium text-slate-500 mt-0.5">Target: {log.resource}</div>
                   </td>
                   <td className="py-4 px-6">
                      <div className="text-sm font-bold text-slate-700">{log.user}</div>
                      <div className="text-xs font-medium text-slate-500 font-mono mt-0.5">{log.ip}</div>
                   </td>
                   <td className="py-4 px-6">
                      <span className={`inline-flex items-center px-2.5 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg ${
                        log.status === 'Success' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                      }`}>
                         {log.status}
                      </span>
                   </td>
                 </tr>
               )})}
             </tbody>
           </table>
         </div>
      </div>
    </div>
  );
}
