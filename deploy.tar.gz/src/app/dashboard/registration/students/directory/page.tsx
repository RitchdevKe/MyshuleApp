"use client";

import React, { useState } from "react";
import {
  Search, Plus, MoreHorizontal, Eye, MessageSquare, Phone,
  Building2, GraduationCap, ChevronLeft, ChevronRight,
  LayoutGrid, List, SlidersHorizontal, CheckCircle2, AlertTriangle,
  XCircle, Sparkles, X, Save, Lock, Pencil, Shield, User,
  CalendarDays, Users, ChevronDown
} from "lucide-react";

// ── Role definitions ──────────────────────────────────────────────────────────
type UserRole = "admin" | "teacher" | "secretary";

const ROLE_PERMISSIONS: Record<UserRole, {
  canEditName: boolean;
  canEditGrade: boolean;
  canEditStatus: boolean;
  canEditParent: boolean;
  canEditPhone: boolean;
  canEditBranch: boolean;
  canDelete: boolean;
}> = {
  admin:     { canEditName: true,  canEditGrade: true,  canEditStatus: true,  canEditParent: true,  canEditPhone: true,  canEditBranch: true,  canDelete: true  },
  secretary: { canEditName: true,  canEditGrade: false, canEditStatus: false, canEditParent: true,  canEditPhone: true,  canEditBranch: false, canDelete: false },
  teacher:   { canEditName: false, canEditGrade: false, canEditStatus: false, canEditParent: false, canEditPhone: false, canEditBranch: false, canDelete: false },
};

// ── Student data ──────────────────────────────────────────────────────────────
interface Student {
  id: string;
  name: string;
  initials: string;
  grade: string;
  stream: string;
  branch: string;
  status: "Active" | "Suspended" | "Warning";
  attendance: number;
  phone: string;
  parent: string;
  joined: string;
  dob?: string;
  gender?: "Male" | "Female";
  nemisNo?: string;
}

const INITIAL_STUDENTS: Student[] = [
  { id: "STD-2601", name: "John Kamau",    initials: "JK",  grade: "Grade 4", stream: "East",  branch: "Main Campus", status: "Active",    attendance: 95, phone: "0712 345 678", parent: "Peter Kamau",    joined: "Jan 2023", dob: "2016-03-14", gender: "Male",   nemisNo: "NEM-2601" },
  { id: "STD-2602", name: "Mary Wanjiku",  initials: "MW",  grade: "Grade 1", stream: "A",     branch: "Main Campus", status: "Active",    attendance: 88, phone: "0723 456 789", parent: "Grace Wanjiku",  joined: "Jan 2026", dob: "2019-08-22", gender: "Female", nemisNo: "NEM-2602" },
  { id: "STD-2603", name: "David Ochieng", initials: "DO",  grade: "Form 2",  stream: "West",  branch: "West Wing",   status: "Suspended", attendance: 65, phone: "0734 567 890", parent: "Jane Ochieng",   joined: "Jan 2025", dob: "2011-11-05", gender: "Male",   nemisNo: "NEM-2603" },
  { id: "STD-2604", name: "Sarah Mutiso",  initials: "SM",  grade: "Grade 3", stream: "North", branch: "Main Campus", status: "Active",    attendance: 98, phone: "0745 678 901", parent: "Paul Mutiso",    joined: "Jan 2024", dob: "2017-06-30", gender: "Female", nemisNo: "NEM-2604" },
  { id: "STD-2605", name: "Kevin Kiprop",  initials: "KK",  grade: "Grade 5", stream: "South", branch: "West Wing",   status: "Active",    attendance: 92, phone: "0756 789 012", parent: "Alice Kiprop",   joined: "Jan 2022", dob: "2015-01-18", gender: "Male",   nemisNo: "NEM-2605" },
  { id: "STD-2606", name: "Faith Njeri",   initials: "FN",  grade: "Grade 2", stream: "B",     branch: "Main Campus", status: "Active",    attendance: 90, phone: "0767 890 123", parent: "Joseph Njeri",   joined: "Jan 2025", dob: "2018-04-09", gender: "Female", nemisNo: "NEM-2606" },
  { id: "STD-2607", name: "Brian Otieno",  initials: "BO",  grade: "Form 3",  stream: "East",  branch: "West Wing",   status: "Active",    attendance: 87, phone: "0778 901 234", parent: "Ruth Otieno",    joined: "Jan 2024", dob: "2010-09-25", gender: "Male",   nemisNo: "NEM-2607" },
  { id: "STD-2608", name: "Amina Hassan",  initials: "AH",  grade: "Pre-Primary", stream: "Pp1", branch: "Main Campus", status: "Active",  attendance: 96, phone: "0789 012 345", parent: "Hassan Yusuf",   joined: "Jan 2026", dob: "2020-12-03", gender: "Female", nemisNo: "NEM-2608" },
  { id: "STD-2609", name: "Liam Omondi",   initials: "LO",  grade: "Grade 6", stream: "West",  branch: "Main Campus", status: "Warning",   attendance: 72, phone: "0700 123 456", parent: "Jane Omondi",    joined: "Jan 2021", dob: "2014-07-16", gender: "Male",   nemisNo: "NEM-2609" },
  { id: "STD-2610", name: "Esther Achieng",initials: "EA",  grade: "Form 1",  stream: "South", branch: "West Wing",   status: "Active",    attendance: 93, phone: "0711 234 567", parent: "Mark Achieng",   joined: "Jan 2026", dob: "2013-02-28", gender: "Female", nemisNo: "NEM-2610" },
  { id: "STD-2611", name: "Moses Wekesa",  initials: "MoW", grade: "Grade 7", stream: "North", branch: "Main Campus", status: "Active",    attendance: 89, phone: "0722 345 678", parent: "David Wekesa",   joined: "Jan 2020", dob: "2013-10-11", gender: "Male",   nemisNo: "NEM-2611" },
  { id: "STD-2612", name: "Diana Moraa",   initials: "DM",  grade: "Form 4",  stream: "East",  branch: "West Wing",   status: "Active",    attendance: 97, phone: "0733 456 789", parent: "Simon Moraa",    joined: "Jan 2023", dob: "2008-05-20", gender: "Female", nemisNo: "NEM-2612" },
];

const avatarGrads = [
  "from-primary-700 to-primary-900", "from-secondary-500 to-secondary-700",
  "from-indigo-500 to-violet-600",   "from-emerald-500 to-teal-600",
  "from-amber-500 to-orange-500",    "from-sky-500 to-blue-600",
  "from-pink-500 to-rose-600",       "from-cyan-500 to-blue-500",
];

const statusConfig = {
  Active:    { pill: "bg-emerald-50 text-emerald-700 border-emerald-200", icon: CheckCircle2, dot: "bg-emerald-500" },
  Suspended: { pill: "bg-rose-50 text-rose-700 border-rose-200",          icon: XCircle,     dot: "bg-rose-500" },
  Warning:   { pill: "bg-amber-50 text-amber-700 border-amber-200",       icon: AlertTriangle, dot: "bg-amber-500" },
};

const STATUSES   = ["All", "Active", "Warning", "Suspended"];
const GRADES_OPT = ["All Grades", "Pre-Primary", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Form 1", "Form 2", "Form 3", "Form 4"];
const GRADE_LIST = GRADES_OPT.slice(1);
const STREAMS    = ["A", "B", "East", "West", "North", "South", "Pp1", "Pp2"];
const BRANCHES   = ["Main Campus", "West Wing"];
const STATUS_LIST: ("Active" | "Suspended" | "Warning")[] = ["Active", "Warning", "Suspended"];

// ── Locked field component ────────────────────────────────────────────────────
function LockedField({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <label className="flex items-center gap-1 text-[10px] font-black text-slate-400 uppercase tracking-wider mb-1">
        <Lock className="w-2.5 h-2.5" /> {label}
      </label>
      <div className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-400 cursor-not-allowed">
        {value}
      </div>
    </div>
  );
}

// ── Edit drawer ───────────────────────────────────────────────────────────────
function EditStudentDrawer({
  student,
  role,
  avatarIdx,
  onSave,
  onClose,
}: {
  student: Student;
  role: UserRole;
  avatarIdx: number;
  onSave: (updated: Student) => void;
  onClose: () => void;
}) {
  const [form, setForm] = useState<Student>({ ...student });
  const perms = ROLE_PERMISSIONS[role];

  const field = (key: keyof Student, value: string) =>
    setForm(prev => ({ ...prev, [key]: value }));

  const roleLabel = { admin: "Administrator", secretary: "Secretary", teacher: "Class Teacher" }[role];
  const roleColor = { admin: "bg-emerald-100 text-emerald-700", secretary: "bg-sky-100 text-sky-700", teacher: "bg-amber-100 text-amber-700" }[role];

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div className="flex-1 bg-primary-950/50 backdrop-blur-sm" onClick={onClose} />

      {/* Drawer */}
      <div className="w-full max-w-lg bg-white h-full flex flex-col shadow-2xl overflow-y-auto animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="bg-gradient-to-r from-primary-900 to-primary-700 px-6 py-5 flex-shrink-0">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${avatarGrads[avatarIdx % avatarGrads.length]} flex items-center justify-center text-white font-black text-sm shadow-lg`}>
                {student.initials}
              </div>
              <div>
                <p className="text-xs font-black text-white/50 uppercase tracking-wider">Editing Student</p>
                <h2 className="text-lg font-black text-white leading-tight">{student.name}</h2>
                <p className="text-[11px] text-white/60 font-bold">{student.id} · {student.nemisNo}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Role badge */}
          <div className="flex items-center gap-2">
            <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-black ${roleColor}`}>
              <Shield className="w-3 h-3" />
              {roleLabel} Access
            </div>
            {!perms.canEditGrade && (
              <p className="text-[10px] text-white/50 font-bold">
                Some fields are read-only for your role
              </p>
            )}
          </div>
        </div>

        {/* Form body */}
        <div className="flex-1 p-6 space-y-5 overflow-y-auto">

          {/* Personal Info section */}
          <div>
            <p className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3">
              <User className="w-3 h-3" /> Personal Information
            </p>
            <div className="space-y-3">
              {perms.canEditName ? (
                <div>
                  <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Full Name *</label>
                  <input
                    value={form.name}
                    onChange={e => field("name", e.target.value)}
                    className="w-full px-3 py-2 text-sm font-bold border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-300 focus:border-primary-300 transition-all"
                  />
                </div>
              ) : (
                <LockedField label="Full Name" value={form.name} />
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Gender</label>
                  {perms.canEditName ? (
                    <div className="relative">
                      <select
                        value={form.gender ?? "Male"}
                        onChange={e => field("gender", e.target.value)}
                        className="w-full appearance-none px-3 py-2 text-sm font-bold border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-300 bg-white transition-all pr-8"
                      >
                        <option>Male</option>
                        <option>Female</option>
                      </select>
                      <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400 pointer-events-none" />
                    </div>
                  ) : (
                    <LockedField label="" value={form.gender ?? "—"} />
                  )}
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Date of Birth</label>
                  {perms.canEditName ? (
                    <input
                      type="date"
                      value={form.dob ?? ""}
                      onChange={e => field("dob", e.target.value)}
                      className="w-full px-3 py-2 text-sm font-bold border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-300 transition-all"
                    />
                  ) : (
                    <LockedField label="" value={form.dob ?? "—"} />
                  )}
                </div>
              </div>
              <LockedField label="NEMIS Number" value={form.nemisNo ?? "—"} />
            </div>
          </div>

          {/* Academic section */}
          <div className="border-t border-slate-100 pt-5">
            <p className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3">
              <GraduationCap className="w-3 h-3" /> Academic Placement
            </p>
            <div className="grid grid-cols-2 gap-3">
              {perms.canEditGrade ? (
                <>
                  <div>
                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Grade *</label>
                    <div className="relative">
                      <select
                        value={form.grade}
                        onChange={e => field("grade", e.target.value)}
                        className="w-full appearance-none px-3 py-2 text-sm font-bold border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-300 bg-white transition-all pr-8"
                      >
                        {GRADE_LIST.map(g => <option key={g}>{g}</option>)}
                      </select>
                      <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400 pointer-events-none" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Stream *</label>
                    <div className="relative">
                      <select
                        value={form.stream}
                        onChange={e => field("stream", e.target.value)}
                        className="w-full appearance-none px-3 py-2 text-sm font-bold border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-300 bg-white transition-all pr-8"
                      >
                        {STREAMS.map(s => <option key={s}>{s}</option>)}
                      </select>
                      <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400 pointer-events-none" />
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <LockedField label="Grade" value={form.grade} />
                  <LockedField label="Stream" value={form.stream} />
                </>
              )}

              {perms.canEditBranch ? (
                <div>
                  <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Branch *</label>
                  <div className="relative">
                    <select
                      value={form.branch}
                      onChange={e => field("branch", e.target.value)}
                      className="w-full appearance-none px-3 py-2 text-sm font-bold border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-300 bg-white transition-all pr-8"
                    >
                      {BRANCHES.map(b => <option key={b}>{b}</option>)}
                    </select>
                    <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400 pointer-events-none" />
                  </div>
                </div>
              ) : (
                <LockedField label="Branch" value={form.branch} />
              )}

              {perms.canEditStatus ? (
                <div>
                  <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Status *</label>
                  <div className="relative">
                    <select
                      value={form.status}
                      onChange={e => field("status", e.target.value as Student["status"])}
                      className="w-full appearance-none px-3 py-2 text-sm font-bold border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-300 bg-white transition-all pr-8"
                    >
                      {STATUS_LIST.map(s => <option key={s}>{s}</option>)}
                    </select>
                    <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400 pointer-events-none" />
                  </div>
                </div>
              ) : (
                <LockedField label="Status" value={form.status} />
              )}
            </div>
          </div>

          {/* Parent / Contact section */}
          <div className="border-t border-slate-100 pt-5">
            <p className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3">
              <Users className="w-3 h-3" /> Parent / Guardian
            </p>
            <div className="space-y-3">
              {perms.canEditParent ? (
                <div>
                  <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Parent Name *</label>
                  <input
                    value={form.parent}
                    onChange={e => field("parent", e.target.value)}
                    className="w-full px-3 py-2 text-sm font-bold border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-300 transition-all"
                  />
                </div>
              ) : (
                <LockedField label="Parent Name" value={form.parent} />
              )}
              {perms.canEditPhone ? (
                <div>
                  <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Phone *</label>
                  <input
                    value={form.phone}
                    onChange={e => field("phone", e.target.value)}
                    className="w-full px-3 py-2 text-sm font-bold border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-300 transition-all"
                  />
                </div>
              ) : (
                <LockedField label="Phone" value={form.phone} />
              )}
            </div>
          </div>

          {/* Read-only meta */}
          <div className="border-t border-slate-100 pt-5">
            <p className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3">
              <CalendarDays className="w-3 h-3" /> System Record
            </p>
            <div className="grid grid-cols-2 gap-3">
              <LockedField label="Student ID" value={form.id} />
              <LockedField label="Joined" value={form.joined} />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex-shrink-0 border-t border-slate-100 px-6 py-4 bg-slate-50/80 flex items-center justify-between gap-3">
          {perms.canDelete && (
            <button className="text-xs font-black text-rose-500 hover:text-rose-700 hover:bg-rose-50 px-3 py-2 rounded-xl transition-colors">
              Delete Student
            </button>
          )}
          <div className="flex items-center gap-2 ml-auto">
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm font-black text-slate-600 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              id="save-student-btn"
              onClick={() => onSave(form)}
              className="flex items-center gap-2 px-5 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all"
            >
              <Save className="w-4 h-4" /> Save Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function DirectoryPage() {
  const [students, setStudents] = useState<Student[]>(INITIAL_STUDENTS);
  const [search,   setSearch]   = useState("");
  const [status,   setStatus]   = useState("All");
  const [grade,    setGrade]    = useState("All Grades");
  const [viewMode, setViewMode] = useState<"grid" | "list">("list");

  // Edit state
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [editingIdx,     setEditingIdx]     = useState(0);

  // For demo: simulate the logged-in user's role
  const [currentRole, setCurrentRole] = useState<UserRole>("admin");

  const filtered = students.filter(s => {
    const matchSearch = !search || s.name.toLowerCase().includes(search.toLowerCase()) || s.id.toLowerCase().includes(search.toLowerCase());
    const matchStatus = status === "All" || s.status === status;
    const matchGrade  = grade === "All Grades" || s.grade === grade;
    return matchSearch && matchStatus && matchGrade;
  });

  function openEdit(s: Student, i: number) {
    setEditingStudent(s);
    setEditingIdx(i);
  }

  function handleSave(updated: Student) {
    setStudents(prev => prev.map(s => s.id === updated.id ? updated : s));
    setEditingStudent(null);
  }

  return (
    <div className="space-y-4">
      {/* Demo role switcher — would be removed in production, replaced by auth */}
      <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 rounded-xl px-4 py-2.5 text-xs">
        <Shield className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />
        <span className="font-bold text-amber-700">Demo: Viewing as</span>
        {(["admin", "secretary", "teacher"] as UserRole[]).map(r => (
          <button
            key={r}
            onClick={() => setCurrentRole(r)}
            className={`px-2.5 py-1 rounded-lg font-black text-[11px] capitalize transition-colors ${
              currentRole === r ? "bg-amber-500 text-white" : "bg-white text-amber-700 border border-amber-200 hover:bg-amber-100"
            }`}
          >
            {r}
          </button>
        ))}
        <span className="ml-2 text-amber-600 font-bold">
          {currentRole === "admin"     ? "Full edit access" :
           currentRole === "secretary" ? "Can edit contact & name, not grade/status" :
           "Read-only — click Edit to see locked fields"}
        </span>
      </div>

      {/* Main card */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden flex flex-col min-h-[600px]">
        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search students..."
              className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-64 placeholder:text-slate-400"
            />
          </div>

          <div className="flex gap-2 flex-wrap items-center">
            {/* Status filters */}
            <div className="flex gap-1.5 p-1 bg-slate-100 rounded-xl">
              {STATUSES.map(s => (
                <button
                  key={s}
                  onClick={() => setStatus(s)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${
                    status === s ? "bg-white text-primary-900 shadow-sm" : "text-slate-500 hover:text-slate-700"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>

            {/* Grade select */}
            <select
              value={grade}
              onChange={e => setGrade(e.target.value)}
              className="px-3 py-2 text-sm font-bold text-slate-700 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 shadow-sm"
            >
              {GRADES_OPT.map(g => <option key={g}>{g}</option>)}
            </select>

            {/* View Toggle */}
            <div className="flex bg-slate-100 p-1 rounded-xl gap-1">
              <button onClick={() => setViewMode("grid")} className={`p-1.5 rounded-lg transition-colors ${viewMode === "grid" ? "bg-white shadow-sm text-primary-900" : "text-slate-400 hover:text-slate-600"}`}>
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button onClick={() => setViewMode("list")} className={`p-1.5 rounded-lg transition-colors ${viewMode === "list" ? "bg-white shadow-sm text-primary-900" : "text-slate-400 hover:text-slate-600"}`}>
                <List className="w-4 h-4" />
              </button>
            </div>

            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm">
              <SlidersHorizontal className="w-4 h-4" /> Filter
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all">
              <Plus className="w-4 h-4" /> Add Student
            </button>
          </div>
        </div>

        {/* ── GRID VIEW ── */}
        {viewMode === "grid" && (
          <div className="flex-1 p-5 overflow-y-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filtered.map((student, i) => {
                const cfg = statusConfig[student.status];
                const StatusIcon = cfg.icon;
                const attColor = student.attendance >= 90 ? "bg-emerald-500" : student.attendance >= 75 ? "bg-amber-500" : "bg-rose-500";
                const origIdx = students.findIndex(s => s.id === student.id);
                return (
                  <div
                    key={student.id}
                    className="bg-white/80 backdrop-blur-xl border border-slate-200 rounded-3xl shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden group cursor-pointer"
                  >
                    <div className="h-1 w-full bg-slate-100">
                      <div className={`h-full ${attColor} rounded-full`} style={{ width: `${student.attendance}%` }} />
                    </div>
                    <div className="p-5 relative">
                      <div className="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-slate-400 hover:text-primary-700 hover:bg-primary-50 rounded-lg transition-colors">
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => openEdit(student, origIdx)}
                          className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <div className="flex items-center gap-3 mb-4">
                        <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${avatarGrads[origIdx % avatarGrads.length]} flex items-center justify-center text-white font-black text-base shadow-md flex-shrink-0`}>
                          {student.initials}
                        </div>
                        <div>
                          <h3 className="font-black text-slate-800 text-sm leading-tight">{student.name}</h3>
                          <p className="text-[10px] font-black text-slate-400 mt-0.5">{student.id}</p>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1.5 mb-4">
                        <span className="flex items-center gap-1 px-2 py-1 bg-slate-100 text-slate-600 rounded-lg text-[10px] font-black border border-slate-200">
                          <GraduationCap className="w-2.5 h-2.5" />{student.grade} · {student.stream}
                        </span>
                        <span className="flex items-center gap-1 px-2 py-1 bg-slate-100 text-slate-600 rounded-lg text-[10px] font-black border border-slate-200">
                          <Building2 className="w-2.5 h-2.5" />{student.branch}
                        </span>
                      </div>
                      <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                        <div className="flex gap-1.5">
                          <button className="p-1.5 bg-primary-50 text-primary-600 hover:bg-primary-100 rounded-lg transition-colors border border-primary-100">
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>
                          <button className="p-1.5 bg-secondary-50 text-secondary-600 hover:bg-secondary-100 rounded-lg transition-colors border border-secondary-100">
                            <Phone className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-black text-slate-400">{student.attendance}%</span>
                          <span className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-black border ${cfg.pill}`}>
                            <StatusIcon className="w-2.5 h-2.5" />{student.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── LIST VIEW ── */}
        {viewMode === "list" && (
          <div className="flex-1 overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="bg-gradient-to-r from-primary-900 to-primary-800 text-white">
                  <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Student</th>
                  <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">ID</th>
                  <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Grade</th>
                  <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Parent</th>
                  <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Branch</th>
                  <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Attendance</th>
                  <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Status</th>
                  <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((s, i) => {
                  const cfg = statusConfig[s.status];
                  const StatusIcon = cfg.icon;
                  const attColor = s.attendance >= 90 ? "bg-emerald-500" : s.attendance >= 75 ? "bg-amber-500" : "bg-rose-500";
                  const origIdx = students.findIndex(st => st.id === s.id);
                  return (
                    <tr key={s.id} className="hover:bg-primary-50/40 border-l-4 border-transparent hover:border-l-secondary-500 transition-all group">
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${avatarGrads[origIdx % avatarGrads.length]} flex items-center justify-center text-white text-[10px] font-black shadow-sm flex-shrink-0`}>
                            {s.initials}
                          </div>
                          <div>
                            <p className="font-bold text-slate-800 text-sm">{s.name}</p>
                            <p className="text-[10px] font-bold text-slate-400">Since {s.joined}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="text-xs font-black text-primary-900 bg-primary-50 border border-primary-100 px-2 py-1 rounded-lg">{s.id}</span>
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="text-xs font-bold text-slate-700 bg-slate-100 border border-slate-200 px-2 py-1 rounded-lg flex items-center gap-1 w-fit">
                          <GraduationCap className="w-3 h-3 text-slate-400" />{s.grade} {s.stream}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-xs font-bold text-slate-600">{s.parent}</td>
                      <td className="px-5 py-3.5 text-xs font-bold text-slate-500">{s.branch}</td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-2">
                          <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                            <div className={`h-full ${attColor} rounded-full`} style={{ width: `${s.attendance}%` }} />
                          </div>
                          <span className="text-xs font-black text-slate-600">{s.attendance}%</span>
                        </div>
                      </td>
                      <td className="px-5 py-3.5">
                        <span className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-black border w-fit ${cfg.pill}`}>
                          <StatusIcon className="w-3 h-3" />{s.status}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button className="p-1.5 text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            id={`edit-student-${s.id}`}
                            onClick={() => openEdit(s, origIdx)}
                            className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button className="p-1.5 text-secondary-600 hover:bg-secondary-50 rounded-lg transition-colors">
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>
                          <button className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                            <MoreHorizontal className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Empty state */}
        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-slate-400">
            <Sparkles className="w-12 h-12 mb-3 opacity-20" />
            <p className="font-bold text-lg text-slate-500">No students found</p>
          </div>
        )}

        {/* Pagination */}
        <div className="px-5 py-3.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/60 mt-auto">
          <span className="font-bold">Showing <span className="text-primary-900">{filtered.length}</span> of {students.length} students</span>
          <div className="flex items-center gap-1">
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg hover:bg-slate-50 disabled:opacity-40 font-bold" disabled>
              <ChevronLeft className="w-3.5 h-3.5" /> Prev
            </button>
            <button className="w-8 h-8 flex items-center justify-center rounded-lg bg-primary-900 text-white text-xs font-black">1</button>
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg hover:bg-slate-50 font-bold">
              Next <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Edit Drawer */}
      {editingStudent && (
        <EditStudentDrawer
          student={editingStudent}
          role={currentRole}
          avatarIdx={editingIdx}
          onSave={handleSave}
          onClose={() => setEditingStudent(null)}
        />
      )}
    </div>
  );
}