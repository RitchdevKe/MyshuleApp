"use client";
import React, { useState } from "react";
import { CheckCircle2, Search, Filter } from "lucide-react";

export default function DailyAttendanceTab() {
  const [students, setStudents] = useState([
    { id: "ADM-2023-001", name: "John Kamau", status: "Present" },
    { id: "ADM-2023-042", name: "Mary Wanjiku", status: "Present" },
    { id: "ADM-2023-112", name: "Peter Otieno", status: "Late" },
    { id: "ADM-2023-087", name: "Brian Mwangi", status: "Absent" },
    { id: "ADM-2023-091", name: "Grace Omondi", status: "Excused" },
  ]);

  const handleStatusChange = (id: string, newStatus: string) => {
    setStudents(students.map(s => s.id === id ? { ...s, status: newStatus } : s));
  };

  const markAllPresent = () => {
    setStudents(students.map(s => ({ ...s, status: "Present" })));
  };

  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 bg-white/40 p-4 rounded-3xl border border-white/60 backdrop-blur-md shadow-sm">
        <div>
          <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
            <CheckCircle2 className="w-6 h-6 text-indigo-500" /> Grade 8A — Today's Students
          </h2>
          <p className="text-sm font-bold text-slate-500 mt-1">Teacher: Mr. Omondi • Date: Sept 12</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search student..." 
              className="pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold focus:outline-none focus:border-indigo-500 shadow-sm w-48"
            />
          </div>
          
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl shadow-sm hover:bg-slate-50 transition-colors">
            <Filter className="w-4 h-4" /> Filter
          </button>
          
          <button 
            onClick={markAllPresent}
            className="px-4 py-2 text-sm font-bold text-white bg-emerald-500 rounded-xl shadow-sm shadow-emerald-500/20 hover:bg-emerald-600 transition-colors"
          >
            Mark All Present
          </button>
        </div>
      </div>
      
      <div className="bg-white/60 backdrop-blur-md border border-white rounded-3xl overflow-hidden shadow-sm">
        <div className="divide-y divide-slate-100/60">
          {students.map((student) => (
            <div key={student.id} className="p-5 flex items-center justify-between hover:bg-white/80 transition-colors group">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-black text-lg border border-indigo-100/50 shadow-sm">
                  {student.name.charAt(0)}
                </div>
                <div>
                  <div className="font-black text-slate-800 text-base">{student.name}</div>
                  <div className="text-xs font-bold text-slate-400">{student.id}</div>
                </div>
              </div>
              
              <div className="flex bg-slate-100/50 p-1.5 rounded-2xl border border-slate-200/50">
                <button 
                  onClick={() => handleStatusChange(student.id, "Present")}
                  className={`px-4 py-2 text-xs font-black uppercase tracking-wider rounded-xl transition-all duration-300 ${
                    student.status === 'Present' 
                    ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/30' 
                    : 'text-slate-500 hover:bg-white hover:text-slate-800 hover:shadow-sm'
                  }`}
                >
                  Present
                </button>
                <button 
                  onClick={() => handleStatusChange(student.id, "Absent")}
                  className={`px-4 py-2 text-xs font-black uppercase tracking-wider rounded-xl transition-all duration-300 ${
                    student.status === 'Absent' 
                    ? 'bg-rose-500 text-white shadow-md shadow-rose-500/30' 
                    : 'text-slate-500 hover:bg-white hover:text-slate-800 hover:shadow-sm'
                  }`}
                >
                  Absent
                </button>
                <button 
                  onClick={() => handleStatusChange(student.id, "Late")}
                  className={`px-4 py-2 text-xs font-black uppercase tracking-wider rounded-xl transition-all duration-300 ${
                    student.status === 'Late' 
                    ? 'bg-amber-500 text-white shadow-md shadow-amber-500/30' 
                    : 'text-slate-500 hover:bg-white hover:text-slate-800 hover:shadow-sm'
                  }`}
                >
                  Late
                </button>
                <button 
                  onClick={() => handleStatusChange(student.id, "Excused")}
                  className={`px-4 py-2 text-xs font-black uppercase tracking-wider rounded-xl transition-all duration-300 ${
                    student.status === 'Excused' 
                    ? 'bg-indigo-500 text-white shadow-md shadow-indigo-500/30' 
                    : 'text-slate-500 hover:bg-white hover:text-slate-800 hover:shadow-sm'
                  }`}
                >
                  Excused
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
