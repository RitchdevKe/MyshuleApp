"use client";

import React from "react";
import { FileMinus, Plus, ShieldAlert, Activity, CreditCard, Users, Settings } from "lucide-react";

export default function DeductionsPage() {
  const rules = [
    { id: "DED-PAYE", name: "PAYE (Income Tax)", type: "Statutory", rate: "Tiered (10% - 30%)", icon: ShieldAlert, color: "text-rose-600", bg: "bg-rose-50", active: true },
    { id: "DED-NHIF", name: "NHIF (Health)", type: "Statutory", rate: "Fixed (KES 150 - 1700)", icon: Activity, color: "text-emerald-600", bg: "bg-emerald-50", active: true },
    { id: "DED-NSSF", name: "NSSF (Pension)", type: "Statutory", rate: "6% of Pensionable Pay", icon: FileMinus, color: "text-blue-600", bg: "bg-blue-50", active: true },
    { id: "DED-ADV", name: "Salary Advances", type: "Custom", rate: "Variable (Recovery)", icon: CreditCard, color: "text-amber-600", bg: "bg-amber-50", active: true },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div>
           <h2 className="text-lg font-black text-slate-800">Deductions & Allowances Rules</h2>
           <p className="text-sm font-medium text-slate-500">Manage statutory requirements and custom deduction rules.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
           <Plus className="w-4 h-4" />
           New Rule
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {rules.map((rule) => {
           const Icon = rule.icon;
           return (
            <div key={rule.id} className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm hover:shadow-md transition-all group">
              <div className="flex justify-between items-start mb-4">
                <div className={`p-3 rounded-2xl ${rule.bg} ${rule.color}`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div className="flex items-center gap-2">
                   <span className={`px-2 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg ${rule.type === 'Statutory' ? 'bg-slate-100 text-slate-600' : 'bg-primary-50 text-primary-600'}`}>
                      {rule.type}
                   </span>
                </div>
              </div>
              <h3 className="font-black text-slate-800 mb-1">{rule.name}</h3>
              <p className="text-xs font-bold text-slate-400 mb-4 uppercase tracking-wider">{rule.id}</p>
              
              <div className="bg-slate-50 rounded-xl p-3 mb-4">
                 <p className="text-xs font-bold text-slate-500 mb-1">Deduction Rate</p>
                 <p className="font-bold text-slate-700 text-sm">{rule.rate}</p>
              </div>

              <div className="flex justify-between items-center pt-3 border-t border-slate-100">
                 <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${rule.active ? 'bg-emerald-500' : 'bg-slate-300'}`}></div>
                    <span className="text-xs font-bold text-slate-500">{rule.active ? 'Active Rule' : 'Inactive'}</span>
                 </div>
                 <button className="text-slate-400 hover:text-primary-900 transition-colors">
                    <Settings className="w-4 h-4" />
                 </button>
              </div>
            </div>
           );
        })}
      </div>

      {/* Impacted Employees Section */}
      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200/60 flex justify-between items-center bg-slate-50/50">
           <h3 className="font-black text-slate-800 flex items-center gap-2"><Users className="w-5 h-5 text-slate-400"/> Recent Custom Deductions (Advances)</h3>
           <button className="text-sm font-bold text-primary-600 hover:text-primary-800">View All</button>
        </div>
        <div className="p-0">
          <table className="w-full text-left border-collapse">
             <thead>
               <tr className="border-b border-slate-100">
                  <th className="py-3 px-5 text-xs font-bold text-slate-400 uppercase tracking-wider">Employee</th>
                  <th className="py-3 px-5 text-xs font-bold text-slate-400 uppercase tracking-wider">Amount</th>
                  <th className="py-3 px-5 text-xs font-bold text-slate-400 uppercase tracking-wider">Installments</th>
                  <th className="py-3 px-5 text-xs font-bold text-slate-400 uppercase tracking-wider">Status</th>
               </tr>
             </thead>
             <tbody className="divide-y divide-slate-100">
               <tr className="hover:bg-slate-50/50 transition-colors">
                  <td className="py-3 px-5 font-bold text-slate-700 text-sm">Michael Ochieng</td>
                  <td className="py-3 px-5 font-bold text-slate-700 text-sm">$500.00</td>
                  <td className="py-3 px-5 font-medium text-slate-500 text-sm">2 of 5</td>
                  <td className="py-3 px-5"><span className="px-2 py-1 bg-amber-50 text-amber-600 text-xs font-bold rounded-lg">Recovering</span></td>
               </tr>
               <tr className="hover:bg-slate-50/50 transition-colors">
                  <td className="py-3 px-5 font-bold text-slate-700 text-sm">David Kim</td>
                  <td className="py-3 px-5 font-bold text-slate-700 text-sm">$1,200.00</td>
                  <td className="py-3 px-5 font-medium text-slate-500 text-sm">12 of 12</td>
                  <td className="py-3 px-5"><span className="px-2 py-1 bg-emerald-50 text-emerald-600 text-xs font-bold rounded-lg">Cleared</span></td>
               </tr>
             </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
