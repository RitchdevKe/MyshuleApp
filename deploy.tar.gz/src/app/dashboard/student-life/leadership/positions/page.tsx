import React from "react";
import { Award, Search, Filter, Shield, MoreVertical } from "lucide-react";

export default function LeadershipPositionsPage() {
  const positions = [
    { id: 1, title: "School Captain", category: "Executive", holder: "John Kamau", grade: "Grade 11A", term: "2025 - 2026", status: "Active" },
    { id: 2, title: "Deputy Captain", category: "Executive", holder: "Mary Wanjiku", grade: "Grade 11B", term: "2025 - 2026", status: "Active" },
    { id: 3, title: "Sports Captain", category: "Sports", holder: "Peter Otieno", grade: "Grade 11C", term: "2025 - 2026", status: "Active" },
    { id: 4, title: "Welfare Captain", category: "Welfare", holder: "Jane Doe", grade: "Grade 10A", term: "2025 - 2026", status: "Active" },
    { id: 5, title: "Library Prefect", category: "Academic", holder: "David Ochieng", grade: "Grade 10B", term: "2025 - 2026", status: "Active" },
    { id: 6, title: "Dining Hall Prefect", category: "Welfare", holder: "Sarah Hassan", grade: "Grade 11A", term: "2025 - 2026", status: "Active" },
  ];

  return (
    <div className="p-6">
      
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search positions or students..." 
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-secondary-500/20 focus:border-secondary-500 transition-all shadow-sm"
          />
        </div>
        
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors shadow-sm">
            <Filter className="w-4 h-4" /> Filter
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-white bg-primary-900 rounded-xl hover:bg-primary-800 transition-colors shadow-sm">
            <Award className="w-4 h-4" /> Add Position
          </button>
        </div>
      </div>

      {/* Positions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {positions.map((pos) => (
          <div key={pos.id} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-shadow group relative">
            <button className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors opacity-0 group-hover:opacity-100">
              <MoreVertical className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-xl bg-primary-50 flex items-center justify-center text-primary-900 shadow-inner">
                <Shield className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-secondary-500 bg-secondary-50 px-2 py-0.5 rounded-full mb-1 inline-block">
                  {pos.category}
                </span>
                <h3 className="font-bold text-slate-800">{pos.title}</h3>
              </div>
            </div>

            <div className="space-y-3 pt-4 border-t border-slate-100">
              <div>
                <div className="text-xs font-medium text-slate-500 mb-0.5">Current Holder</div>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-[10px] font-bold text-slate-600">
                    {pos.holder.charAt(0)}
                  </div>
                  <span className="text-sm font-bold text-slate-800">{pos.holder}</span>
                  <span className="text-xs text-slate-500">({pos.grade})</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-medium text-slate-500 mb-0.5">Term</div>
                  <div className="text-sm font-bold text-slate-700">{pos.term}</div>
                </div>
                <span className="px-2.5 py-1 bg-green-50 text-green-700 text-xs font-bold rounded-lg border border-green-200">
                  {pos.status}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
}
