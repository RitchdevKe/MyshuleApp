import React from "react";
import { Vote, Users, Search, Play, CheckCircle2, AlertCircle } from "lucide-react";

export default function LeadershipElectionsPage() {
  const elections = [
    { id: 1, title: "2026 Prefect Elections", status: "Live", date: "Oct 24, 2025", voters: 850, turnout: 68 },
    { id: 2, title: "Club Leadership 2025", status: "Upcoming", date: "Nov 15, 2025", voters: 420, turnout: 0 },
    { id: 3, title: "2025 School Captain", status: "Completed", date: "Jan 10, 2025", voters: 1200, turnout: 92 },
  ];

  return (
    <div className="p-6">
      
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search elections..." 
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-secondary-500/20 focus:border-secondary-500 transition-all shadow-sm"
          />
        </div>
        
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-white bg-secondary-500 rounded-xl hover:bg-secondary-600 transition-colors shadow-sm">
            <Vote className="w-4 h-4" /> Create Election
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {elections.map((election) => (
          <div key={election.id} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-shadow flex flex-col">
            
            <div className="flex justify-between items-start mb-4">
              <div className="w-12 h-12 rounded-xl bg-primary-50 flex items-center justify-center text-primary-900 shadow-inner">
                <Vote className="w-6 h-6" />
              </div>
              
              {election.status === 'Live' && (
                <span className="flex items-center gap-1.5 px-2.5 py-1 bg-secondary-50 text-secondary-600 text-[10px] font-black uppercase tracking-wider rounded-lg border border-secondary-200">
                  <Play className="w-3 h-3" /> Live
                </span>
              )}
              {election.status === 'Upcoming' && (
                <span className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-50 text-amber-600 text-[10px] font-black uppercase tracking-wider rounded-lg border border-amber-200">
                  <AlertCircle className="w-3 h-3" /> Upcoming
                </span>
              )}
              {election.status === 'Completed' && (
                <span className="flex items-center gap-1.5 px-2.5 py-1 bg-green-50 text-green-700 text-[10px] font-black uppercase tracking-wider rounded-lg border border-green-200">
                  <CheckCircle2 className="w-3 h-3" /> Completed
                </span>
              )}
            </div>

            <h3 className="font-black text-lg text-slate-800 mb-1">{election.title}</h3>
            <p className="text-sm font-medium text-slate-500 mb-4">{election.date}</p>

            <div className="mt-auto space-y-4 pt-4 border-t border-slate-100">
              <div className="flex justify-between text-xs font-bold text-slate-600">
                <span className="flex items-center gap-1.5"><Users className="w-3.5 h-3.5"/> {election.voters} Eligible</span>
                <span>{election.turnout}% Turnout</span>
              </div>
              
              {election.turnout > 0 && (
                <div className="w-full bg-slate-100 rounded-full h-2">
                  <div className={`h-2 rounded-full ${election.status === 'Live' ? 'bg-secondary-500' : 'bg-primary-500'}`} style={{ width: `${election.turnout}%` }}></div>
                </div>
              )}

              <div className="flex gap-2">
                <button className="flex-1 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 transition-colors">
                  View Candidates
                </button>
                <button className="flex-1 py-2 bg-primary-900 hover:bg-primary-800 text-white text-xs font-bold rounded-xl border border-primary-900 transition-colors">
                  {election.status === 'Completed' ? 'Results' : 'Manage'}
                </button>
              </div>
            </div>
            
          </div>
        ))}
      </div>

    </div>
  );
}
