"use client";

import React, { useState } from "react";
import {
  Search, Plus, MoreHorizontal, Eye, Mail, Phone,
  MessageSquare, ChevronLeft, ChevronRight, Link2,
  CheckCircle2, XCircle, SlidersHorizontal, GraduationCap
} from "lucide-react";

const PARENTS = [
  { id: "PRT-001", name: "Alice Mwangangi",  initials: "AM", phone: "+254 712 345 678", email: "alice.m@gmail.com",       students: ["John Kamau · Gr 4", "Faith Kamau · Gr 1"], relation: "Mother", status: "Active",   joined: "Jan 2023", occupation: "Teacher" },
  { id: "PRT-002", name: "David Ochieng",    initials: "DO", phone: "+254 723 456 789", email: "dochieng@gmail.com",       students: ["Brian Ochieng · Gr 6"],                    relation: "Father", status: "Active",   joined: "Jan 2022", occupation: "Engineer" },
  { id: "PRT-003", name: "Grace Njau",       initials: "GN", phone: "+254 734 567 890", email: "grace.njau@gmail.com",     students: ["Mary Njau · Gr 2"],                        relation: "Mother", status: "Archived", joined: "Jan 2021", occupation: "Business" },
  { id: "PRT-004", name: "Paul Kiprotich",   initials: "PK", phone: "+254 745 678 901", email: "paul.k@gmail.com",         students: ["Mercy Kiprotich · Gr 5"],                  relation: "Father", status: "Active",   joined: "Jan 2024", occupation: "Doctor" },
  { id: "PRT-005", name: "Jane Omondi",      initials: "JO", phone: "+254 756 789 012", email: "jane.omondi@gmail.com",    students: ["Liam Omondi · Gr 6", "Sue Omondi · Gr 3"], relation: "Mother", status: "Active",   joined: "Jan 2020", occupation: "Nurse" },
  { id: "PRT-006", name: "Mohammed Ali",     initials: "MA", phone: "+254 767 890 123", email: "mali@gmail.com",           students: ["Fatuma Ali · Gr 6"],                        relation: "Father", status: "Active",   joined: "Jan 2023", occupation: "Accountant" },
  { id: "PRT-007", name: "Catherine Mutua",  initials: "CM", phone: "+254 778 901 234", email: "c.mutua@gmail.com",        students: ["Brian Mutua · Jnr Sec"],                   relation: "Mother", status: "Active",   joined: "Jan 2025", occupation: "Lecturer" },
  { id: "PRT-008", name: "James Wanjiru",    initials: "JW", phone: "+254 789 012 345", email: "j.wanjiru@gmail.com",      students: ["Mercy Wanjiru · Gr 4"],                    relation: "Father", status: "Active",   joined: "Jan 2024", occupation: "Pilot" },
  { id: "PRT-009", name: "Sarah Otieno",     initials: "SO", phone: "+254 700 123 456", email: "s.otieno@gmail.com",       students: ["Kevin Ochieng · Gr 2"],                    relation: "Mother", status: "Active",   joined: "Jan 2026", occupation: "Lawyer" },
  { id: "PRT-010", name: "Hassan Yusuf",     initials: "HY", phone: "+254 711 234 567", email: "hassan.y@gmail.com",       students: ["Amina Hassan · Pre-Primary"],               relation: "Father", status: "Active",   joined: "Jan 2026", occupation: "Businessman" },
];

const avatarGrads = [
  "from-primary-700 to-primary-900", "from-secondary-500 to-secondary-700",
  "from-indigo-500 to-violet-600",   "from-emerald-500 to-teal-600",
  "from-amber-500 to-orange-500",    "from-sky-500 to-blue-600",
  "from-pink-500 to-rose-600",       "from-cyan-500 to-blue-500",
  "from-lime-500 to-green-600",      "from-fuchsia-500 to-purple-600",
];

const STATUSES = ["All", "Active", "Archived"];

export default function ParentsDirectoryPage() {
  const [search, setSearch]   = useState("");
  const [statusF, setStatusF] = useState("All");

  const filtered = PARENTS.filter(p => {
    const matchSearch = !search || p.name.toLowerCase().includes(search.toLowerCase()) || p.id.toLowerCase().includes(search.toLowerCase()) || p.phone.includes(search);
    const matchStatus = statusF === "All" || p.status === statusF;
    return matchSearch && matchStatus;
  });

  return (
    <div className="space-y-4">

      {/* Summary ribbon */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "Total Parents",  value: PARENTS.length,                                    color: "from-primary-800 to-primary-900" },
          { label: "Active",         value: PARENTS.filter(p => p.status === "Active").length,  color: "from-emerald-600 to-teal-600" },
          { label: "Archived",       value: PARENTS.filter(p => p.status === "Archived").length,color: "from-slate-500 to-slate-700" },
          { label: "Students Linked",value: PARENTS.reduce((a, p) => a + p.students.length, 0), color: "from-indigo-600 to-violet-600" },
        ].map(c => (
          <div key={c.label} className={`bg-gradient-to-br ${c.color} rounded-2xl px-5 py-3.5 text-white shadow-md`}>
            <p className="text-2xl font-black">{c.value}</p>
            <p className="text-xs font-bold text-white/75">{c.label}</p>
          </div>
        ))}
      </div>

      {/* Main card */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden">

        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search by name, ID, phone..."
                className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-56 placeholder:text-slate-400"
              />
            </div>
            <div className="flex gap-1.5">
              {STATUSES.map(s => (
                <button key={s} onClick={() => setStatusF(s)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all ${statusF === s ? "bg-primary-900 text-white shadow-md shadow-primary-900/20" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}>
                  {s}
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm">
              <Mail className="w-4 h-4" /> Bulk Email
            </button>
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm">
              <SlidersHorizontal className="w-4 h-4" /> Filter
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all">
              <Plus className="w-4 h-4" /> Add Parent
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-primary-900 to-primary-800 text-white">
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Parent</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Contact</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Occupation</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Linked Students</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Relation</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Status</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((p, i) => (
                <tr key={p.id} className="hover:bg-primary-50/40 border-l-4 border-transparent hover:border-l-secondary-500 transition-all group">
                  {/* Parent */}
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-10 h-10 rounded-2xl bg-gradient-to-br ${avatarGrads[i % avatarGrads.length]} flex items-center justify-center text-white text-xs font-black shadow-sm flex-shrink-0`}>
                        {p.initials}
                      </div>
                      <div>
                        <p className="font-bold text-slate-800 text-sm">{p.name}</p>
                        <p className="text-[10px] font-black text-primary-700 bg-primary-50 px-1.5 py-0.5 rounded mt-0.5 inline-block">{p.id}</p>
                      </div>
                    </div>
                  </td>
                  {/* Contact */}
                  <td className="px-5 py-3.5">
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600">
                        <Phone className="w-3 h-3 text-slate-400 flex-shrink-0" /> {p.phone}
                      </div>
                      <div className="flex items-center gap-1.5 text-xs font-medium text-slate-400">
                        <Mail className="w-3 h-3 text-slate-300 flex-shrink-0" /> {p.email}
                      </div>
                    </div>
                  </td>
                  {/* Occupation */}
                  <td className="px-5 py-3.5">
                    <span className="text-xs font-bold text-slate-600 bg-slate-100 border border-slate-200 px-2.5 py-1 rounded-lg">{p.occupation}</span>
                  </td>
                  {/* Students */}
                  <td className="px-5 py-3.5">
                    <div className="flex flex-col gap-1">
                      {p.students.map((s, j) => (
                        <span key={j} className="flex items-center gap-1 text-[10px] font-bold text-primary-800 bg-primary-50 border border-primary-100 px-2 py-0.5 rounded-lg w-fit">
                          <GraduationCap className="w-2.5 h-2.5" /> {s}
                        </span>
                      ))}
                    </div>
                  </td>
                  {/* Relation */}
                  <td className="px-5 py-3.5">
                    <span className="text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 px-2.5 py-1 rounded-lg">{p.relation}</span>
                  </td>
                  {/* Status */}
                  <td className="px-5 py-3.5">
                    {p.status === "Active" ? (
                      <span className="flex items-center gap-1.5 text-xs font-black text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-lg w-fit">
                        <CheckCircle2 className="w-3 h-3" /> Active
                      </span>
                    ) : (
                      <span className="flex items-center gap-1.5 text-xs font-black text-slate-500 bg-slate-100 border border-slate-200 px-2.5 py-1 rounded-lg w-fit">
                        <XCircle className="w-3 h-3" /> Archived
                      </span>
                    )}
                  </td>
                  {/* Actions */}
                  <td className="px-5 py-3.5 text-right">
                    <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-1.5 text-primary-600 bg-primary-50 hover:bg-primary-100 border border-primary-100 rounded-lg" title="View">
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button className="p-1.5 text-secondary-600 bg-secondary-50 hover:bg-secondary-100 border border-secondary-100 rounded-lg" title="Message">
                        <MessageSquare className="w-3.5 h-3.5" />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:bg-slate-100 rounded-lg" title="More">
                        <MoreHorizontal className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="px-5 py-3.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/60">
          <span className="font-bold">Showing <span className="text-primary-900">{filtered.length}</span> of {PARENTS.length} parents</span>
          <div className="flex items-center gap-1">
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg hover:bg-slate-50 disabled:opacity-40 font-bold" disabled>
              <ChevronLeft className="w-3.5 h-3.5" /> Prev
            </button>
            <button className="w-8 h-8 flex items-center justify-center rounded-lg bg-primary-900 text-white text-xs font-black">1</button>
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg hover:bg-slate-50 font-bold">
              Next <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}