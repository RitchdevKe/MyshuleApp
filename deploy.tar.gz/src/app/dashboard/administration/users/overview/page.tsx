"use client";

import React from "react";
import { Unlock } from "lucide-react";

export default function OverviewPage() {
  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden p-6 space-y-6">
      
      <div className="grid grid-cols-2 md:grid-cols-5 gap-0 border border-slate-200/60 rounded-2xl bg-white/80 overflow-hidden mb-8">
        <div className="col-span-2 p-6 border-b md:border-b-0 md:border-r border-slate-200/60 bg-primary-900 text-white shadow-inner">
          <div className="text-4xl font-black mb-1">1,284</div>
          <div className="text-xs font-bold uppercase tracking-wider text-primary-200">Total Users</div>
        </div>
        <div className="p-6 border-b md:border-b-0 md:border-r border-slate-200/60 text-center">
          <div className="text-3xl font-black text-emerald-600">964</div>
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mt-1">Active</div>
        </div>
        <div className="p-6 border-r border-slate-200/60 text-center">
          <div className="text-3xl font-black text-amber-600">32</div>
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mt-1">Pending</div>
        </div>
        <div className="p-6 text-center bg-rose-50/50">
          <div className="text-3xl font-black text-rose-600">11</div>
          <div className="text-xs font-bold text-rose-500 uppercase tracking-wider mt-1">Suspended</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200/60 rounded-2xl overflow-hidden shadow-sm">
          <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider">User Directory</h3>
            <button className="text-xs font-bold bg-primary-900 text-white px-3 py-1.5 rounded-lg hover:bg-primary-800 transition-colors shadow-sm shadow-primary-900/20">View All</button>
          </div>
          <div className="divide-y divide-slate-100">
            {[
              { name: "Jane Wanjiku", role: "Teacher", dept: "Academics", status: "Active" },
              { name: "Peter Kamau", role: "Bursar", dept: "Finance", status: "Active" },
              { name: "Sarah Omondi", role: "Parent", dept: "External", status: "Active" },
            ].map((user, idx) => (
              <div key={idx} className="p-4 flex items-center justify-between hover:bg-slate-50/50">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center font-bold text-xs">
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-bold text-sm text-slate-800">{user.name}</div>
                    <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">{user.role} • {user.dept}</div>
                  </div>
                </div>
                <span className="px-2 py-1 text-[10px] font-black uppercase tracking-wider bg-emerald-50 text-emerald-600 rounded">
                  {user.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-amber-50/50 border border-amber-100 rounded-2xl p-5 shadow-sm">
          <h3 className="text-sm font-black text-amber-900 uppercase tracking-wider mb-4 flex items-center gap-2">
            <Unlock className="w-4 h-4 text-amber-600" /> Pending Access Requests
          </h3>
          <div className="space-y-4">
            {[
              { user: "Jane Wanjiku", request: "Grade 9 Results Access", reason: "Covering for Mr. Ouma" },
              { user: "David Kiprono", request: "Export Student Data", reason: "Ministry Report Prep" },
            ].map((req, idx) => (
              <div key={idx} className="p-4 bg-white border border-amber-100/50 rounded-xl shadow-sm">
                <div className="flex justify-between items-start mb-2">
                  <span className="font-bold text-slate-800 text-sm">{req.user}</span>
                  <div className="flex gap-2">
                    <button className="px-3 py-1.5 text-[10px] font-black uppercase tracking-wider bg-emerald-500 text-white rounded-lg shadow-sm hover:bg-emerald-600 transition-colors">Approve</button>
                    <button className="px-3 py-1.5 text-[10px] font-black uppercase tracking-wider bg-rose-500 text-white rounded-lg shadow-sm hover:bg-rose-600 transition-colors">Reject</button>
                  </div>
                </div>
                <p className="text-xs font-bold text-slate-600 mb-1">{req.request}</p>
                <p className="text-xs text-slate-500 italic">"{req.reason}"</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
