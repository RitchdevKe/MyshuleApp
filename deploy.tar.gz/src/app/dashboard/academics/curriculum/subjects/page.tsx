"use client";

import React, { useState } from "react";
import { Search, Filter, Plus, MoreHorizontal, Layers, CheckCircle2, AlertTriangle, PlayCircle, BookOpen } from "lucide-react";

const SUBJECTS = [
  { id: "SUB-001", name: "Mathematics",    category: "Sciences",     mappedArea: "Mathematics Activities", status: "Active",  lessons: 5 },
  { id: "SUB-002", name: "English",        category: "Languages",    mappedArea: "Language Activities",    status: "Active",  lessons: 5 },
  { id: "SUB-003", name: "Kiswahili",      category: "Languages",    mappedArea: "Language Activities",    status: "Active",  lessons: 4 },
  { id: "SUB-004", name: "Science",        category: "Sciences",     mappedArea: "Science & Technology",   status: "Active",  lessons: 4 },
  { id: "SUB-005", name: "Social Studies", category: "Humanities",   mappedArea: "Environmental Act.",     status: "Active",  lessons: 3 },
  { id: "SUB-006", name: "C.R.E",          category: "Humanities",   mappedArea: "Religious Education",    status: "Active",  lessons: 3 },
  { id: "SUB-007", name: "Art & Craft",    category: "Creative Arts",mappedArea: "Creative Arts",          status: "Active",  lessons: 2 },
  { id: "SUB-008", name: "French",         category: "Languages",    mappedArea: "Foreign Languages",      status: "Draft",   lessons: 2 }
];

const categoryColors: Record<string, { bg: string, text: string, border: string }> = {
  "Sciences":      { bg: "bg-indigo-50",   text: "text-indigo-700",   border: "border-indigo-200" },
  "Languages":     { bg: "bg-emerald-50",  text: "text-emerald-700",  border: "border-emerald-200" },
  "Humanities":    { bg: "bg-amber-50",    text: "text-amber-700",    border: "border-amber-200" },
  "Creative Arts": { bg: "bg-rose-50",     text: "text-rose-700",     border: "border-rose-200" },
};

export default function SubjectsPage() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredData = SUBJECTS.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    item.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Subjects",   value: "24",  icon: BookOpen,      color: "from-primary-600 to-primary-800" },
          { label: "Active Subjects",  value: "23",  icon: CheckCircle2,  color: "from-emerald-500 to-teal-600" },
          { label: "In Draft",         value: "1",   icon: AlertTriangle, color: "from-amber-500 to-orange-500" },
          { label: "Avg Lessons/Wk",   value: "3.5", icon: PlayCircle,    color: "from-indigo-500 to-violet-600" },
        ].map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className={`bg-gradient-to-br ${c.color} rounded-2xl p-4 text-white shadow-md flex items-center gap-3`}>
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-black leading-tight">{c.value}</p>
                <p className="text-xs font-bold text-white/80">{c.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Table Card */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden flex flex-col min-h-[500px]">
        
        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search Subjects..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-64 placeholder:text-slate-400"
            />
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm transition-colors">
              <Filter className="w-4 h-4" /> Filter
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all">
              <Plus className="w-4 h-4" /> Add Subject
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-gradient-to-r from-primary-900 to-primary-800 text-white">
              <tr>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Subject Details</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Category</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Mapped CBC Area</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Lessons / Wk</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Status</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredData.map((row) => {
                const isActive = row.status === 'Active';
                const colors = categoryColors[row.category] || { bg: "bg-slate-50", text: "text-slate-700", border: "border-slate-200" };
                
                return (
                  <tr key={row.id} className="hover:bg-primary-50/40 border-l-4 border-transparent hover:border-l-secondary-500 transition-all group">
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl border flex items-center justify-center flex-shrink-0 ${colors.bg} ${colors.border} ${colors.text}`}>
                          <Layers className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-bold text-slate-800 text-sm">{row.name}</p>
                          <span className="text-[10px] font-black text-primary-700 bg-primary-50 px-1.5 py-0.5 rounded mt-0.5 inline-block">{row.id}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-bold border ${colors.bg} ${colors.text} ${colors.border}`}>
                        {row.category}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-xs font-bold text-slate-700 bg-slate-100 border border-slate-200 px-2.5 py-1 rounded-lg">
                        {row.mappedArea}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-xs font-bold text-slate-500">
                        {row.lessons} periods
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-black border ${
                        isActive ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 
                        'bg-slate-50 text-slate-600 border-slate-200'
                      }`}>
                        {isActive && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>}
                        {!isActive && <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>}
                        {row.status}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          
          {filteredData.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-slate-400">
              <Layers className="w-12 h-12 mb-3 opacity-20" />
              <p className="font-bold text-lg text-slate-500">No subjects found</p>
              <p className="text-sm font-medium mt-1">Try adjusting your search criteria</p>
            </div>
          )}
        </div>
        
        {/* Footer */}
        <div className="px-5 py-3.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/60 mt-auto">
          <span className="font-bold">Showing <span className="text-primary-900">{filteredData.length}</span> of {SUBJECTS.length} records</span>
          <div className="flex gap-1">
            <button className="px-3 py-1.5 border border-slate-200 bg-white rounded-lg font-bold hover:bg-slate-50 disabled:opacity-40 transition-colors shadow-sm" disabled>Prev</button>
            <button className="px-3 py-1.5 border border-slate-200 bg-white rounded-lg font-bold hover:bg-slate-50 transition-colors shadow-sm">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
}