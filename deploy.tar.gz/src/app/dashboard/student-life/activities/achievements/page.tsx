"use client";

import React, { useState } from "react";
import { Trophy, Medal, Search, Plus, Filter } from "lucide-react";

export default function AchievementsPage() {
  const achievements = [
    { title: "National Science Fair - 1st Place", entity: "Science Club", category: "Academic", date: "Oct 15, 2026", type: "Trophy" },
    { title: "Regional Debate Finals - MVP", entity: "John Kamau", category: "Debate", date: "Sep 28, 2026", type: "Medal" },
    { title: "Inter-School Swimming - Gold", entity: "Mary Wanjiku", category: "Sports", date: "Sep 15, 2026", type: "Medal" },
    { title: "Community Service Excellence", entity: "Grade 11 Volunteers", category: "Community", date: "Aug 30, 2026", type: "Certificate" },
  ];

  return (
    <div className="p-8 space-y-6 bg-white/30 backdrop-blur-md rounded-3xl min-h-[600px]">
      
      {/* Header & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white/60 p-4 rounded-2xl border border-white/60 shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center">
            <Trophy className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-slate-800">Trophy Cabinet</h2>
            <p className="text-xs font-bold text-slate-500">Record and celebrate student and team achievements</p>
          </div>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-amber-600 rounded-xl hover:bg-amber-700 transition-colors shadow-sm">
          <Plus className="w-4 h-4" /> Add Achievement
        </button>
      </div>

      <div className="flex flex-col md:flex-row gap-4 bg-white/40 p-4 rounded-2xl border border-white/60 shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search achievements..." 
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all"
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors">
          <Filter className="w-4 h-4" /> Filter
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
        {achievements.map((ach, idx) => (
          <div key={idx} className="bg-gradient-to-r from-amber-50/80 to-yellow-50/30 border border-amber-200/60 rounded-3xl p-6 shadow-sm hover:shadow-md hover:-translate-y-1 transition-all flex items-center gap-6 group">
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 shadow-inner ${
              ach.type === 'Trophy' ? 'bg-gradient-to-br from-amber-300 to-amber-500 text-white' :
              ach.type === 'Medal' ? 'bg-gradient-to-br from-slate-300 to-slate-400 text-white' :
              'bg-gradient-to-br from-emerald-300 to-emerald-500 text-white'
            }`}>
              {ach.type === 'Trophy' ? <Trophy className="w-8 h-8 drop-shadow-sm" /> : <Medal className="w-8 h-8 drop-shadow-sm" />}
            </div>
            
            <div className="flex-1">
              <span className="text-[10px] font-black uppercase tracking-wider text-amber-600 mb-1 inline-block">{ach.category}</span>
              <h3 className="font-black text-slate-800 text-lg leading-tight mb-1 group-hover:text-amber-700 transition-colors">{ach.title}</h3>
              <p className="text-sm font-medium text-slate-600">{ach.entity}</p>
            </div>
            
            <div className="text-right">
              <span className="text-xs font-bold text-slate-400 block whitespace-nowrap">{ach.date}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
