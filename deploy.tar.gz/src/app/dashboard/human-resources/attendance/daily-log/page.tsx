"use client";

import React from "react";
import { Clock, Filter, CheckCircle2, XCircle, AlertCircle, Search, Download } from "lucide-react";

export default function DailyLogPage() {
  const attendanceData = [
    { id: "E001", name: "Jane Doe", role: "Senior Mathematics Teacher", status: "Present", clockIn: "07:45 AM", clockOut: "--:--", dept: "Academics" },
    { id: "E005", name: "Sarah Connor", role: "Head of Sciences", status: "Late", clockIn: "08:15 AM", clockOut: "--:--", dept: "Academics" },
    { id: "E002", name: "John Smith", role: "Maintenance Supervisor", status: "Present", clockIn: "07:30 AM", clockOut: "--:--", dept: "Operations" },
    { id: "E003", name: "Emily Chen", role: "School Nurse", status: "On Leave", clockIn: "N/A", clockOut: "N/A", dept: "Health" },
    { id: "E004", name: "Michael Ochieng", role: "IT Support Technician", status: "Absent", clockIn: "N/A", clockOut: "N/A", dept: "Administration" },
    { id: "E006", name: "David Kim", role: "Bus Driver", status: "Present", clockIn: "06:15 AM", clockOut: "--:--", dept: "Transport" },
  ];

  return (
    <div className="space-y-6">
      {/* Top Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-slate-50 text-slate-600 rounded-2xl">
             <Clock className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Staff Today</p>
            <p className="text-2xl font-black text-slate-800">142</p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
             <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Present</p>
            <p className="text-2xl font-black text-slate-800">131 <span className="text-sm font-medium text-emerald-500">(92%)</span></p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl">
             <AlertCircle className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Late</p>
            <p className="text-2xl font-black text-slate-800">4</p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-red-50 text-red-600 rounded-2xl">
             <XCircle className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Absent / Leave</p>
            <p className="text-2xl font-black text-slate-800">7</p>
          </div>
        </div>
      </div>

      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4">
           <div className="flex items-center gap-2 w-full md:w-auto relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input type="text" placeholder="Search employees..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-slate-50 border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
           </div>
           <div className="flex gap-2">
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
                 <Filter className="w-4 h-4" />
                 Filter
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
                 <Download className="w-4 h-4" />
                 Export
              </button>
           </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Employee</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Department</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Clock In</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Clock Out</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {attendanceData.map((record) => (
                <tr key={record.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="py-4 px-6">
                    <p className="font-bold text-slate-800 text-sm">{record.name}</p>
                    <p className="text-xs text-slate-500 font-medium">{record.role}</p>
                  </td>
                  <td className="py-4 px-6">
                    <span className="px-3 py-1 bg-slate-100 text-slate-600 text-xs font-bold rounded-lg">{record.dept}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-lg ${
                      record.status === 'Present' ? 'bg-emerald-50 text-emerald-600' : 
                      record.status === 'Late' ? 'bg-amber-50 text-amber-600' : 
                      record.status === 'On Leave' ? 'bg-blue-50 text-blue-600' :
                      'bg-red-50 text-red-600'
                    }`}>
                      {record.status}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm font-bold text-slate-700">{record.clockIn}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm font-bold text-slate-400">{record.clockOut}</span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <button className="text-sm font-bold text-primary-600 hover:text-primary-800 hover:underline">Edit Log</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
