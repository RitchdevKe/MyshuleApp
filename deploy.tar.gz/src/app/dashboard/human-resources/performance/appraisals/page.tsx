"use client";

import React from "react";
import { LineChart, Search, Filter, Play, CheckCircle2, AlertCircle, Clock, Star } from "lucide-react";

export default function AppraisalsPage() {
  const appraisals = [
    { id: "APP-2024-H1-01", employee: "Jane Doe", role: "Senior Math Teacher", reviewer: "David Mwangi", score: "4.8/5.0", rating: "Exceeds Expectations", status: "Completed", date: "Jul 15, 2024" },
    { id: "APP-2024-H1-02", employee: "Sarah Connor", role: "Head of Sciences", reviewer: "Sarah Palmer", score: "5.0/5.0", rating: "Outstanding", status: "Completed", date: "Jul 10, 2024" },
    { id: "APP-2024-H1-03", employee: "John Smith", role: "Maintenance", reviewer: "Robert Kiprono", score: "4.2/5.0", rating: "Meets Expectations", status: "Pending Review", date: "Jul 18, 2024" },
    { id: "APP-2024-H1-04", employee: "Michael Ochieng", role: "IT Support", reviewer: "Alice Wanjiku", score: "--", rating: "Pending", status: "In Progress", date: "--" },
    { id: "APP-2024-H1-05", employee: "Emily Chen", role: "School Nurse", reviewer: "Alice Wanjiku", score: "3.5/5.0", rating: "Needs Improvement", status: "Completed", date: "Jul 12, 2024" },
  ];

  return (
    <div className="space-y-6">
      {/* Current Cycle Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex flex-col justify-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Current Cycle</p>
          <p className="text-2xl font-black text-slate-800">2024 H1 Review</p>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
             <LineChart className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Completion Rate</p>
            <p className="text-2xl font-black text-slate-800">78%</p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
             <Star className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Average Score</p>
            <p className="text-2xl font-black text-slate-800">4.3 <span className="text-sm font-bold text-slate-400">/ 5.0</span></p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center justify-between">
           <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Actions</p>
              <p className="text-sm font-bold text-amber-600">12 Pending Reviews</p>
           </div>
           <button className="p-3 bg-primary-900 hover:bg-primary-800 text-white rounded-xl transition-colors shadow-sm shadow-primary-900/20">
              <Play className="w-5 h-5" />
           </button>
        </div>
      </div>

      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4">
           <div className="flex items-center gap-2 w-full md:w-auto relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input type="text" placeholder="Search appraisals..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-slate-50 border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
           </div>
           <div className="flex gap-2">
              <select className="px-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-900 cursor-pointer">
                 <option>All Statuses</option>
                 <option>Completed</option>
                 <option>Pending Review</option>
                 <option>In Progress</option>
              </select>
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
                 <Filter className="w-4 h-4" />
                 More Filters
              </button>
           </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Employee</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Reviewer</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Score</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Overall Rating</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {appraisals.map((app) => (
                <tr key={app.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="py-4 px-6">
                    <p className="font-bold text-slate-800 text-sm">{app.employee}</p>
                    <p className="text-xs text-slate-500 font-medium">{app.role}</p>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm font-bold text-slate-600">{app.reviewer}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm font-black text-slate-800">{app.score}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`text-sm font-bold ${
                       app.rating === 'Outstanding' || app.rating === 'Exceeds Expectations' ? 'text-emerald-600' :
                       app.rating === 'Meets Expectations' ? 'text-blue-600' :
                       app.rating === 'Needs Improvement' ? 'text-amber-600' : 'text-slate-400'
                    }`}>{app.rating}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-lg ${
                      app.status === 'Completed' ? 'bg-emerald-50 text-emerald-600' : 
                      app.status === 'Pending Review' ? 'bg-amber-50 text-amber-600' : 
                      'bg-slate-100 text-slate-600'
                    }`}>
                      {app.status === 'Completed' && <CheckCircle2 className="w-3.5 h-3.5" />}
                      {app.status === 'Pending Review' && <AlertCircle className="w-3.5 h-3.5" />}
                      {app.status === 'In Progress' && <Clock className="w-3.5 h-3.5" />}
                      {app.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    {app.status === 'Pending Review' ? (
                       <button className="text-sm font-bold text-white bg-primary-900 hover:bg-primary-800 px-3 py-1.5 rounded-lg transition-colors">Review</button>
                    ) : (
                       <button className="text-sm font-bold text-primary-600 hover:text-primary-800 hover:underline">View File</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
