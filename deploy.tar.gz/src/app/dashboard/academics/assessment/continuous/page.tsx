"use client";

import React from "react";
import { Search, Plus, MoreHorizontal, Calendar, ArrowUpRight, ArrowDownRight, Clock, BookOpen, FileText } from "lucide-react";

const mockExamsData = [
  { id: "EXM-001", name: "Mid Term 2 Exam", type: "Main Exam", date: "2026-06-15", class: "Grade 4", status: "Published", avgScore: "68%" },
  { id: "EXM-002", name: "Mathematics CAT 1", type: "CAT", date: "2026-05-20", class: "Grade 4 North", status: "Published", avgScore: "72%" },
  { id: "EXM-003", name: "English Reading Quiz", type: "Quiz", date: "2026-07-02", class: "Grade 5", status: "Draft", avgScore: "-" },
  { id: "EXM-004", name: "End Term 2 Exam", type: "Main Exam", date: "2026-07-28", class: "All Grades", status: "Scheduled", avgScore: "-" },
];

export default function ContinuousAssessmentPage() {
  const getStatusStyle = (status: string) => {
    switch (status) {
      case "Published": return "bg-emerald-100/80 text-emerald-700 border-emerald-200";
      case "Scheduled": return "bg-blue-100/80 text-blue-700 border-blue-200";
      case "Draft": return "bg-slate-100/80 text-slate-700 border-slate-200";
      default: return "bg-slate-100/80 text-slate-700 border-slate-200";
    }
  };

  return (
    <div className="space-y-6">
      
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-white/60 backdrop-blur-xl p-6 rounded-3xl border border-white/60 shadow-lg relative overflow-hidden group hover:shadow-xl transition-all duration-300">
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary-500/5 rounded-full blur-3xl group-hover:bg-primary-500/10 transition-colors duration-500"></div>
          <div className="flex justify-between items-start mb-4 relative z-10">
            <div className="p-3 bg-primary-100 text-primary-900 rounded-2xl">
              <FileText className="w-6 h-6" />
            </div>
            <span className="flex items-center gap-1 text-xs font-extrabold text-emerald-700 bg-emerald-100/80 px-2.5 py-1.5 rounded-lg">
              <ArrowUpRight className="w-3.5 h-3.5" /> 3 this month
            </span>
          </div>
          <p className="text-sm font-bold text-slate-500 mb-1 relative z-10">Total Assessments</p>
          <h3 className="text-3xl font-black text-slate-800 tracking-tight relative z-10">24 <span className="text-sm font-bold text-slate-400">YTD</span></h3>
        </div>

        <div className="bg-white/60 backdrop-blur-xl p-6 rounded-3xl border border-white/60 shadow-lg relative overflow-hidden group hover:shadow-xl transition-all duration-300">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl group-hover:bg-blue-500/10 transition-colors duration-500"></div>
          <div className="flex justify-between items-start mb-4 relative z-10">
            <div className="p-3 bg-blue-100 text-blue-600 rounded-2xl">
              <BookOpen className="w-6 h-6" />
            </div>
            <span className="flex items-center gap-1 text-xs font-extrabold text-emerald-700 bg-emerald-100/80 px-2.5 py-1.5 rounded-lg">
              <ArrowUpRight className="w-3.5 h-3.5" /> +2.4%
            </span>
          </div>
          <p className="text-sm font-bold text-slate-500 mb-1 relative z-10">Average Score</p>
          <h3 className="text-3xl font-black text-slate-800 tracking-tight relative z-10">68.5%</h3>
        </div>

        <div className="bg-white/60 backdrop-blur-xl p-6 rounded-3xl border border-white/60 shadow-lg relative overflow-hidden group hover:shadow-xl transition-all duration-300">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl group-hover:bg-amber-500/10 transition-colors duration-500"></div>
          <div className="flex justify-between items-start mb-4 relative z-10">
            <div className="p-3 bg-amber-100 text-amber-600 rounded-2xl">
              <Clock className="w-6 h-6" />
            </div>
          </div>
          <p className="text-sm font-bold text-slate-500 mb-1 relative z-10">Upcoming</p>
          <h3 className="text-3xl font-black text-slate-800 tracking-tight relative z-10">End Term 2 Exam</h3>
          <p className="text-xs font-bold text-amber-600 mt-1">In 14 days</p>
        </div>
      </div>

      {/* Main Table Area */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/60 rounded-3xl shadow-lg overflow-hidden flex flex-col min-h-[400px]">
        {/* Toolbar */}
        <div className="p-5 border-b border-slate-200/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="relative w-full sm:max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search exams & CATs..." 
              className="w-full pl-10 pr-4 py-2.5 text-sm font-bold bg-white/80 border border-slate-200/60 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-900 focus:border-primary-900 transition-shadow"
            />
          </div>
          <div className="flex items-center gap-3">
            <select className="px-4 py-2.5 bg-white border border-slate-200/60 rounded-xl text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-900 cursor-pointer">
              <option>All Terms</option>
              <option>Term 1</option>
              <option>Term 2</option>
            </select>
            <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-white bg-primary-900 rounded-xl hover:bg-primary-800 transition-colors shadow-sm">
              <Plus className="w-4 h-4" /> New Exam
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50/50 text-[10px] uppercase font-black text-slate-500 border-b border-slate-200/60 tracking-wider">
              <tr>
                <th className="px-6 py-4">Assessment Name</th>
                <th className="px-6 py-4">Type</th>
                <th className="px-6 py-4">Target Class</th>
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4">Avg. Score</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/60">
              {mockExamsData.map((row, i) => (
                <tr key={i} className="hover:bg-white/80 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="font-bold text-slate-800">{row.name}</span>
                      <span className="text-xs font-bold text-slate-400">{row.id}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 font-bold text-slate-700">{row.type}</td>
                  <td className="px-6 py-4 font-bold text-slate-700">{row.class}</td>
                  <td className="px-6 py-4">
                    <span className="flex items-center gap-1.5 font-bold text-slate-600">
                      <Calendar className="w-4 h-4 text-slate-400" />
                      {row.date}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="font-black text-slate-800">{row.avgScore}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold border backdrop-blur-sm ${getStatusStyle(row.status)}`}>
                      {row.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="p-1.5 text-slate-400 hover:text-primary-900 hover:bg-slate-100 rounded-lg transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100">
                      <MoreHorizontal className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}