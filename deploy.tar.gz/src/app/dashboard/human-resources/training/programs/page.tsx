"use client";

import React from "react";
import { GraduationCap, BookOpen, Clock, Users, Play, Plus, Search, Filter } from "lucide-react";

export default function ProgramsPage() {
  const programs = [
    { id: "PRG-01", title: "Advanced Pedagogy Workshop", format: "In-Person", duration: "12 Hours", instructor: "Prof. Alan Smith", enrolled: 45, status: "Active", bg: "bg-blue-50", color: "text-blue-600" },
    { id: "PRG-02", title: "Fire Safety & Emergency Response", format: "Online", duration: "4 Hours", instructor: "Safety First Ltd.", enrolled: 120, status: "Active", bg: "bg-rose-50", color: "text-rose-600" },
    { id: "PRG-03", title: "Digital Literacy in Classrooms", format: "Hybrid", duration: "8 Hours", instructor: "IT Department", enrolled: 85, status: "Active", bg: "bg-emerald-50", color: "text-emerald-600" },
    { id: "PRG-04", title: "Leadership Seminar 2024", format: "In-Person", duration: "16 Hours", instructor: "Dr. Helen Mirren", enrolled: 12, status: "Upcoming", bg: "bg-amber-50", color: "text-amber-600" },
    { id: "PRG-05", title: "First Aid Basics", format: "In-Person", duration: "8 Hours", instructor: "Red Cross", enrolled: 30, status: "Completed", bg: "bg-slate-100", color: "text-slate-600" },
  ];

  return (
    <div className="space-y-6">
      {/* Top Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-primary-50 text-primary-600 rounded-2xl">
             <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Programs</p>
            <p className="text-2xl font-black text-slate-800">12</p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
             <Users className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Enrolled</p>
            <p className="text-2xl font-black text-slate-800">292</p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
             <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Completion Rate</p>
            <p className="text-2xl font-black text-slate-800">84%</p>
          </div>
        </div>
      </div>

      <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-2">
         <div className="flex items-center gap-2 w-full md:w-auto relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input type="text" placeholder="Search training programs..." className="w-full md:w-80 pl-9 pr-4 py-2.5 bg-white border border-slate-200/60 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-primary-900 shadow-sm" />
         </div>
         <div className="flex gap-2">
            <button className="flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
               <Filter className="w-4 h-4" />
               Filter
            </button>
            <button className="flex items-center gap-2 px-4 py-2.5 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
               <Plus className="w-4 h-4" />
               New Course
            </button>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
         {programs.map((program) => (
            <div key={program.id} className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden hover:shadow-xl transition-all duration-300 group flex flex-col">
               <div className={`p-6 ${program.bg} border-b border-white/40 flex justify-between items-start relative overflow-hidden`}>
                  {/* Decorative shape */}
                  <div className="absolute -right-4 -top-4 w-24 h-24 bg-white/20 rounded-full blur-xl"></div>
                  
                  <div className="relative z-10">
                     <span className={`inline-block px-2 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg bg-white/60 mb-3 ${program.color}`}>
                        {program.format}
                     </span>
                     <h3 className={`font-black text-lg leading-tight ${program.color.replace('text-', 'text-').replace('600', '900')}`}>
                        {program.title}
                     </h3>
                  </div>
                  <div className={`w-10 h-10 rounded-2xl bg-white/60 flex items-center justify-center shrink-0 relative z-10 ${program.color}`}>
                     <GraduationCap className="w-5 h-5" />
                  </div>
               </div>
               
               <div className="p-6 flex-grow flex flex-col justify-between">
                  <div className="space-y-3 mb-6">
                     <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Duration</span>
                        <span className="text-sm font-bold text-slate-700 flex items-center gap-1.5"><Clock className="w-4 h-4 text-slate-400" /> {program.duration}</span>
                     </div>
                     <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Instructor</span>
                        <span className="text-sm font-bold text-slate-700">{program.instructor}</span>
                     </div>
                  </div>

                  <div className="flex justify-between items-center pt-4 border-t border-slate-100">
                     <div className="flex flex-col">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Enrolled</span>
                        <div className="flex items-center gap-1.5 text-sm font-black text-slate-800">
                           <Users className="w-4 h-4 text-primary-500" />
                           {program.enrolled}
                        </div>
                     </div>
                     <button className="flex items-center justify-center w-10 h-10 rounded-full bg-slate-50 text-slate-600 hover:bg-primary-900 hover:text-white transition-colors">
                        <Play className="w-4 h-4 ml-0.5" />
                     </button>
                  </div>
               </div>
            </div>
         ))}
      </div>
    </div>
  );
}
