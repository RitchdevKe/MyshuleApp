"use client";

import React, { useState } from "react";
import { Search, Plus, Filter, Calendar, CalendarCheck, CalendarDays, Clock, MoreHorizontal, Settings2 } from "lucide-react";

const ACADEMIC_YEARS = [
  { id: "AY-2026", year: "2026", term: "Term 1", startDate: "05/01/26", endDate: "10/04/26", status: "Active",   weeks: 14, feeDeadline: "20/01/26" },
  { id: "AY-2026", year: "2026", term: "Term 2", startDate: "04/05/26", endDate: "07/08/26", status: "Upcoming", weeks: 14, feeDeadline: "15/05/26" },
  { id: "AY-2026", year: "2026", term: "Term 3", startDate: "31/08/26", endDate: "27/11/26", status: "Planned",  weeks: 13, feeDeadline: "10/09/26" },
  { id: "AY-2025", year: "2025", term: "Term 3", startDate: "01/09/25", endDate: "28/11/25", status: "Completed",weeks: 13, feeDeadline: "15/09/25" },
];

export default function AcademicPage() {
  const [search, setSearch] = useState("");

  const filtered = ACADEMIC_YEARS.filter(y => 
    y.year.includes(search) || y.term.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Current Year",  value: "2026",      icon: Calendar,      color: "from-primary-600 to-primary-800" },
          { label: "Active Term",   value: "Term 1",    icon: CalendarCheck, color: "from-emerald-500 to-teal-600" },
          { label: "Total Weeks",   value: "14 Weeks",  icon: Clock,         color: "from-indigo-500 to-violet-600" },
          { label: "Next Deadline", value: "20/01/26",  icon: CalendarDays,  color: "from-amber-500 to-orange-500" },
        ].map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className={`bg-gradient-to-br ${c.color} rounded-2xl p-4 text-white shadow-md flex items-center gap-3`}>
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-black leading-tight">{c.value}</p>
                <p className="text-xs font-bold text-white/80">{c.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Table Card */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden">
        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search year or term..."
              className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-64 placeholder:text-slate-400"
            />
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm">
              <Filter className="w-4 h-4" /> Filter
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all">
              <Plus className="w-4 h-4" /> New Term
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-primary-900 to-primary-800 text-white">
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Academic Term</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Start Date</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">End Date</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Duration</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Fee Deadline</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Status</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((y, i) => {
                const isActive = y.status === "Active";
                const isCompleted = y.status === "Completed";
                const isUpcoming = y.status === "Upcoming";
                
                return (
                  <tr key={i} className={`hover:bg-primary-50/40 border-l-4 transition-all group ${isActive ? 'border-l-secondary-500 bg-secondary-50/10' : 'border-transparent hover:border-l-primary-400'}`}>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl border flex items-center justify-center flex-shrink-0 ${isActive ? 'bg-secondary-50 border-secondary-200 text-secondary-600' : 'bg-slate-50 border-slate-200 text-slate-500'}`}>
                          <Calendar className="w-5 h-5" />
                        </div>
                        <div>
                          <p className={`font-black text-sm ${isActive ? 'text-secondary-700' : 'text-slate-800'}`}>{y.term}</p>
                          <span className="text-[10px] font-black text-primary-700 bg-primary-50 px-1.5 py-0.5 rounded mt-0.5 inline-block">Year {y.year}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-xs font-bold text-slate-600">{y.startDate}</span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-xs font-bold text-slate-600">{y.endDate}</span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200">{y.weeks} Weeks</span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">{y.feeDeadline}</span>
                    </td>
                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-black border ${
                        isActive ? 'bg-emerald-50 text-emerald-700 border-emerald-200 shadow-sm' : 
                        isCompleted ? 'bg-slate-100 text-slate-600 border-slate-300' : 
                        isUpcoming ? 'bg-indigo-50 text-indigo-700 border-indigo-200' :
                        'bg-slate-50 text-slate-500 border-slate-200'
                      }`}>
                        {isActive && <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />}
                        {y.status}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-primary-600 bg-primary-50 hover:bg-primary-100 border border-primary-100 rounded-lg">
                          <Settings2 className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 text-slate-400 hover:bg-slate-100 rounded-lg">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}