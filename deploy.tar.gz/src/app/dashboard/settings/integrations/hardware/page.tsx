"use client";

import React from "react";
import { MonitorSmartphone, Settings, CheckCircle2, Activity, ShieldCheck, CreditCard, RefreshCw } from "lucide-react";

export default function HardwarePage() {
  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <div className="flex items-center gap-3 mb-8">
         <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center">
            <MonitorSmartphone className="w-5 h-5" />
         </div>
         <div>
            <h3 className="text-xl font-black text-slate-800">Hardware Integrations</h3>
            <p className="text-sm font-medium text-slate-500">Manage connections to physical devices like biometric scanners and POS terminals.</p>
         </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Biometric Scanners */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col h-full hover:border-slate-300 transition-colors">
            <div className="p-5 flex-1">
               <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                     <div className="w-12 h-12 bg-sky-100 rounded-xl flex items-center justify-center text-sky-600 shadow-inner">
                        <ShieldCheck className="w-6 h-6" />
                     </div>
                     <div>
                        <h4 className="font-black text-slate-800 text-lg">ZKTeco Biometrics</h4>
                        <div className="flex items-center gap-1.5 mt-0.5">
                           <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                           <span className="text-xs font-bold text-emerald-600">2 Devices Online</span>
                        </div>
                     </div>
                  </div>
                  <button className="text-slate-400 hover:text-slate-700 transition-colors">
                     <Settings className="w-5 h-5" />
                  </button>
               </div>
               
               <p className="text-sm text-slate-500 font-medium mb-5">
                  Fingerprint and facial recognition scanners used for automated student and staff attendance tracking at the main gates.
               </p>
               
               <div className="space-y-2">
                  <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex justify-between items-center group">
                     <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                        <div>
                           <div className="text-sm font-bold text-slate-800">Main Gate - Entry</div>
                           <div className="text-[10px] font-mono text-slate-500">IP: 192.168.1.105</div>
                        </div>
                     </div>
                     <button className="text-slate-400 hover:text-sky-600 transition-colors opacity-0 group-hover:opacity-100">
                        <RefreshCw className="w-4 h-4" />
                     </button>
                  </div>
                  
                  <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex justify-between items-center group">
                     <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                        <div>
                           <div className="text-sm font-bold text-slate-800">Staff Entrance</div>
                           <div className="text-[10px] font-mono text-slate-500">IP: 192.168.1.106</div>
                        </div>
                     </div>
                     <button className="text-slate-400 hover:text-sky-600 transition-colors opacity-0 group-hover:opacity-100">
                        <RefreshCw className="w-4 h-4" />
                     </button>
                  </div>
               </div>
            </div>
            <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
               <span className="text-xs font-bold text-slate-500">Last heartbeat: Just now</span>
               <div className="flex items-center gap-1 text-xs font-bold text-emerald-600">
                  <Activity className="w-3 h-3" /> Healthy
               </div>
            </div>
        </div>

        {/* Cafeteria POS */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col h-full hover:border-slate-300 transition-colors">
            <div className="p-5 flex-1">
               <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                     <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center text-orange-600 shadow-inner">
                        <CreditCard className="w-6 h-6" />
                     </div>
                     <div>
                        <h4 className="font-black text-slate-800 text-lg">Cafeteria POS</h4>
                        <div className="flex items-center gap-1.5 mt-0.5">
                           <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                           <span className="text-xs font-bold text-emerald-600">1 Device Online</span>
                        </div>
                     </div>
                  </div>
                  <button className="text-slate-400 hover:text-slate-700 transition-colors">
                     <Settings className="w-5 h-5" />
                  </button>
               </div>
               
               <p className="text-sm text-slate-500 font-medium mb-5">
                  Point of Sale terminals linked to student smart cards for cashless transactions in the dining hall.
               </p>
               
               <div className="space-y-2">
                  <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 flex justify-between items-center group">
                     <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                        <div>
                           <div className="text-sm font-bold text-slate-800">Dining Hall - Register 1</div>
                           <div className="text-[10px] font-mono text-slate-500">IP: 192.168.1.120</div>
                        </div>
                     </div>
                     <button className="text-slate-400 hover:text-orange-600 transition-colors opacity-0 group-hover:opacity-100">
                        <RefreshCw className="w-4 h-4" />
                     </button>
                  </div>
               </div>
            </div>
            <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
               <span className="text-xs font-bold text-slate-500">Last sync: 5 mins ago</span>
               <div className="flex items-center gap-1 text-xs font-bold text-emerald-600">
                  <Activity className="w-3 h-3" /> Healthy
               </div>
            </div>
        </div>

      </div>
    </div>
  );
}
