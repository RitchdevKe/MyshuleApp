"use client";

import React from "react";
import { Filter, Search, MoreVertical, Mail, Phone, Calendar, ArrowRight } from "lucide-react";

export default function ApplicantsPage() {
  const stages = [
    {
      name: "Applied",
      count: 3,
      applicants: [
        { name: "Sarah Jenkins", role: "Senior Math Teacher", date: "2 days ago", rating: 4 },
        { name: "Michael Chen", role: "IT Support", date: "3 days ago", rating: 3 },
        { name: "David Okafor", role: "Bus Driver", date: "1 week ago", rating: 2 },
      ]
    },
    {
      name: "Screening",
      count: 2,
      applicants: [
        { name: "Emily Watson", role: "School Nurse", date: "4 days ago", rating: 5 },
        { name: "James Anderson", role: "Senior Math Teacher", date: "5 days ago", rating: 4 },
      ]
    },
    {
      name: "Interview",
      count: 2,
      applicants: [
        { name: "Rachel Green", role: "IT Support", date: "1 week ago", rating: 5 },
        { name: "Ahmed Patel", role: "Senior Math Teacher", date: "1 week ago", rating: 4 },
      ]
    },
    {
      name: "Offered",
      count: 1,
      applicants: [
        { name: "Jessica Taylor", role: "School Nurse", date: "2 weeks ago", rating: 5 },
      ]
    }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-4 flex flex-col md:flex-row justify-between items-center gap-4">
         <div className="flex items-center gap-2 w-full md:w-auto relative">
            <Search className="w-5 h-5 text-slate-400 absolute left-4" />
            <input type="text" placeholder="Search by name or role..." className="w-full md:w-80 pl-11 pr-4 py-2.5 bg-slate-50 border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
         </div>
         <div className="flex gap-2 w-full md:w-auto">
            <select className="px-4 py-2.5 bg-white border border-slate-200/60 rounded-xl text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-900 cursor-pointer w-full md:w-auto">
               <option>All Roles</option>
               <option>Senior Math Teacher</option>
               <option>IT Support</option>
               <option>School Nurse</option>
            </select>
            <button className="flex items-center justify-center gap-2 px-4 py-2.5 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm w-full md:w-auto">
               <Filter className="w-4 h-4" />
               Filters
            </button>
         </div>
      </div>

      <div className="flex gap-6 overflow-x-auto pb-4 hide-scrollbar">
         {stages.map((stage, i) => (
           <div key={i} className="min-w-[320px] max-w-[320px] flex-shrink-0 flex flex-col">
              <div className="flex items-center justify-between mb-4 px-2">
                 <h3 className="font-bold text-slate-700 flex items-center gap-2">
                    {stage.name}
                    <span className="bg-slate-200 text-slate-600 px-2 py-0.5 rounded-full text-xs">{stage.count}</span>
                 </h3>
              </div>
              
              <div className="flex flex-col gap-4">
                 {stage.applicants.map((applicant, j) => (
                    <div key={j} className="bg-white/80 backdrop-blur-xl rounded-2xl border border-slate-200/80 shadow-sm p-5 hover:shadow-md transition-all cursor-grab group">
                       <div className="flex justify-between items-start mb-3">
                          <div>
                             <h4 className="font-bold text-slate-800">{applicant.name}</h4>
                             <p className="text-xs font-medium text-slate-500">{applicant.role}</p>
                          </div>
                          <button className="text-slate-400 hover:text-primary-900 transition-colors">
                             <MoreVertical className="w-4 h-4" />
                          </button>
                       </div>
                       
                       <div className="flex items-center gap-1 mb-4">
                          {[1, 2, 3, 4, 5].map((star) => (
                             <svg key={star} className={`w-3.5 h-3.5 ${star <= applicant.rating ? 'text-amber-400' : 'text-slate-200'}`} fill="currentColor" viewBox="0 0 20 20">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                             </svg>
                          ))}
                       </div>

                       <div className="flex items-center justify-between text-xs font-medium text-slate-500">
                          <span>{applicant.date}</span>
                          <div className="flex gap-2">
                             <button className="p-1.5 bg-slate-50 hover:bg-primary-50 hover:text-primary-600 rounded-lg transition-colors">
                                <Mail className="w-3.5 h-3.5" />
                             </button>
                             <button className="p-1.5 bg-slate-50 hover:bg-primary-50 hover:text-primary-600 rounded-lg transition-colors">
                                <Phone className="w-3.5 h-3.5" />
                             </button>
                          </div>
                       </div>
                       
                       <div className="mt-4 pt-4 border-t border-slate-100 hidden group-hover:flex items-center justify-between">
                          <button className="text-xs font-bold text-slate-500 hover:text-slate-800">Reject</button>
                          <button className="flex items-center gap-1 px-3 py-1.5 bg-primary-900 hover:bg-primary-800 text-white rounded-lg text-xs font-bold transition-colors">
                             Review
                             <ArrowRight className="w-3 h-3" />
                          </button>
                       </div>
                    </div>
                 ))}
                 
                 {stage.applicants.length === 0 && (
                    <div className="border-2 border-dashed border-slate-200 rounded-2xl p-6 text-center">
                       <p className="text-sm font-medium text-slate-400">No applicants</p>
                    </div>
                 )}
              </div>
           </div>
         ))}
      </div>
    </div>
  );
}
