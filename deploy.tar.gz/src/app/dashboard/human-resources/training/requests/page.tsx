"use client";

import React from "react";
import { Search, Filter, Check, X, Clock, HelpCircle, FileCheck, CheckCircle2 } from "lucide-react";

export default function RequestsPage() {
  const requests = [
    { id: "TRQ-1042", employee: "Jane Doe", course: "Advanced React Patterns", provider: "FrontendMasters", cost: "$350.00", status: "Approved", date: "Aug 10, 2024" },
    { id: "TRQ-1043", employee: "Michael Ochieng", course: "AWS Solutions Architect", provider: "A Cloud Guru", cost: "$400.00", status: "Pending", date: "Aug 09, 2024" },
    { id: "TRQ-1044", employee: "Sarah Connor", course: "Conflict Resolution", provider: "Internal HR", cost: "Free", status: "Approved", date: "Aug 08, 2024" },
    { id: "TRQ-1045", employee: "David Kim", course: "Data Science Bootcamp", provider: "General Assembly", cost: "$2,500.00", status: "Rejected", date: "Aug 05, 2024" },
    { id: "TRQ-1046", employee: "Emily Chen", course: "First Aid & CPR", provider: "Red Cross", cost: "$120.00", status: "Pending", date: "Aug 11, 2024" },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50/50">
           <div className="flex items-center gap-4">
              <div className="p-2 bg-primary-50 text-primary-600 rounded-xl hidden md:block">
                 <FileCheck className="w-5 h-5" />
              </div>
              <div>
                 <h2 className="text-lg font-black text-slate-800">Training Requests & Approvals</h2>
                 <p className="text-sm font-medium text-slate-500">Manage budget and enrollment approvals for external and internal courses.</p>
              </div>
           </div>
        </div>

        <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4">
           <div className="flex items-center gap-2 w-full md:w-auto relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input type="text" placeholder="Search by employee or course..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-slate-50 border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
           </div>
           <div className="flex gap-2">
              <select className="px-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-900 cursor-pointer">
                 <option>All Statuses</option>
                 <option>Pending</option>
                 <option>Approved</option>
                 <option>Rejected</option>
              </select>
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
                 <Filter className="w-4 h-4" />
                 Filter
              </button>
           </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Request ID</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Employee</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Course / Program</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Est. Cost</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Manager Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {requests.map((req) => (
                <tr key={req.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="py-4 px-6">
                    <span className="font-bold text-slate-700 text-sm">{req.id}</span>
                    <p className="text-[10px] font-bold text-slate-400 mt-0.5">{req.date}</p>
                  </td>
                  <td className="py-4 px-6">
                    <span className="font-bold text-slate-800 text-sm">{req.employee}</span>
                  </td>
                  <td className="py-4 px-6">
                    <p className="font-bold text-slate-800 text-sm">{req.course}</p>
                    <p className="text-xs text-slate-500 font-medium">Provider: {req.provider}</p>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`text-sm font-black ${req.cost === 'Free' ? 'text-emerald-600' : 'text-slate-800'}`}>{req.cost}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-lg ${
                      req.status === 'Approved' ? 'bg-emerald-50 text-emerald-600' : 
                      req.status === 'Pending' ? 'bg-amber-50 text-amber-600' : 
                      'bg-rose-50 text-rose-600'
                    }`}>
                      {req.status === 'Approved' && <CheckCircle2 className="w-3.5 h-3.5" />}
                      {req.status === 'Pending' && <Clock className="w-3.5 h-3.5" />}
                      {req.status === 'Rejected' && <X className="w-3.5 h-3.5" />}
                      {req.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    {req.status === 'Pending' ? (
                       <div className="flex justify-end gap-2">
                          <button className="p-2 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 rounded-lg transition-colors tooltip-trigger" title="Approve">
                             <Check className="w-4 h-4" />
                          </button>
                          <button className="p-2 bg-rose-50 text-rose-600 hover:bg-rose-100 rounded-lg transition-colors tooltip-trigger" title="Reject">
                             <X className="w-4 h-4" />
                          </button>
                          <button className="p-2 bg-slate-50 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors tooltip-trigger" title="Request Details">
                             <HelpCircle className="w-4 h-4" />
                          </button>
                       </div>
                    ) : (
                       <button className="text-sm font-bold text-primary-600 hover:text-primary-800 hover:underline">View Details</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
