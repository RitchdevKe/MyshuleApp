"use client";

import React from "react";
import { Plus, Calendar, Clock, CheckCircle, XCircle } from "lucide-react";

export default function LeaveRequestsPage() {
  const requests = {
    pending: [
      { id: "LR-001", name: "Emily Chen", role: "School Nurse", type: "Sick Leave", dates: "Aug 12 - Aug 14", days: 3, reason: "Medical appointment and recovery." },
      { id: "LR-002", name: "John Smith", role: "Maintenance", type: "Annual PTO", dates: "Aug 20 - Aug 25", days: 5, reason: "Family vacation." },
    ],
    approved: [
      { id: "LR-003", name: "Sarah Connor", role: "Head of Sciences", type: "Maternity", dates: "Sep 01 - Dec 01", days: 90, reason: "Maternity leave as per policy." },
    ],
    rejected: [
      { id: "LR-004", name: "Michael Ochieng", role: "IT Support", type: "Personal", dates: "Aug 10 - Aug 11", days: 2, reason: "Insufficient notice period given during peak system upgrade week." },
    ]
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div>
           <h2 className="text-lg font-black text-slate-800">Leave Requests</h2>
           <p className="text-sm font-medium text-slate-500">Manage and approve employee time off.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
           <Plus className="w-4 h-4" />
           New Request
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Pending Column */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-amber-500"></div>
            <h3 className="font-black text-slate-700 uppercase tracking-wider text-sm">Pending Review ({requests.pending.length})</h3>
          </div>
          {requests.pending.map((req) => (
             <div key={req.id} className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-5 hover:shadow-md transition-all">
                <div className="flex justify-between items-start mb-3">
                   <div>
                      <p className="font-black text-slate-800">{req.name}</p>
                      <p className="text-xs font-bold text-slate-500">{req.role}</p>
                   </div>
                   <span className="px-2 py-1 bg-slate-100 text-slate-600 text-[10px] font-black uppercase tracking-wider rounded-lg">{req.type}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-600 font-medium mb-1">
                   <Calendar className="w-4 h-4 text-primary-500" />
                   {req.dates} <span className="text-xs text-slate-400">({req.days} days)</span>
                </div>
                <p className="text-sm text-slate-500 mt-3 p-3 bg-slate-50 rounded-xl italic">"{req.reason}"</p>
                
                <div className="grid grid-cols-2 gap-2 mt-4">
                   <button className="flex items-center justify-center gap-2 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-600 font-bold rounded-xl text-sm transition-colors">
                      <CheckCircle className="w-4 h-4" /> Approve
                   </button>
                   <button className="flex items-center justify-center gap-2 py-2 bg-red-50 hover:bg-red-100 text-red-600 font-bold rounded-xl text-sm transition-colors">
                      <XCircle className="w-4 h-4" /> Reject
                   </button>
                </div>
             </div>
          ))}
        </div>

        {/* Approved Column */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
            <h3 className="font-black text-slate-700 uppercase tracking-wider text-sm">Approved ({requests.approved.length})</h3>
          </div>
          {requests.approved.map((req) => (
             <div key={req.id} className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-5 opacity-80">
                <div className="flex justify-between items-start mb-3">
                   <div>
                      <p className="font-black text-slate-800">{req.name}</p>
                      <p className="text-xs font-bold text-slate-500">{req.role}</p>
                   </div>
                   <span className="px-2 py-1 bg-slate-100 text-slate-600 text-[10px] font-black uppercase tracking-wider rounded-lg">{req.type}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-600 font-medium mb-1">
                   <Calendar className="w-4 h-4 text-emerald-500" />
                   {req.dates} <span className="text-xs text-slate-400">({req.days} days)</span>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2 text-emerald-600 text-sm font-bold">
                   <CheckCircle className="w-4 h-4" /> Approved
                </div>
             </div>
          ))}
        </div>

        {/* Rejected Column */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-red-500"></div>
            <h3 className="font-black text-slate-700 uppercase tracking-wider text-sm">Rejected ({requests.rejected.length})</h3>
          </div>
          {requests.rejected.map((req) => (
             <div key={req.id} className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-5 opacity-80">
                <div className="flex justify-between items-start mb-3">
                   <div>
                      <p className="font-black text-slate-800">{req.name}</p>
                      <p className="text-xs font-bold text-slate-500">{req.role}</p>
                   </div>
                   <span className="px-2 py-1 bg-slate-100 text-slate-600 text-[10px] font-black uppercase tracking-wider rounded-lg">{req.type}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-600 font-medium mb-1">
                   <Calendar className="w-4 h-4 text-red-500" />
                   {req.dates} <span className="text-xs text-slate-400">({req.days} days)</span>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-100">
                   <p className="text-xs font-bold text-red-500 mb-1 flex items-center gap-1"><XCircle className="w-3 h-3"/> Rejected Reason:</p>
                   <p className="text-xs text-slate-500 font-medium">{req.reason}</p>
                </div>
             </div>
          ))}
        </div>
      </div>
    </div>
  );
}
