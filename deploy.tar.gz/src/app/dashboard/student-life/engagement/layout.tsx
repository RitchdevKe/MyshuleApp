"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Search, MapPin, Target, Shield, Heart, GraduationCap, Award, BookOpen, Star, BarChart3 } from "lucide-react";

export default function EngagementLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  const tabs = [
    { id: "overview", label: "Overview", icon: Star },
    { id: "portfolio", label: "Student Portfolio", icon: BookOpen },
    { id: "participation", label: "Participation", icon: Target },
    { id: "service", label: "Community Service", icon: Heart },
    { id: "awards", label: "Awards", icon: Award },
    { id: "analytics", label: "Analytics", icon: BarChart3 },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      
      {/* Contextual Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-primary-900 p-5 rounded-3xl border border-primary-800 shadow-lg shadow-primary-900/20">
        <div>
          <h1 className="text-3xl font-black text-white tracking-tight capitalize">
            Student Engagement
          </h1>
          <p className="text-sm text-primary-100 font-medium mt-1">
            The MyShule Student Passport: tracking holistic development and participation.
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="Lookup Student Passport..." 
              className="pl-9 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-secondary-500 focus:border-secondary-500 w-64 shadow-sm"
            />
          </div>
        </div>
      </div>

      {/* Dynamic Tab Navigation */}
      <div className="flex space-x-2 bg-white/40 p-1.5 rounded-2xl overflow-x-auto border border-white/60 backdrop-blur-md shadow-sm hide-scrollbar">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = pathname === `/dashboard/student-life/engagement/${tab.id}`;
          return (
            <Link
              key={tab.id}
              href={`/dashboard/student-life/engagement/${tab.id}`}
              className={`flex items-center gap-2 px-4 py-2.5 text-sm font-bold rounded-xl whitespace-nowrap transition-all duration-300 ${
                isActive
                  ? "bg-secondary-500 text-white shadow-md border-transparent"
                  : "bg-primary-900 text-white hover:bg-primary-800 shadow-sm border-transparent opacity-90 hover:opacity-100"
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </Link>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="bg-white/80 backdrop-blur-lg border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden min-h-[600px]">
        {children}
      </div>
    </div>
  );
}
