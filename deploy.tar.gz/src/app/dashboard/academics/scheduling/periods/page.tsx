"use client";
import React from "react";
import { Search, Plus, MoreHorizontal, Clock, ArrowRight } from "lucide-react";

const mockPeriods = [
  { id: "PRD-001", name: "Assembly", start: "08:00 AM", end: "08:20 AM", type: "Non-Teaching", duration: "20 mins" },
  { id: "PRD-002", name: "Period 1", start: "08:20 AM", end: "09:00 AM", type: "Teaching", duration: "40 mins" },
  { id: "PRD-003", name: "Period 2", start: "09:00 AM", end: "09:40 AM", type: "Teaching", duration: "40 mins" },
  { id: "PRD-004", name: "Break", start: "09:40 AM", end: "10:00 AM", type: "Break", duration: "20 mins" },
  { id: "PRD-005", name: "Period 3", start: "10:00 AM", end: "10:40 AM", type: "Teaching", duration: "40 mins" },
];

export default function PeriodsPage() {
  const getTypeStyle = (type: string) => {
    switch (type) {
      case "Teaching": return "bg-blue-50 text-blue-700 border-blue-200";
      case "Break": return "bg-emerald-50 text-emerald-700 border-emerald-200";
      case "Non-Teaching": return "bg-amber-50 text-amber-700 border-amber-200";
      default: return "bg-slate-50 text-slate-700 border-slate-200";
    }
  };

  return (
    <div className="bg-white/60 backdrop-blur-xl border border-white/60 rounded-3xl shadow-lg overflow-hidden flex flex-col min-h-[400px]">
      
      {/* Toolbar */}
      <div className="p-5 border-b border-slate-200/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative w-full sm:max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search periods..." 
            className="w-full pl-10 pr-4 py-2.5 text-sm font-bold bg-white/80 border border-slate-200/60 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-900 focus:border-primary-900 transition-shadow"
          />
        </div>
        <div className="flex items-center gap-3">
          <select className="px-4 py-2.5 bg-white border border-slate-200/60 rounded-xl text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-900 cursor-pointer">
            <option>Standard Day</option>
            <option>Short Day</option>
          </select>
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-white bg-primary-900 rounded-xl hover:bg-primary-800 transition-colors shadow-sm">
            <Plus className="w-4 h-4" /> Add Period
          </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-x-auto">
        <table className="w-full text-left text-sm text-slate-600">
          <thead className="bg-slate-50/50 text-[10px] uppercase font-black text-slate-500 border-b border-slate-200/60 tracking-wider">
            <tr>
              <th className="px-6 py-4">Period Name</th>
              <th className="px-6 py-4">Time Slot</th>
              <th className="px-6 py-4">Duration</th>
              <th className="px-6 py-4">Type</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200/60">
            {mockPeriods.map((row, i) => (
              <tr key={i} className="hover:bg-white/80 transition-colors group">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-primary-50 text-primary-900 rounded-lg group-hover:bg-primary-100 transition-colors">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div className="flex flex-col">
                      <span className="font-bold text-slate-800">{row.name}</span>
                      <span className="text-xs font-bold text-slate-400">{row.id}</span>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2 font-bold text-slate-700">
                    <span>{row.start}</span>
                    <ArrowRight className="w-3 h-3 text-slate-400" />
                    <span>{row.end}</span>
                  </div>
                </td>
                <td className="px-6 py-4 font-bold text-slate-600">{row.duration}</td>
                <td className="px-6 py-4">
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold border backdrop-blur-sm ${getTypeStyle(row.type)}`}>
                    {row.type}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="p-1.5 text-slate-400 hover:text-primary-900 hover:bg-slate-100 rounded-lg transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100">
                    <MoreHorizontal className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}