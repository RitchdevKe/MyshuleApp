"use client";

import React from "react";
import { Briefcase, Settings2, Users, MapPin, Clock, ArrowRight, Activity } from "lucide-react";

export default function JobOpeningsPage() {
  const jobs = [
    { 
      title: "Senior Mathematics Teacher", 
      department: "Academics", 
      type: "Full-Time",
      location: "Main Campus",
      status: "Active", 
      applicants: 12, 
      daysOpen: 14,
      progress: 45
    },
    { 
      title: "School Nurse", 
      department: "Health & Welfare", 
      type: "Full-Time",
      location: "North Wing Clinic",
      status: "Active", 
      applicants: 5, 
      daysOpen: 4,
      progress: 20
    },
    { 
      title: "Bus Driver", 
      department: "Transport", 
      type: "Part-Time",
      location: "Transport Depot",
      status: "Draft", 
      applicants: 0, 
      daysOpen: 0,
      progress: 0
    },
    { 
      title: "IT Support Technician", 
      department: "IT & Infrastructure", 
      type: "Contract",
      location: "Admin Block",
      status: "Closed", 
      applicants: 24, 
      daysOpen: 30,
      progress: 100
    },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white/80 backdrop-blur-xl border border-white/60 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-4 bg-emerald-50 rounded-2xl text-emerald-600">
             <Briefcase className="w-8 h-8" />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-400 uppercase tracking-wider">Active Openings</p>
            <p className="text-3xl font-black text-slate-800">12</p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-white/60 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-4 bg-primary-50 rounded-2xl text-primary-600">
             <Users className="w-8 h-8" />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-400 uppercase tracking-wider">Total Applicants</p>
            <p className="text-3xl font-black text-slate-800">84</p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-white/60 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-4 bg-secondary-50 rounded-2xl text-secondary-600">
             <Activity className="w-8 h-8" />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-400 uppercase tracking-wider">Avg Time to Hire</p>
            <p className="text-3xl font-black text-slate-800">18 <span className="text-lg text-slate-500 font-bold">days</span></p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {jobs.map((job, i) => (
          <div key={i} className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-6 hover:shadow-xl transition-all duration-300">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-4">
                <div className={`p-3 rounded-2xl ${job.status === 'Active' ? 'bg-emerald-50 text-emerald-600' : job.status === 'Draft' ? 'bg-amber-50 text-amber-600' : 'bg-slate-100 text-slate-500'}`}>
                  <Briefcase className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-800">{job.title}</h3>
                  <p className="text-sm font-bold text-slate-500">{job.department}</p>
                </div>
              </div>
              <button className="p-2 text-slate-400 hover:text-primary-900 bg-slate-50 hover:bg-primary-50 rounded-xl transition-colors">
                <Settings2 className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
               <div className="flex items-center gap-2 text-sm font-medium text-slate-600">
                  <Clock className="w-4 h-4 text-slate-400" />
                  {job.type}
               </div>
               <div className="flex items-center gap-2 text-sm font-medium text-slate-600">
                  <MapPin className="w-4 h-4 text-slate-400" />
                  {job.location}
               </div>
            </div>

            <div className="flex items-center gap-6 mb-6 p-4 bg-slate-50/50 rounded-2xl">
              <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Status</p>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold ${
                    job.status === 'Active' ? 'bg-emerald-100 text-emerald-800' : 
                    job.status === 'Draft' ? 'bg-amber-100 text-amber-800' : 
                    'bg-slate-200 text-slate-800'
                  }`}>
                    {job.status}
                  </span>
              </div>
              <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Days Open</p>
                  <p className="text-sm font-bold text-slate-700">{job.daysOpen}</p>
              </div>
              <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Pipeline</p>
                  <div className="flex items-center gap-2">
                     <div className="w-16 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                        <div className={`h-full ${job.status === 'Active' ? 'bg-emerald-500' : job.status === 'Closed' ? 'bg-slate-400' : 'bg-primary-500'}`} style={{ width: `${job.progress}%` }}></div>
                     </div>
                     <span className="text-xs font-bold text-slate-600">{job.progress}%</span>
                  </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-bold text-slate-600">
                  <Users className="w-4 h-4 text-slate-400" />
                  {job.applicants} Applicants
              </div>
              <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white text-sm font-bold rounded-xl transition-colors shadow-sm shadow-primary-900/20">
                  Manage Pipeline
                  <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
