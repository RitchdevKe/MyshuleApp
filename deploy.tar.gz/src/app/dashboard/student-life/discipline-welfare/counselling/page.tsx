"use client";

import React, { useState } from "react";
import { Stethoscope, Lock, Calendar, Search, ShieldAlert, FileText, ChevronRight } from "lucide-react";

export default function CounsellingPage() {
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [pin, setPin] = useState("");

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === "1234") setIsAuthorized(true); // Mock auth
  };

  if (!isAuthorized) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[600px] bg-slate-50/50 p-8 rounded-3xl">
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-lg text-center max-w-md w-full">
          <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Lock className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-black text-slate-800 mb-2">Restricted Access</h2>
          <p className="text-sm font-medium text-slate-500 mb-8">
            Counselling records contain highly sensitive student data and require safeguard clearance to view. (Use PIN: 1234)
          </p>
          <form onSubmit={handleAuth} className="space-y-4">
            <input
              type="password"
              placeholder="Enter Access PIN"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              className="w-full text-center px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold tracking-[0.5em] focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all"
            />
            <button 
              type="submit"
              className="w-full py-3 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-md shadow-rose-600/20 transition-colors"
            >
              Verify Clearance
            </button>
          </form>
        </div>
      </div>
    );
  }

  const appointments = [
    { time: "09:00 AM", student: "Alice Wambui", type: "Weekly Session", status: "Completed" },
    { time: "11:30 AM", student: "John Kamau", type: "Crisis Assessment", status: "In Progress" },
    { time: "02:00 PM", student: "Mary Wanjiku", type: "Initial Intake", status: "Scheduled" },
  ];

  return (
    <div className="p-8 space-y-6 bg-slate-50/30 rounded-3xl min-h-[600px]">
      
      {/* Secure Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-teal-900 p-5 rounded-2xl border border-teal-800 shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-teal-800 text-teal-100 rounded-xl flex items-center justify-center border border-teal-700">
            <Stethoscope className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white flex items-center gap-2">
              Counselling Secure Dashboard
              <span className="px-2 py-0.5 bg-rose-500 text-white text-[10px] uppercase tracking-wider rounded border border-rose-400">Safeguard Mode</span>
            </h2>
            <p className="text-xs font-bold text-teal-200">Confidential session logs and scheduling</p>
          </div>
        </div>
        <button 
          onClick={() => setIsAuthorized(false)}
          className="px-4 py-2 text-xs font-bold text-teal-100 bg-teal-800 rounded-xl hover:bg-teal-700 transition-colors border border-teal-700"
        >
          Lock Workspace
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Today's Schedule */}
        <div className="lg:col-span-1 bg-white border border-slate-200 rounded-3xl shadow-sm p-6">
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-6 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-slate-400" /> Today's Appointments
          </h3>
          <div className="space-y-4">
            {appointments.map((apt, i) => (
              <div key={i} className="flex gap-4 p-3 bg-slate-50 rounded-xl border border-slate-100">
                <div className="text-xs font-black text-slate-500 w-16 pt-1">{apt.time}</div>
                <div className="flex-1">
                  <div className="text-sm font-bold text-slate-800">{apt.student}</div>
                  <div className="text-xs font-medium text-slate-500">{apt.type}</div>
                  <div className={`mt-2 inline-flex px-2 py-0.5 text-[10px] font-black uppercase tracking-wider border rounded shadow-sm ${
                    apt.status === 'Completed' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' :
                    apt.status === 'In Progress' ? 'bg-amber-50 text-amber-600 border-amber-200' :
                    'bg-white text-slate-600 border-slate-200'
                  }`}>
                    {apt.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-4 py-2 border-2 border-dashed border-slate-200 rounded-xl text-xs font-bold text-slate-500 hover:border-teal-300 hover:text-teal-600 transition-colors">
            + Schedule New
          </button>
        </div>

        {/* Secure Records Search */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl shadow-sm p-6">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4">Secure Records Search</h3>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search student name or ID..." 
                className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all"
              />
            </div>
            
            <div className="mt-6 space-y-3">
              <div className="text-[10px] font-black uppercase text-slate-400 tracking-wider px-2">Recent Access Logs</div>
              {[
                { name: "Alice Wambui", date: "Oct 10, 2026", type: "Session Notes" },
                { name: "Samuel Njoroge", date: "Oct 05, 2026", type: "Intake Form" }
              ].map((log, i) => (
                <div key={i} className="flex items-center justify-between p-3 hover:bg-slate-50 rounded-xl transition-colors cursor-pointer group border border-transparent hover:border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-teal-50 text-teal-600 rounded-lg flex items-center justify-center">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-slate-700">{log.name}</div>
                      <div className="text-xs font-medium text-slate-500">{log.type}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-xs font-bold text-slate-400">{log.date}</span>
                    <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-teal-500 transition-colors" />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-3xl p-6 flex gap-4">
            <div className="w-10 h-10 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-black text-amber-800 mb-1">Safeguarding Alert</h4>
              <p className="text-xs font-medium text-amber-700 leading-relaxed mb-3">
                Remember to log out of this terminal when stepping away. All access to this module is permanently logged and audited by the safeguarding lead.
              </p>
              <button className="text-xs font-bold text-amber-600 hover:text-amber-800 transition-colors underline underline-offset-2">
                View Audit Log
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
