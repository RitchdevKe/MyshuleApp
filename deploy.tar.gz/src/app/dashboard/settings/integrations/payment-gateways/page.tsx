"use client";

import React, { useState } from "react";
import { CreditCard, ExternalLink, Settings, CheckCircle2, AlertTriangle, KeyRound } from "lucide-react";

export default function PaymentGatewaysPage() {
  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <div className="flex items-center gap-3 mb-8">
         <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <CreditCard className="w-5 h-5" />
         </div>
         <div>
            <h3 className="text-xl font-black text-slate-800">Payment Gateways</h3>
            <p className="text-sm font-medium text-slate-500">Configure integrations with mobile money and card processors to accept fee payments.</p>
         </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* M-PESA */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col h-full hover:border-emerald-300 transition-colors">
            <div className="p-5 flex-1">
               <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                     <div className="w-12 h-12 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-black text-xl shadow-inner">
                        M
                     </div>
                     <div>
                        <h4 className="font-black text-slate-800 text-lg">M-PESA Daraja</h4>
                        <div className="flex items-center gap-1.5 mt-0.5">
                           <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                           <span className="text-xs font-bold text-emerald-600">Connected & Active</span>
                        </div>
                     </div>
                  </div>
                  <button className="text-slate-400 hover:text-slate-700 transition-colors">
                     <Settings className="w-5 h-5" />
                  </button>
               </div>
               
               <p className="text-sm text-slate-500 font-medium mb-5">
                  Accept mobile money payments directly through Safaricom's Daraja API. Enables automated fee reconciliation.
               </p>
               
               <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-2">
                  <div className="flex justify-between items-center">
                     <span className="text-xs font-bold text-slate-500">Paybill Number</span>
                     <span className="text-sm font-black text-slate-800">890123</span>
                  </div>
                  <div className="flex justify-between items-center">
                     <span className="text-xs font-bold text-slate-500">Consumer Key</span>
                     <div className="flex items-center gap-2">
                        <span className="text-sm font-mono text-slate-800">••••••••••••••••aB3</span>
                     </div>
                  </div>
               </div>
            </div>
            <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
               <span className="text-xs font-bold text-slate-500">Last synced: 2 mins ago</span>
               <button className="text-xs font-bold text-emerald-600 hover:text-emerald-700 transition-colors flex items-center gap-1">
                  View Logs <ExternalLink className="w-3 h-3" />
               </button>
            </div>
        </div>

        {/* Stripe */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col h-full hover:border-indigo-300 transition-colors opacity-80">
            <div className="p-5 flex-1">
               <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                     <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-black text-xl shadow-inner">
                        S
                     </div>
                     <div>
                        <h4 className="font-black text-slate-800 text-lg">Stripe</h4>
                        <div className="flex items-center gap-1.5 mt-0.5">
                           <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                           <span className="text-xs font-bold text-amber-600">Setup Required</span>
                        </div>
                     </div>
                  </div>
                  <button className="text-slate-400 hover:text-slate-700 transition-colors">
                     <Settings className="w-5 h-5" />
                  </button>
               </div>
               
               <p className="text-sm text-slate-500 font-medium mb-5">
                  Accept international credit and debit cards. Useful for international students and alumni donations.
               </p>
               
               <button className="w-full py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-sm rounded-xl transition-colors border border-indigo-100 flex items-center justify-center gap-2">
                  <KeyRound className="w-4 h-4" /> Enter API Keys
               </button>
            </div>
        </div>

        {/* Bank Transfer (Manual) */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col h-full hover:border-slate-300 transition-colors md:col-span-2">
            <div className="p-5">
               <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                     <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600 shadow-inner">
                        <CreditCard className="w-6 h-6" />
                     </div>
                     <div>
                        <h4 className="font-black text-slate-800 text-lg">Direct Bank Transfers</h4>
                        <div className="flex items-center gap-1.5 mt-0.5">
                           <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                           <span className="text-xs font-bold text-emerald-600">Active</span>
                        </div>
                     </div>
                  </div>
                  <button className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition-colors">
                     Manage Accounts
                  </button>
               </div>
               
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                     <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">Primary Account</div>
                     <div className="text-sm font-bold text-slate-800">KCB Bank - Upperhill Branch</div>
                     <div className="text-sm font-mono text-slate-600 mt-1">1122334455</div>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                     <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">Secondary Account</div>
                     <div className="text-sm font-bold text-slate-800">Equity Bank - Westlands</div>
                     <div className="text-sm font-mono text-slate-600 mt-1">0099887766</div>
                  </div>
               </div>
            </div>
        </div>

      </div>
    </div>
  );
}
