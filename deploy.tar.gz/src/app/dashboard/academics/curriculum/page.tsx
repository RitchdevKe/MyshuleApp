"use client";
import React from "react";
import { BookOpen, Target, Layout, List, CheckCircle2, TrendingUp, AlertTriangle, BookMarked, Activity } from "lucide-react";

export default function CurriculumOverview() {
  return (
    <div className="space-y-6">
      
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl p-6 shadow-lg flex flex-col relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <BookOpen className="w-24 h-24 text-primary-900" />
          </div>
          <div className="flex items-center gap-3 mb-4 relative z-10">
            <div className="w-10 h-10 rounded-xl bg-primary-100 flex items-center justify-center text-primary-700 shadow-sm border border-primary-200">
              <Layout className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-slate-800">Total Subjects</h3>
              <p className="text-xs font-bold text-slate-500">Active Curriculum</p>
            </div>
          </div>
          <div className="mt-auto relative z-10">
            <div className="text-4xl font-black text-primary-950 mb-1">24</div>
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 bg-emerald-50 w-fit px-2 py-0.5 rounded-lg border border-emerald-100">
              <TrendingUp className="w-3.5 h-3.5" /> +2 this year
            </div>
          </div>
        </div>

        <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl p-6 shadow-lg flex flex-col relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <Target className="w-24 h-24 text-secondary-500" />
          </div>
          <div className="flex items-center gap-3 mb-4 relative z-10">
            <div className="w-10 h-10 rounded-xl bg-secondary-50 flex items-center justify-center text-secondary-600 shadow-sm border border-secondary-100">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-slate-800">Syllabus Coverage</h3>
              <p className="text-xs font-bold text-slate-500">School-wide Average</p>
            </div>
          </div>
          <div className="mt-auto relative z-10 w-full">
            <div className="flex justify-between items-end mb-2">
              <div className="text-4xl font-black text-secondary-600">68%</div>
              <span className="text-xs font-bold text-slate-500 mb-1">Target: 75%</span>
            </div>
            <div className="h-2 w-full bg-slate-200/50 rounded-full overflow-hidden shadow-inner">
              <div className="h-full bg-secondary-500 rounded-full" style={{ width: '68%' }} />
            </div>
          </div>
        </div>

        <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl p-6 shadow-lg flex flex-col relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <CheckCircle2 className="w-24 h-24 text-emerald-500" />
          </div>
          <div className="flex items-center gap-3 mb-4 relative z-10">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600 shadow-sm border border-emerald-100">
              <List className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-slate-800">Lesson Plans</h3>
              <p className="text-xs font-bold text-slate-500">Approved this week</p>
            </div>
          </div>
          <div className="mt-auto relative z-10">
            <div className="text-4xl font-black text-emerald-700 mb-1">142</div>
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-600 bg-amber-50 w-fit px-2 py-0.5 rounded-lg border border-amber-100">
              <AlertTriangle className="w-3.5 h-3.5" /> 12 Pending Review
            </div>
          </div>
        </div>

      </div>

      {/* Recent Updates & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Recent Syllabus Updates */}
        <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-black text-slate-800 flex items-center gap-2">
              <BookMarked className="w-5 h-5 text-primary-900" /> Recent Updates
            </h3>
            <button className="text-xs font-bold text-secondary-600 hover:text-secondary-700 bg-secondary-50 px-3 py-1 rounded-lg transition-colors">
              View All
            </button>
          </div>
          
          <div className="space-y-3">
            {[
              { title: "Grade 4 Mathematics", desc: "Term 2 Topic 3 Completed", time: "Today, 10:30 AM", type: "completion", icon: CheckCircle2, color: "emerald" },
              { title: "CBC Framework", desc: "Updated learning objectives for Grade 1", time: "Yesterday", type: "update", icon: BookOpen, color: "indigo" },
              { title: "Grade 6 Science", desc: "New lesson plan pending approval", time: "2 days ago", type: "pending", icon: AlertTriangle, color: "amber" },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <div key={i} className="flex items-center justify-between p-4 bg-white/80 border border-slate-100 rounded-2xl shadow-sm hover:shadow-md transition-shadow group cursor-pointer">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-xl bg-${item.color}-50 flex items-center justify-center text-${item.color}-600 border border-${item.color}-100 flex-shrink-0 group-hover:scale-110 transition-transform`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-black text-slate-800">{item.title}</p>
                      <p className="text-xs font-bold text-slate-500 mt-0.5">{item.desc}</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-slate-400 whitespace-nowrap bg-slate-50 px-2 py-1 rounded-md border border-slate-100">
                    {item.time}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Coverage by Learning Area */}
        <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg p-6">
          <h3 className="text-lg font-black text-slate-800 flex items-center gap-2 mb-6">
            <Target className="w-5 h-5 text-secondary-500" /> Top Learning Areas
          </h3>
          
          <div className="space-y-5">
            {[
              { name: "Mathematics Activities", progress: 85, target: 80, color: "bg-indigo-500" },
              { name: "Language Activities", progress: 72, target: 75, color: "bg-emerald-500" },
              { name: "Environmental Activities", progress: 60, target: 75, color: "bg-amber-500" },
              { name: "Creative Arts", progress: 45, target: 50, color: "bg-rose-500" },
            ].map((area, i) => (
              <div key={i}>
                <div className="flex justify-between text-xs font-bold mb-1.5">
                  <span className="text-slate-700">{area.name}</span>
                  <div className="flex items-center gap-3">
                    <span className="text-slate-400">Target: {area.target}%</span>
                    <span className="text-primary-900">{area.progress}%</span>
                  </div>
                </div>
                <div className="h-2 w-full bg-slate-200/50 rounded-full overflow-hidden shadow-inner relative">
                  {/* Target Marker */}
                  <div className="absolute top-0 bottom-0 w-0.5 bg-slate-400 z-10" style={{ left: `${area.target}%` }} />
                  <div className={`h-full rounded-full ${area.color}`} style={{ width: `${area.progress}%` }} />
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 p-4 bg-primary-50/50 border border-primary-100 rounded-2xl flex items-start gap-3">
            <div className="mt-0.5 w-2 h-2 rounded-full bg-primary-500 animate-pulse flex-shrink-0" />
            <p className="text-xs font-bold text-primary-800 leading-relaxed">
              Environmental Activities and Creative Arts are falling slightly behind the expected Term 2 targets. Consider scheduling review meetings with heads of department.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}