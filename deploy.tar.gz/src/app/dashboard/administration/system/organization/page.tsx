"use client";

import React from "react";
import { Network, MapPin, Users, ChevronRight, Plus } from "lucide-react";

export default function OrganizationPage() {
  const structure = [
    {
      name: "Main Campus (Nairobi)",
      type: "Campus",
      head: "Dr. Sarah Johnson",
      departments: [
        { name: "Early Childhood (Pre-K to K)", head: "Mary Omondi", staff: 12 },
        { name: "Primary School (Grades 1-5)", head: "Peter Kamau", staff: 45 },
        { name: "Middle School (Grades 6-8)", head: "Jane Wanjiku", staff: 30 },
        { name: "High School (Grades 9-12)", head: "David Ochieng", staff: 55 },
      ]
    },
    {
      name: "Mombasa Branch",
      type: "Campus",
      head: "Prof. Ahmed Ali",
      departments: [
        { name: "Primary School (Grades 1-5)", head: "Fatuma Hassan", staff: 25 },
        { name: "Middle School (Grades 6-8)", head: "Ali Hussein", staff: 18 },
      ]
    }
  ];

  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden min-h-[500px]">
      <div className="p-6 border-b border-slate-200/60 flex justify-between items-center bg-slate-50/50">
         <div>
            <h2 className="text-xl font-black text-slate-800">Organization Structure</h2>
            <p className="text-sm font-medium text-slate-500 mt-1">Manage your institution's hierarchical structure (campuses, branches, departments).</p>
         </div>
         <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
            <Plus className="w-4 h-4" /> Add Campus
         </button>
      </div>

      <div className="p-6 space-y-8">
         {structure.map((campus, idx) => (
            <div key={idx} className="bg-white border border-slate-200/60 rounded-2xl shadow-sm overflow-hidden">
               {/* Campus Header */}
               <div className="bg-slate-50 border-b border-slate-200/60 p-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div className="flex items-center gap-4">
                     <div className="w-12 h-12 bg-primary-100 text-primary-700 rounded-xl flex items-center justify-center shrink-0 shadow-inner">
                        <MapPin className="w-6 h-6" />
                     </div>
                     <div>
                        <h3 className="text-lg font-black text-slate-800 flex items-center gap-2">
                           {campus.name}
                           <span className="px-2 py-0.5 text-[10px] uppercase tracking-wider font-black bg-white border border-slate-200 text-slate-500 rounded-lg">{campus.type}</span>
                        </h3>
                        <p className="text-sm font-medium text-slate-500 mt-0.5">Campus Head: <span className="font-bold text-slate-700">{campus.head}</span></p>
                     </div>
                  </div>
                  <div className="flex gap-2 w-full md:w-auto">
                     <button className="px-3 py-1.5 text-xs font-bold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors">Edit</button>
                     <button className="px-3 py-1.5 text-xs font-bold text-primary-600 bg-primary-50 hover:bg-primary-100 rounded-lg transition-colors flex items-center gap-1"><Plus className="w-3 h-3" /> Dept</button>
                  </div>
               </div>

               {/* Departments */}
               <div className="p-5">
                  <div className="text-xs font-black text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                     <Network className="w-4 h-4" /> Departments
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                     {campus.departments.map((dept, dIdx) => (
                        <div key={dIdx} className="group flex items-center justify-between p-4 border border-slate-200/60 hover:border-primary-300 rounded-xl bg-white transition-all cursor-pointer hover:shadow-sm">
                           <div>
                              <h4 className="font-bold text-sm text-slate-800 group-hover:text-primary-700 transition-colors">{dept.name}</h4>
                              <p className="text-xs font-medium text-slate-500 mt-0.5">Head: {dept.head}</p>
                           </div>
                           <div className="flex items-center gap-4 text-slate-400">
                              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-500 bg-slate-50 px-2 py-1 rounded-lg border border-slate-100">
                                 <Users className="w-3.5 h-3.5" />
                                 {dept.staff}
                              </div>
                              <ChevronRight className="w-4 h-4 group-hover:text-primary-500 transition-colors" />
                           </div>
                        </div>
                     ))}
                  </div>
               </div>
            </div>
         ))}
      </div>
    </div>
  );
}
