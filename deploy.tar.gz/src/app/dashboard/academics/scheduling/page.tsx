import { redirect } from "next/navigation";

export default function SchedulingPage() {
  redirect("/dashboard/academics/scheduling/timetables");
}