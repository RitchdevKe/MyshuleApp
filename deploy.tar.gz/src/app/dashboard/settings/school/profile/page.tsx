"use client";

import React from "react";
import { Building2, UploadCloud, Info } from "lucide-react";

export default function ProfilePage() {
  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <div className="flex items-center gap-3 mb-8">
         <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Building2 className="w-5 h-5" />
         </div>
         <div>
            <h3 className="text-xl font-black text-slate-800">School Profile</h3>
            <p className="text-sm font-medium text-slate-500">Official information used on reports, certificates, and billing.</p>
         </div>
      </div>
      
      <div className="space-y-8">
        
        {/* Cover & Logo Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
           <div className="col-span-1">
              <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-2">School Badge / Crest</label>
              <div className="border-2 border-dashed border-slate-200 rounded-2xl h-40 flex flex-col items-center justify-center bg-slate-50 hover:bg-slate-100 transition-colors cursor-pointer group">
                 <UploadCloud className="w-8 h-8 text-slate-400 group-hover:text-indigo-500 transition-colors mb-2" />
                 <span className="text-xs font-bold text-slate-500">Upload Image</span>
              </div>
           </div>
           <div className="col-span-2">
              <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-2">Cover Image (Portal Login)</label>
              <div className="border-2 border-dashed border-slate-200 rounded-2xl h-40 flex flex-col items-center justify-center bg-slate-50 hover:bg-slate-100 transition-colors cursor-pointer group relative overflow-hidden">
                 <div className="absolute inset-0 bg-indigo-900/10 z-0"></div>
                 <UploadCloud className="w-8 h-8 text-slate-400 group-hover:text-indigo-500 transition-colors mb-2 z-10" />
                 <span className="text-xs font-bold text-slate-500 z-10">Upload Landscape Image</span>
              </div>
           </div>
        </div>

        <div className="h-px w-full bg-slate-100"></div>

        {/* Basic Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">School Name (Display)</label>
            <input type="text" defaultValue="Green Valley Academy" className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm" />
          </div>
          <div>
            <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Official Legal Name (For Documents)</label>
            <input type="text" defaultValue="Green Valley International Academy Ltd" className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm" />
          </div>
          <div>
            <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1 flex items-center gap-1">
               Registration Number <Info className="w-3 h-3 text-slate-400" />
            </label>
            <input type="text" defaultValue="REG-2015-0042" className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm" />
          </div>
          <div>
            <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Tax ID / KRA PIN</label>
            <input type="text" defaultValue="P012345678Z" className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm" />
          </div>
          <div className="md:col-span-2">
            <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">School Motto</label>
            <input type="text" defaultValue="Excellence through discipline and hard work" className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm" />
          </div>
        </div>

        <div className="h-px w-full bg-slate-100"></div>

        {/* Location */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="md:col-span-2">
            <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Physical Address</label>
            <textarea rows={3} defaultValue="123 Valley Road, Kileleshwa&#10;P.O. Box 45678 - 00100&#10;Nairobi, Kenya" className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm resize-none"></textarea>
          </div>
          <div>
             <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Country</label>
             <select className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm appearance-none">
                <option value="KE">Kenya</option>
                <option value="UG">Uganda</option>
                <option value="TZ">Tanzania</option>
                <option value="RW">Rwanda</option>
             </select>
          </div>
          <div>
             <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Timezone</label>
             <select className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm appearance-none">
                <option value="EAT">Africa/Nairobi (EAT)</option>
                <option value="CAT">Africa/Kigali (CAT)</option>
                <option value="SAST">Africa/Johannesburg (SAST)</option>
             </select>
          </div>
        </div>

      </div>
    </div>
  );
}
