"use client";

import React, { useState } from "react";
import {
  MoreHorizontal, Calendar, MessageSquare, Plus, ArrowRight,
  User, GraduationCap, Phone, AlertTriangle, CheckCircle2,
  ChevronRight, X, Hash, Shield, Search
} from "lucide-react";

type Stage = "applied" | "review" | "interview" | "admitted" | "rejected";

interface Applicant {
  id: string;
  admNo: string;       // auto-generated admission number
  name: string;
  grade: string;
  parent: string;
  phone: string;
  date: string;
  alert: boolean;
  initials: string;
}

// ── Grade ordering for admission number sequencing (highest grade first) ──────
const GRADE_ORDER: Record<string, number> = {
  "Grade 9": 1, "Grade 8": 2, "Grade 7": 3,
  "Grade 6": 4, "Grade 5": 5, "Grade 4": 6,
  "Grade 3": 7, "Grade 2": 8, "Grade 1": 9,
  "Pre-Primary": 10,
};

/** Generates an admission number: {YEAR}-{GRADE_CODE}-{SEQ 3-digit}  */
function generateAdmNo(grade: string, seq: number): string {
  const year = new Date().getFullYear();
  const gradeCode = grade.replace(/\s+/g, "").replace("Grade", "G").replace("Pre-Primary", "PP");
  return `${year}-${gradeCode}-${String(seq).padStart(3, "0")}`;
}

const columns: { id: Stage; title: string; count: number; colorClass: string; headerGrad: string; cardBorder: string; badge: string }[] = [
  { id: "applied",   title: "Applied",   count: 3,  colorClass: "from-primary-900 to-primary-700", headerGrad: "bg-primary-900", cardBorder: "border-primary-100 hover:border-primary-300", badge: "bg-primary-100 text-primary-800 border-primary-200" },
  { id: "review",    title: "In Review", count: 2,  colorClass: "from-amber-600 to-amber-500",      headerGrad: "bg-amber-600",   cardBorder: "border-amber-100 hover:border-amber-300",   badge: "bg-amber-100 text-amber-800 border-amber-200" },
  { id: "interview", title: "Interview", count: 1,  colorClass: "from-indigo-600 to-violet-600",    headerGrad: "bg-indigo-600",  cardBorder: "border-indigo-100 hover:border-indigo-300", badge: "bg-indigo-100 text-indigo-800 border-indigo-200" },
  { id: "admitted",  title: "Admitted",  count: 2,  colorClass: "from-emerald-600 to-teal-600",     headerGrad: "bg-emerald-600", cardBorder: "border-emerald-100 hover:border-emerald-300", badge: "bg-emerald-100 text-emerald-800 border-emerald-200" },
  { id: "rejected",  title: "Rejected",  count: 1,  colorClass: "from-rose-600 to-red-600",         headerGrad: "bg-rose-600",    cardBorder: "border-rose-100 hover:border-rose-300",     badge: "bg-rose-100 text-rose-800 border-rose-200" },
];

const initialCards: Record<Stage, Applicant[]> = {
  applied: [
    { id: "APP-012", admNo: generateAdmNo("Grade 4", 1), name: "Mercy Wanjiru",  grade: "Grade 4", parent: "James Wanjiru",   phone: "0712 345 678", date: "Today",     alert: true,  initials: "MW" },
    { id: "APP-011", admNo: generateAdmNo("Grade 1", 2), name: "Kevin Kiprop",   grade: "Grade 1", parent: "Alice Kiprop",    phone: "0723 456 789", date: "Yesterday", alert: false, initials: "KK" },
    { id: "APP-010", admNo: generateAdmNo("Grade 1", 3), name: "Esther Achieng", grade: "Grade 1", parent: "Mark Achieng",    phone: "0734 567 890", date: "2 days ago",alert: false, initials: "EA" },
  ],
  review: [
    { id: "APP-009", admNo: generateAdmNo("Grade 5", 4), name: "Brian Mutua",  grade: "Grade 5", parent: "Catherine Mutua", phone: "0745 678 901", date: "Sep 12", alert: false, initials: "BM" },
    { id: "APP-008", admNo: generateAdmNo("Grade 2", 5), name: "Faith Njeri",  grade: "Grade 2", parent: "Joseph Njeri",    phone: "0756 789 012", date: "Sep 11", alert: true,  initials: "FN" },
  ],
  interview: [
    { id: "APP-007", admNo: generateAdmNo("Grade 6", 6), name: "Dennis Omondi", grade: "Grade 6", parent: "Ruth Omondi", phone: "0767 890 123", date: "Oct 1", alert: false, initials: "DO" },
  ],
  admitted: [
    { id: "APP-006", admNo: generateAdmNo("Grade 4", 7), name: "Joy Wangari",   grade: "Grade 4", parent: "Simon Wangari", phone: "0778 901 234", date: "Completed", alert: false, initials: "JW" },
    { id: "APP-005", admNo: generateAdmNo("Grade 3", 8), name: "Samuel Kimani", grade: "Grade 3", parent: "Mary Kimani",   phone: "0789 012 345", date: "Completed", alert: false, initials: "SK" },
  ],
  rejected: [
    { id: "APP-004", admNo: generateAdmNo("Grade 7", 9), name: "Peter Otieno", grade: "Grade 7", parent: "Anne Otieno", phone: "0700 123 456", date: "Oct 3", alert: false, initials: "PO" },
  ],
};

const GRADE_OPTIONS = [
  "Grade 1","Grade 2","Grade 3","Grade 4","Grade 5",
  "Grade 6","Grade 7","Grade 8","Grade 9","Pre-Primary",
];

const avatarGrads = [
  "from-primary-700 to-primary-900",
  "from-secondary-500 to-secondary-700",
  "from-indigo-500 to-violet-600",
  "from-emerald-500 to-teal-600",
  "from-amber-500 to-orange-600",
];

export default function AdmissionsPage() {
  const [cards, setCards] = useState(initialCards);

  // Modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({ name: "", grade: "Grade 1", parent: "", phone: "" });
  const [duplicate, setDuplicate] = useState<Applicant | null>(null);

  // Count all applicants to generate next seq
  const totalCount = Object.values(cards).flat().length;

  const allApplicants = Object.values(cards).flat();

  // Duplicate check: same name + parent combo
  function checkDuplicate(name: string, parent: string): Applicant | null {
    const n = name.trim().toLowerCase();
    const p = parent.trim().toLowerCase();
    if (!n || !p) return null;
    return allApplicants.find(a =>
      a.name.toLowerCase() === n && a.parent.toLowerCase() === p
    ) ?? null;
  }

  function handleFormChange(field: string, value: string) {
    const next = { ...form, [field]: value };
    setForm(next);
    if (field === "name" || field === "parent") {
      setDuplicate(checkDuplicate(next.name, next.parent));
    }
  }

  function handleSubmit() {
    if (!form.name || !form.parent || !form.phone) return;
    const seq = totalCount + 1;
    // Sort admitted students by grade order (highest grade first) for proper admission no seq
    const newApplicant: Applicant = {
      id: `APP-${String(seq).padStart(3, "0")}`,
      admNo: generateAdmNo(form.grade, seq),
      name: form.name.trim(),
      grade: form.grade,
      parent: form.parent.trim(),
      phone: form.phone.trim(),
      date: "Today",
      alert: false,
      initials: form.name.trim().split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase(),
    };
    setCards(prev => ({ ...prev, applied: [newApplicant, ...prev.applied] }));
    setForm({ name: "", grade: "Grade 1", parent: "", phone: "" });
    setDuplicate(null);
    setModalOpen(false);
  }

  const totalAll = Object.values(cards).flat().length;

  return (
    <div>
      {/* Pipeline total bar */}
      <div className="flex items-center gap-2 mb-4">
        <div className="h-2 rounded-full bg-primary-900 flex-[3]"  title="Applied" />
        <div className="h-2 rounded-full bg-amber-500 flex-[2]"    title="In Review" />
        <div className="h-2 rounded-full bg-indigo-600 flex-[1]"   title="Interview" />
        <div className="h-2 rounded-full bg-emerald-500 flex-[2]"  title="Admitted" />
        <div className="h-2 rounded-full bg-rose-500 flex-[1]"     title="Rejected" />
        <span className="text-xs font-black text-slate-500 ml-1">{totalAll} total</span>

        {/* New Applicant Button */}
        <button
          id="new-applicant-btn"
          onClick={() => setModalOpen(true)}
          className="ml-auto flex items-center gap-2 px-4 py-2 text-xs font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all"
        >
          <Plus className="w-3.5 h-3.5" /> New Applicant
        </button>
      </div>

      {/* Kanban columns */}
      <div className="flex gap-4 overflow-x-auto pb-8 min-h-[560px] hide-scrollbar">
        {columns.map((col, ci) => {
          const colCards = cards[col.id];
          return (
            <div
              key={col.id}
              className="flex-none w-72 flex flex-col rounded-2xl overflow-hidden bg-white/60 backdrop-blur-xl border border-white/80 shadow-md"
            >
              {/* Column header */}
              <div className={`bg-gradient-to-r ${col.colorClass} p-3.5 flex items-center justify-between`}>
                <div>
                  <p className="text-xs font-black text-white uppercase tracking-wider">{col.title}</p>
                  <p className="text-lg font-black text-white/90 mt-0.5">{colCards.length}</p>
                </div>
                <button className="w-7 h-7 bg-white/20 hover:bg-white/30 rounded-xl flex items-center justify-center transition-colors">
                  <MoreHorizontal className="w-4 h-4 text-white" />
                </button>
              </div>

              {/* Cards */}
              <div className="flex-1 p-2.5 space-y-2.5 overflow-y-auto bg-slate-50/60">
                {colCards.map((card, i) => (
                  <div
                    key={card.id}
                    className={`bg-white rounded-xl border ${col.cardBorder} shadow-sm hover:shadow-md cursor-pointer transition-all group relative overflow-hidden`}
                  >
                    {/* Alert corner */}
                    {card.alert && (
                      <div className="absolute top-0 right-0 px-1.5 py-0.5 bg-secondary-500 rounded-bl-xl">
                        <AlertTriangle className="w-3 h-3 text-white" />
                      </div>
                    )}

                    <div className="p-3.5">
                      {/* Admission Number */}
                      <div className="flex items-center gap-1 mb-1.5">
                        <Hash className="w-2.5 h-2.5 text-primary-400" />
                        <p className="text-[10px] font-black text-primary-600 tracking-wider">{card.admNo}</p>
                      </div>

                      {/* Avatar + Name */}
                      <div className="flex items-center gap-2.5 mb-3">
                        <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${avatarGrads[(ci + i) % avatarGrads.length]} flex items-center justify-center text-white text-[10px] font-black shadow-sm flex-shrink-0`}>
                          {card.initials}
                        </div>
                        <div>
                          <p className="font-black text-slate-800 text-sm leading-tight">{card.name}</p>
                          <p className="text-[10px] font-bold text-slate-400">{card.parent}</p>
                        </div>
                      </div>

                      {/* Meta */}
                      <div className="flex items-center gap-1.5 flex-wrap mb-3">
                        <span className={`flex items-center gap-1 text-[10px] font-black px-2 py-0.5 rounded-lg border ${col.badge}`}>
                          <GraduationCap className="w-2.5 h-2.5" />
                          {card.grade}
                        </span>
                        <span className="flex items-center gap-1 text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-lg">
                          <Phone className="w-2.5 h-2.5" />
                          {card.phone}
                        </span>
                      </div>

                      {/* Footer */}
                      <div className="flex items-center justify-between pt-2.5 border-t border-slate-100">
                        <div className="flex items-center gap-1 text-[10px] font-bold text-slate-400">
                          <Calendar className="w-3 h-3" />
                          {card.date}
                        </div>
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button className="p-1 rounded-md text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors">
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>
                          <button className="p-1 rounded-md text-slate-400 hover:text-primary-700 hover:bg-primary-50 transition-colors">
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}

                <button
                  onClick={() => setModalOpen(true)}
                  className="w-full py-2.5 flex items-center justify-center gap-1.5 text-xs font-bold text-slate-400 hover:text-slate-600 hover:bg-white rounded-xl border border-dashed border-slate-300 transition-all"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Applicant
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* ── New Applicant Modal ─────────────────────────────────────── */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-primary-950/60 backdrop-blur-sm"
            onClick={() => { setModalOpen(false); setDuplicate(null); }}
          />

          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Modal header */}
            <div className="bg-gradient-to-r from-primary-900 to-primary-700 px-6 py-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-black uppercase tracking-widest text-white/60">Registration</p>
                <h2 className="text-lg font-black text-white">New Applicant</h2>
              </div>
              <button
                onClick={() => { setModalOpen(false); setDuplicate(null); }}
                className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="px-6 py-5 space-y-4">
              {/* Admission Number Preview */}
              <div className="flex items-center gap-2 bg-primary-50 border border-primary-100 rounded-xl px-4 py-2.5">
                <Hash className="w-4 h-4 text-primary-400 flex-shrink-0" />
                <div>
                  <p className="text-[10px] font-black text-primary-400 uppercase tracking-wider">Auto Admission No.</p>
                  <p className="text-sm font-black text-primary-800">{generateAdmNo(form.grade, totalCount + 1)}</p>
                </div>
                <Shield className="w-3.5 h-3.5 text-primary-300 ml-auto" aria-label="System-generated, tamper-proof" />
              </div>

              {/* Duplicate Warning */}
              {duplicate && (
                <div className="flex items-start gap-2.5 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3">
                  <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-black text-amber-700">Possible Duplicate Detected</p>
                    <p className="text-[11px] text-amber-600 mt-0.5">
                      <strong>{duplicate.name}</strong> (parent: {duplicate.parent}) already exists as <strong>{duplicate.admNo}</strong>.
                      Please verify before proceeding.
                    </p>
                  </div>
                </div>
              )}

              {/* Form fields */}
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Student Full Name *</label>
                  <input
                    value={form.name}
                    onChange={e => handleFormChange("name", e.target.value)}
                    placeholder="e.g. Mary Wanjiku"
                    className="w-full px-3 py-2 text-sm font-bold border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-300 focus:border-primary-300 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Grade *</label>
                  <select
                    value={form.grade}
                    onChange={e => handleFormChange("grade", e.target.value)}
                    className="w-full px-3 py-2 text-sm font-bold border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-300 focus:border-primary-300 bg-white transition-all"
                  >
                    {GRADE_OPTIONS.map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Parent Phone *</label>
                  <input
                    value={form.phone}
                    onChange={e => handleFormChange("phone", e.target.value)}
                    placeholder="07XX XXX XXX"
                    className="w-full px-3 py-2 text-sm font-bold border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-300 focus:border-primary-300 transition-all"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Parent / Guardian Name *</label>
                  <input
                    value={form.parent}
                    onChange={e => handleFormChange("parent", e.target.value)}
                    placeholder="e.g. Peter Wanjiku"
                    className="w-full px-3 py-2 text-sm font-bold border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-300 focus:border-primary-300 transition-all"
                  />
                </div>
              </div>
            </div>

            {/* Modal footer */}
            <div className="px-6 pb-5 flex items-center justify-end gap-2">
              <button
                onClick={() => { setModalOpen(false); setDuplicate(null); }}
                className="px-4 py-2 text-sm font-black text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
              >
                Cancel
              </button>
              <button
                id="submit-new-applicant"
                onClick={handleSubmit}
                disabled={!form.name || !form.parent || !form.phone}
                className="px-5 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 disabled:opacity-40 disabled:cursor-not-allowed rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                Register Applicant
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}