"use client";

import React from "react";
import { MessageSquare, ExternalLink, Settings, CheckCircle2, AlertTriangle, KeyRound, Smartphone } from "lucide-react";

export default function SmsProvidersPage() {
  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <div className="flex items-center gap-3 mb-8">
         <div className="w-10 h-10 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center">
            <MessageSquare className="w-5 h-5" />
         </div>
         <div>
            <h3 className="text-xl font-black text-slate-800">SMS Providers</h3>
            <p className="text-sm font-medium text-slate-500">Configure third-party bulk SMS and USSD gateways.</p>
         </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Africa's Talking */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col h-full hover:border-violet-300 transition-colors">
            <div className="p-5 flex-1">
               <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                     <div className="w-12 h-12 bg-orange-500 rounded-xl flex items-center justify-center text-white font-black text-xl shadow-inner">
                        AT
                     </div>
                     <div>
                        <h4 className="font-black text-slate-800 text-lg">Africa's Talking</h4>
                        <div className="flex items-center gap-1.5 mt-0.5">
                           <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                           <span className="text-xs font-bold text-emerald-600">Connected</span>
                        </div>
                     </div>
                  </div>
                  <button className="text-slate-400 hover:text-slate-700 transition-colors">
                     <Settings className="w-5 h-5" />
                  </button>
               </div>
               
               <p className="text-sm text-slate-500 font-medium mb-5">
                  Primary provider for bulk SMS, shortcodes, and USSD. Highly reliable across Africa.
               </p>
               
               <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-2">
                  <div className="flex justify-between items-center">
                     <span className="text-xs font-bold text-slate-500">Username</span>
                     <span className="text-sm font-black text-slate-800">kepler_edu_prod</span>
                  </div>
                  <div className="flex justify-between items-center">
                     <span className="text-xs font-bold text-slate-500">API Key</span>
                     <div className="flex items-center gap-2">
                        <span className="text-sm font-mono text-slate-800">••••••••••••••••f9A</span>
                     </div>
                  </div>
                  <div className="flex justify-between items-center pt-2 border-t border-slate-200/60 mt-2">
                     <span className="text-xs font-bold text-slate-500">Sender ID</span>
                     <span className="text-sm font-black text-violet-700 bg-violet-50 px-2 py-0.5 rounded">KEPLER_SCH</span>
                  </div>
               </div>
            </div>
            <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
               <span className="text-xs font-bold text-slate-500">Balance: KSh 4,520.00</span>
               <button className="text-xs font-bold text-violet-600 hover:text-violet-700 transition-colors flex items-center gap-1">
                  Dashboard <ExternalLink className="w-3 h-3" />
               </button>
            </div>
        </div>

        {/* Twilio */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col h-full hover:border-red-300 transition-colors opacity-80">
            <div className="p-5 flex-1">
               <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                     <div className="w-12 h-12 bg-red-600 rounded-xl flex items-center justify-center text-white font-black text-xl shadow-inner">
                        T
                     </div>
                     <div>
                        <h4 className="font-black text-slate-800 text-lg">Twilio</h4>
                        <div className="flex items-center gap-1.5 mt-0.5">
                           <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                           <span className="text-xs font-bold text-amber-600">Setup Required</span>
                        </div>
                     </div>
                  </div>
                  <button className="text-slate-400 hover:text-slate-700 transition-colors">
                     <Settings className="w-5 h-5" />
                  </button>
               </div>
               
               <p className="text-sm text-slate-500 font-medium mb-5">
                  Fallback provider for international SMS and WhatsApp business API integrations.
               </p>
               
               <button className="w-full py-2.5 bg-red-50 hover:bg-red-100 text-red-700 font-bold text-sm rounded-xl transition-colors border border-red-100 flex items-center justify-center gap-2">
                  <KeyRound className="w-4 h-4" /> Enter Auth Token
               </button>
            </div>
        </div>

      </div>
    </div>
  );
}
