"use client";

import React, { useState } from "react";
import { Search, Filter, Mail, Phone, MoreVertical } from "lucide-react";

export default function UsersPage() {
  const users = [
    { id: 1, name: "Jane Wanjiku", email: "jane.w@school.edu", phone: "+254 712 345 678", role: "Teacher", dept: "Academics", status: "Active" },
    { id: 2, name: "Peter Kamau", email: "p.kamau@school.edu", phone: "+254 723 456 789", role: "Bursar", dept: "Finance", status: "Active" },
    { id: 3, name: "Sarah Omondi", email: "sarah.o@gmail.com", phone: "+254 734 567 890", role: "Parent", dept: "External", status: "Active" },
    { id: 4, name: "David Kiprono", email: "david.k@school.edu", phone: "+254 745 678 901", role: "IT Support", dept: "Operations", status: "Suspended" },
    { id: 5, name: "Dr. Alice Mumbi", email: "a.mumbi@school.edu", phone: "+254 756 789 012", role: "Principal", dept: "Administration", status: "Active" },
  ];

  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden min-h-[500px]">
      <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50/50">
         <div className="flex items-center gap-2 w-full md:w-auto relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input type="text" placeholder="Search users by name or email..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
         </div>
         <div className="flex gap-2">
            <select className="px-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-900 cursor-pointer">
               <option>All Roles</option>
               <option>Teacher</option>
               <option>Parent</option>
               <option>Admin</option>
            </select>
            <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
               <Filter className="w-4 h-4" />
               Filter
            </button>
         </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50">
              <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">User</th>
              <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Contact</th>
              <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Role & Dept</th>
              <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
              <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {users.map((user) => (
              <tr key={user.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="py-4 px-6">
                   <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center font-bold text-sm shadow-inner">
                         {user.name.charAt(0)}
                      </div>
                      <div>
                         <div className="font-bold text-sm text-slate-800">{user.name}</div>
                         <div className="text-xs font-medium text-slate-500">{user.email}</div>
                      </div>
                   </div>
                </td>
                <td className="py-4 px-6">
                   <div className="flex flex-col gap-1">
                      <span className="flex items-center gap-1.5 text-xs text-slate-600"><Phone className="w-3.5 h-3.5 text-slate-400" /> {user.phone}</span>
                   </div>
                </td>
                <td className="py-4 px-6">
                   <div className="font-bold text-sm text-slate-700">{user.role}</div>
                   <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 mt-0.5">{user.dept}</div>
                </td>
                <td className="py-4 px-6">
                   <span className={`inline-flex items-center px-2.5 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg ${user.status === 'Active' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                      {user.status}
                   </span>
                </td>
                <td className="py-4 px-6 text-right">
                   <div className="flex items-center justify-end gap-2">
                      <button className="text-white bg-primary-900 hover:bg-primary-800 px-4 py-2 rounded-xl transition-all shadow-sm shadow-primary-900/20 font-bold text-sm">
                         Manage
                      </button>
                      <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                         <MoreVertical className="w-5 h-5" />
                      </button>
                   </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
