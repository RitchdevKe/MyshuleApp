"use client";

import React from "react";
import { Search, ShieldAlert, Key, Plus, Lock } from "lucide-react";

export default function PoliciesPage() {
  const policies = [
    { id: 1, name: "MFA Requirement for Finance", description: "Enforces Multi-Factor Authentication for any user attempting to access the Finance module.", status: "Active", scope: "Bursar, Admin" },
    { id: 2, name: "Grade Editing Window", description: "Restricts grade modification to only the last 2 weeks of the term.", status: "Active", scope: "Teachers" },
    { id: 3, name: "Off-Campus Access Restriction", description: "Blocks access to sensitive student records from non-whitelisted IP addresses.", status: "Inactive", scope: "All Users" },
    { id: 4, name: "Session Timeout", description: "Automatically logs out inactive sessions after 15 minutes of idle time.", status: "Active", scope: "All Users" },
  ];

  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden min-h-[500px]">
      <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50/50">
         <div className="flex items-center gap-2 w-full md:w-auto relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input type="text" placeholder="Search policies..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
         </div>
         <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
            <Plus className="w-4 h-4" />
            New Policy
         </button>
      </div>

      <div className="p-6 grid grid-cols-1 gap-4">
         {policies.map((policy) => (
            <div key={policy.id} className="bg-white border border-slate-200 p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-primary-400 hover:shadow-sm transition-all group">
               <div className="flex items-start gap-4">
                  <div className={`mt-1 p-2.5 rounded-xl shrink-0 ${policy.status === 'Active' ? 'bg-primary-50 text-primary-600' : 'bg-slate-100 text-slate-400'}`}>
                     {policy.status === 'Active' ? <ShieldAlert className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
                  </div>
                  <div>
                     <div className="flex items-center gap-2 mb-1">
                        <h4 className={`font-bold text-lg ${policy.status === 'Active' ? 'text-slate-800' : 'text-slate-500'}`}>{policy.name}</h4>
                        <span className={`px-2 py-0.5 text-[10px] font-black uppercase tracking-wider rounded-md ${policy.status === 'Active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                           {policy.status}
                        </span>
                     </div>
                     <p className={`text-sm font-medium ${policy.status === 'Active' ? 'text-slate-500' : 'text-slate-400'} max-w-2xl`}>{policy.description}</p>
                     
                     <div className="mt-3 flex items-center gap-2">
                        <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">Scope:</span>
                        <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2 py-1 rounded-lg">{policy.scope}</span>
                     </div>
                  </div>
               </div>
               
               <div className="flex items-center gap-2 md:self-end">
                  <button className="px-4 py-2 text-xs font-bold bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl transition-colors">
                     Edit Policy
                  </button>
                  {policy.status === 'Active' ? (
                     <button className="px-4 py-2 text-xs font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl transition-colors border border-rose-100">
                        Disable
                     </button>
                  ) : (
                     <button className="px-4 py-2 text-xs font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl transition-colors border border-emerald-100">
                        Enable
                     </button>
                  )}
               </div>
            </div>
         ))}
      </div>
    </div>
  );
}
