"use client";

import React, { useState } from "react";
import { CheckSquare, Clock, Bell, UserX } from "lucide-react";

export default function AttendancePage() {
  const [toggles, setToggles] = useState({
     autoAlerts: true,
     biometricIntegration: false,
     allowTeacherOverride: true,
  });

  const handleToggle = (key: keyof typeof toggles) => {
     setToggles(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <div className="flex items-center gap-3 mb-8">
         <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <CheckSquare className="w-5 h-5" />
         </div>
         <div>
            <h3 className="text-xl font-black text-slate-800">Attendance Rules</h3>
            <p className="text-sm font-medium text-slate-500">Configure roll call frequency, late thresholds, and notifications.</p>
         </div>
      </div>

      <div className="space-y-10">
         
         {/* Core Settings */}
         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
               <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-slate-400" /> Roll Call Frequency
               </h4>
               <div className="space-y-3">
                  <label className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-xl cursor-pointer hover:border-emerald-300 transition-colors">
                     <input type="radio" name="frequency" className="text-emerald-600 focus:ring-emerald-500" defaultChecked />
                     <span className="text-sm font-bold text-slate-700">Once Daily (Morning)</span>
                  </label>
                  <label className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-xl cursor-pointer hover:border-emerald-300 transition-colors">
                     <input type="radio" name="frequency" className="text-emerald-600 focus:ring-emerald-500" />
                     <span className="text-sm font-bold text-slate-700">Twice Daily (Morning & Afternoon)</span>
                  </label>
                  <label className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-xl cursor-pointer hover:border-emerald-300 transition-colors">
                     <input type="radio" name="frequency" className="text-emerald-600 focus:ring-emerald-500" />
                     <span className="text-sm font-bold text-slate-700">Per Period (Subject level)</span>
                  </label>
               </div>
            </div>

            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
               <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-2">
                  <UserX className="w-4 h-4 text-slate-400" /> Late Threshold
               </h4>
               <p className="text-xs font-medium text-slate-500 mb-4">Minutes after the start of the day/period before a student is marked as "Late".</p>
               
               <div className="flex items-center gap-4 bg-white p-4 rounded-xl border border-slate-200">
                  <input type="number" defaultValue="15" className="w-20 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-emerald-500 transition-all text-center" />
                  <span className="text-sm font-bold text-slate-600">Minutes</span>
               </div>
               
               <div className="mt-4 flex items-start gap-2">
                  <input type="checkbox" id="convert_late" className="mt-1 rounded text-emerald-600 focus:ring-emerald-500" defaultChecked />
                  <label htmlFor="convert_late" className="text-xs font-medium text-slate-600">
                     Automatically convert to "Absent" if more than <input type="number" defaultValue="45" className="w-12 bg-white border border-slate-200 rounded px-1 py-0.5 mx-1 text-center font-bold inline-block" /> minutes late.
                  </label>
               </div>
            </div>
         </div>

         {/* Automation & Toggles */}
         <div>
            <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">Automation & Enforcement</h4>
            
            <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden divide-y divide-slate-100">
               
               <div className="p-5 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex gap-4">
                     <div className="mt-1"><Bell className="w-5 h-5 text-slate-400" /></div>
                     <div>
                        <div className="font-bold text-slate-800 text-sm">Automated Absence Alerts (SMS/Email)</div>
                        <div className="text-xs font-medium text-slate-500 max-w-lg">Automatically notify parents/guardians when a student is marked absent without prior excuse.</div>
                     </div>
                  </div>
                  <button 
                     onClick={() => handleToggle('autoAlerts')}
                     className={`w-12 h-6 rounded-full relative transition-colors ${toggles.autoAlerts ? 'bg-emerald-500' : 'bg-slate-300'}`}
                  >
                     <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${toggles.autoAlerts ? 'left-7' : 'left-1'}`}></div>
                  </button>
               </div>

               <div className="p-5 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex gap-4">
                     <div className="mt-1"><CheckSquare className="w-5 h-5 text-slate-400" /></div>
                     <div>
                        <div className="font-bold text-slate-800 text-sm">Allow Teacher Override</div>
                        <div className="text-xs font-medium text-slate-500 max-w-lg">Allow class teachers to modify attendance records up to 24 hours after submission.</div>
                     </div>
                  </div>
                  <button 
                     onClick={() => handleToggle('allowTeacherOverride')}
                     className={`w-12 h-6 rounded-full relative transition-colors ${toggles.allowTeacherOverride ? 'bg-emerald-500' : 'bg-slate-300'}`}
                  >
                     <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${toggles.allowTeacherOverride ? 'left-7' : 'left-1'}`}></div>
                  </button>
               </div>
               
               <div className="p-5 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex gap-4">
                     <div className="mt-1 flex items-center justify-center w-5 h-5 rounded-full border-2 border-slate-400 text-slate-400 text-[8px] font-black">BIO</div>
                     <div>
                        <div className="font-bold text-slate-800 text-sm">Biometric/RFID Integration</div>
                        <div className="text-xs font-medium text-slate-500 max-w-lg">Sync attendance data from physical hardware scanners at the school gates.</div>
                     </div>
                  </div>
                  <button 
                     onClick={() => handleToggle('biometricIntegration')}
                     className={`w-12 h-6 rounded-full relative transition-colors ${toggles.biometricIntegration ? 'bg-emerald-500' : 'bg-slate-300'}`}
                  >
                     <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${toggles.biometricIntegration ? 'left-7' : 'left-1'}`}></div>
                  </button>
               </div>

            </div>
         </div>

      </div>
    </div>
  );
}
