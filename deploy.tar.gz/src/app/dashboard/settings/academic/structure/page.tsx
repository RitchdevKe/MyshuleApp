"use client";

import React from "react";
import { BookOpen, Plus, Search, Filter, BookKey, Beaker, Globe, Calculator, Palette } from "lucide-react";

export default function StructurePage() {
  const subjects = [
     { name: "Mathematics", code: "MAT101", type: "Core", category: "STEM", icon: Calculator, color: "text-blue-500", bg: "bg-blue-50" },
     { name: "English Language", code: "ENG101", type: "Core", category: "Languages", icon: BookKey, color: "text-indigo-500", bg: "bg-indigo-50" },
     { name: "Integrated Science", code: "SCI101", type: "Core", category: "STEM", icon: Beaker, color: "text-emerald-500", bg: "bg-emerald-50" },
     { name: "Social Studies", code: "SOC101", type: "Core", category: "Humanities", icon: Globe, color: "text-amber-500", bg: "bg-amber-50" },
     { name: "Art & Design", code: "ART201", type: "Elective", category: "Creative Arts", icon: Palette, color: "text-rose-500", bg: "bg-rose-50" },
  ];

  return (
    <div className="p-6 md:p-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
         <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center">
               <BookOpen className="w-5 h-5" />
            </div>
            <div>
               <h3 className="text-xl font-black text-slate-800">Curriculum & Subjects</h3>
               <p className="text-sm font-medium text-slate-500">Manage subject offerings, categories, and core/elective rules.</p>
            </div>
         </div>
         <button className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-xl text-sm font-bold shadow-sm hover:bg-slate-700 transition-colors">
            <Plus className="w-4 h-4" /> Add Subject
         </button>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
         <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
            <input 
               type="text" 
               placeholder="Search subjects by name or code..." 
               className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm font-bold text-slate-800 focus:outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 transition-all shadow-sm"
            />
         </div>
         <button className="flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 text-slate-700 rounded-xl font-bold text-sm hover:bg-slate-50 transition-colors shadow-sm">
            <Filter className="w-4 h-4" /> Filter
         </button>
      </div>
      
      {/* Subject Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
         {subjects.map((subject, idx) => {
            const Icon = subject.icon;
            return (
               <div key={idx} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm hover:border-sky-300 hover:shadow-md transition-all group cursor-pointer">
                  <div className="flex justify-between items-start mb-4">
                     <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${subject.bg} ${subject.color}`}>
                        <Icon className="w-5 h-5" />
                     </div>
                     <span className={`px-2 py-1 rounded text-[10px] font-black uppercase tracking-wider ${
                        subject.type === 'Core' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600'
                     }`}>
                        {subject.type}
                     </span>
                  </div>
                  
                  <h4 className="text-lg font-black text-slate-800 mb-1 group-hover:text-sky-700 transition-colors">{subject.name}</h4>
                  
                  <div className="flex items-center gap-3 mt-3">
                     <div className="bg-slate-100 px-2 py-1 rounded text-xs font-bold text-slate-600">
                        {subject.code}
                     </div>
                     <div className="text-xs font-medium text-slate-500">
                        {subject.category}
                     </div>
                  </div>
               </div>
            );
         })}

         {/* Add New Card */}
         <div className="bg-slate-50/50 border-2 border-dashed border-slate-200 rounded-2xl p-5 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-slate-50 hover:border-sky-300 hover:text-sky-600 transition-all min-h-[160px] group">
            <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center mb-3 group-hover:border-sky-300 group-hover:text-sky-600 text-slate-400 transition-colors shadow-sm">
               <Plus className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-600 group-hover:text-sky-700">Create New Subject</h4>
         </div>
      </div>
    </div>
  );
}
