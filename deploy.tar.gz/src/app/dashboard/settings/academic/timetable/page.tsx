"use client";

import React from "react";
import { Clock, CalendarDays, Plus, Sun, Sunrise, Sunset } from "lucide-react";

export default function TimetablePage() {
  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <div className="flex items-center gap-3 mb-8">
         <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
            <Clock className="w-5 h-5" />
         </div>
         <div>
            <h3 className="text-xl font-black text-slate-800">Timetable Structure</h3>
            <p className="text-sm font-medium text-slate-500">Define daily schedules, period durations, and break times.</p>
         </div>
      </div>

      <div className="space-y-10">
         
         {/* Shifts / Day Types */}
         <div>
            <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-2">
               <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider">Active Daily Schedules</h4>
               <button className="text-xs font-bold text-orange-600 hover:text-orange-800 flex items-center gap-1 transition-colors">
                  <Plus className="w-3 h-3" /> Add Schedule Variant
               </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div className="bg-white border-2 border-orange-200 rounded-2xl shadow-sm p-5 relative overflow-hidden">
                  <div className="absolute top-0 right-0 bg-orange-100 text-orange-700 text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-bl-xl">Default (Mon-Thu)</div>
                  
                  <div className="flex items-center gap-3 mb-6 mt-2">
                     <Sun className="w-6 h-6 text-orange-500" />
                     <h5 className="font-black text-slate-800 text-lg">Standard Day</h5>
                  </div>
                  
                  <div className="space-y-4">
                     <div>
                        <div className="flex justify-between text-xs font-bold text-slate-500 mb-1">
                           <span>School Starts</span>
                           <span>School Ends</span>
                        </div>
                        <div className="flex justify-between font-black text-slate-800">
                           <span className="flex items-center gap-1"><Sunrise className="w-4 h-4 text-slate-400" /> 08:00 AM</span>
                           <span className="flex items-center gap-1"><Sunset className="w-4 h-4 text-slate-400" /> 03:30 PM</span>
                        </div>
                     </div>
                     <div className="h-px bg-slate-100"></div>
                     <div className="flex gap-4">
                        <div className="flex-1 bg-slate-50 p-3 rounded-xl border border-slate-100">
                           <div className="text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1">Period Length</div>
                           <div className="font-bold text-slate-800">40 Mins</div>
                        </div>
                        <div className="flex-1 bg-slate-50 p-3 rounded-xl border border-slate-100">
                           <div className="text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1">Total Periods</div>
                           <div className="font-bold text-slate-800">8 Periods</div>
                        </div>
                     </div>
                  </div>
               </div>

               <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5 relative overflow-hidden opacity-90 hover:opacity-100 transition-opacity">
                  <div className="absolute top-0 right-0 bg-slate-100 text-slate-600 text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-bl-xl">Fridays</div>
                  
                  <div className="flex items-center gap-3 mb-6 mt-2">
                     <CalendarDays className="w-6 h-6 text-sky-500" />
                     <h5 className="font-black text-slate-800 text-lg">Short Day</h5>
                  </div>
                  
                  <div className="space-y-4">
                     <div>
                        <div className="flex justify-between text-xs font-bold text-slate-500 mb-1">
                           <span>School Starts</span>
                           <span>School Ends</span>
                        </div>
                        <div className="flex justify-between font-black text-slate-800">
                           <span className="flex items-center gap-1"><Sunrise className="w-4 h-4 text-slate-400" /> 08:00 AM</span>
                           <span className="flex items-center gap-1"><Sunset className="w-4 h-4 text-slate-400" /> 01:00 PM</span>
                        </div>
                     </div>
                     <div className="h-px bg-slate-100"></div>
                     <div className="flex gap-4">
                        <div className="flex-1 bg-slate-50 p-3 rounded-xl border border-slate-100">
                           <div className="text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1">Period Length</div>
                           <div className="font-bold text-slate-800">35 Mins</div>
                        </div>
                        <div className="flex-1 bg-slate-50 p-3 rounded-xl border border-slate-100">
                           <div className="text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1">Total Periods</div>
                           <div className="font-bold text-slate-800">6 Periods</div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>

         {/* Constraints */}
         <div>
            <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">Global Constraints</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-2">Max consecutive periods for a Teacher</label>
                  <div className="flex items-center gap-3">
                     <input type="number" defaultValue="3" className="w-24 bg-white border border-slate-200 rounded-lg px-4 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-orange-500 transition-all shadow-sm" />
                     <span className="text-sm font-medium text-slate-600">Periods</span>
                  </div>
               </div>

               <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-2">Max daily periods per Teacher</label>
                  <div className="flex items-center gap-3">
                     <input type="number" defaultValue="6" className="w-24 bg-white border border-slate-200 rounded-lg px-4 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-orange-500 transition-all shadow-sm" />
                     <span className="text-sm font-medium text-slate-600">Periods</span>
                  </div>
               </div>
            </div>
         </div>

      </div>
    </div>
  );
}
