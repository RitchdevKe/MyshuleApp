"use client";

import React, { useState } from "react";
import { Users, Search, MoreHorizontal, Plus } from "lucide-react";

export default function ClubsPage() {
  const [searchTerm, setSearchTerm] = useState("");

  const clubs = [
    { name: "Debate Club", category: "Academic", members: 45, nextMeeting: "Today, 4:30 PM", sponsor: "Mrs. Kariuki", status: "Active" },
    { name: "Science Club", category: "STEM", members: 32, nextMeeting: "Friday, 2:00 PM", sponsor: "Mr. Kiprono", status: "Active" },
    { name: "Drama Club", category: "Arts", members: 58, nextMeeting: "Wednesday, 3:15 PM", sponsor: "Ms. Achieng", status: "Active" },
    { name: "Chess Club", category: "Strategy", members: 24, nextMeeting: "Thursday, 4:00 PM", sponsor: "Mr. Omondi", status: "Active" },
    { name: "Coding Club", category: "STEM", members: 40, nextMeeting: "Tuesday, 3:30 PM", sponsor: "Mrs. Mutua", status: "Inactive" },
  ];

  return (
    <div className="p-8 space-y-6 bg-white/30 backdrop-blur-md rounded-3xl min-h-[600px]">
      
      {/* Header & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white/60 p-4 rounded-2xl border border-white/60 shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-slate-800">Clubs Registry</h2>
            <p className="text-xs font-bold text-slate-500">Manage student clubs and academic societies</p>
          </div>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-sm">
          <Plus className="w-4 h-4" /> New Club
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4 bg-white/40 p-4 rounded-2xl border border-white/60 shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search clubs..." 
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <select className="bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20">
            <option>All Categories</option>
            <option>Academic</option>
            <option>STEM</option>
            <option>Arts</option>
            <option>Strategy</option>
          </select>
          <select className="bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20">
            <option>Status: Active</option>
            <option>Status: Inactive</option>
            <option>Status: All</option>
          </select>
        </div>
      </div>

      {/* Grid View */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {clubs.map((club, idx) => (
          <div key={idx} className="bg-white/80 border border-slate-200/60 rounded-3xl p-6 shadow-sm hover:shadow-md hover:border-indigo-200 transition-all group">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center font-black text-xl border border-indigo-100">
                  {club.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-black text-slate-800 text-lg group-hover:text-indigo-700 transition-colors">{club.name}</h3>
                  <p className="text-[10px] font-black uppercase tracking-wider text-slate-400">{club.category}</p>
                </div>
              </div>
              <button className="text-slate-400 hover:text-indigo-600">
                <MoreHorizontal className="w-5 h-5" />
              </button>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-5 p-4 bg-slate-50 rounded-2xl border border-slate-100">
              <div>
                <div className="text-[10px] font-black uppercase text-slate-400 tracking-wider mb-1">Members</div>
                <div className="text-xl font-black text-slate-700">{club.members}</div>
              </div>
              <div>
                <div className="text-[10px] font-black uppercase text-slate-400 tracking-wider mb-1">Status</div>
                <div className={`text-xs font-bold px-2 py-1 inline-block rounded-md ${club.status === 'Active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-600'}`}>
                  {club.status}
                </div>
              </div>
            </div>

            <div className="space-y-2 text-sm font-medium text-slate-600">
              <div className="flex justify-between">
                <span className="text-slate-400">Next Meeting:</span>
                <span className="text-slate-700">{club.nextMeeting}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Sponsor:</span>
                <span className="text-slate-700">{club.sponsor}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
