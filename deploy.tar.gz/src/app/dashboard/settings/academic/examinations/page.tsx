"use client";

import React, { useState } from "react";
import { FileText, EyeOff, FileSignature, Send, ShieldCheck, AlertCircle } from "lucide-react";

export default function ExaminationsPage() {
  const [toggles, setToggles] = useState({
     anonymousGrading: false,
     strictInvigilation: true,
     autoPublish: false,
     lockAfterPublish: true,
  });

  const handleToggle = (key: keyof typeof toggles) => {
     setToggles(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <div className="flex items-center gap-3 mb-8">
         <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
            <FileText className="w-5 h-5" />
         </div>
         <div>
            <h3 className="text-xl font-black text-slate-800">Examination Policies</h3>
            <p className="text-sm font-medium text-slate-500">Configure rules for invigilation, grading anonymity, and publishing.</p>
         </div>
      </div>

      <div className="space-y-10">
         
         {/* Policy Toggles */}
         <div>
            <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">Global Exam Rules</h4>
            
            <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden divide-y divide-slate-100">
               
               <div className="p-5 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex gap-4">
                     <div className="mt-1"><EyeOff className="w-5 h-5 text-slate-400" /></div>
                     <div>
                        <div className="font-bold text-slate-800 text-sm">Anonymous Grading</div>
                        <div className="text-xs font-medium text-slate-500 max-w-lg">Hide student names from teachers during the grading process to prevent bias. Student IDs will be used instead.</div>
                     </div>
                  </div>
                  <button 
                     onClick={() => handleToggle('anonymousGrading')}
                     className={`w-12 h-6 rounded-full relative transition-colors ${toggles.anonymousGrading ? 'bg-purple-500' : 'bg-slate-300'}`}
                  >
                     <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${toggles.anonymousGrading ? 'left-7' : 'left-1'}`}></div>
                  </button>
               </div>

               <div className="p-5 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex gap-4">
                     <div className="mt-1"><FileSignature className="w-5 h-5 text-slate-400" /></div>
                     <div>
                        <div className="font-bold text-slate-800 text-sm">Strict Invigilation (Dual Sign-off)</div>
                        <div className="text-xs font-medium text-slate-500 max-w-lg">Require both the primary invigilator and the department head to sign off on exam attendance sheets.</div>
                     </div>
                  </div>
                  <button 
                     onClick={() => handleToggle('strictInvigilation')}
                     className={`w-12 h-6 rounded-full relative transition-colors ${toggles.strictInvigilation ? 'bg-purple-500' : 'bg-slate-300'}`}
                  >
                     <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${toggles.strictInvigilation ? 'left-7' : 'left-1'}`}></div>
                  </button>
               </div>

               <div className="p-5 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex gap-4">
                     <div className="mt-1"><Send className="w-5 h-5 text-slate-400" /></div>
                     <div>
                        <div className="font-bold text-slate-800 text-sm">Automatic Result Publishing</div>
                        <div className="text-xs font-medium text-slate-500 max-w-lg">Instantly publish results to the Student and Parent portals as soon as teachers submit the final grades.</div>
                     </div>
                  </div>
                  <button 
                     onClick={() => handleToggle('autoPublish')}
                     className={`w-12 h-6 rounded-full relative transition-colors ${toggles.autoPublish ? 'bg-purple-500' : 'bg-slate-300'}`}
                  >
                     <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${toggles.autoPublish ? 'left-7' : 'left-1'}`}></div>
                  </button>
               </div>

               <div className="p-5 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex gap-4">
                     <div className="mt-1"><ShieldCheck className="w-5 h-5 text-slate-400" /></div>
                     <div>
                        <div className="font-bold text-slate-800 text-sm">Lock Grades After Publishing</div>
                        <div className="text-xs font-medium text-slate-500 max-w-lg">Prevent any modifications to grades by teachers once the results have been published.</div>
                     </div>
                  </div>
                  <button 
                     onClick={() => handleToggle('lockAfterPublish')}
                     className={`w-12 h-6 rounded-full relative transition-colors ${toggles.lockAfterPublish ? 'bg-purple-500' : 'bg-slate-300'}`}
                  >
                     <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${toggles.lockAfterPublish ? 'left-7' : 'left-1'}`}></div>
                  </button>
               </div>

            </div>
         </div>

         {/* Grade Thresholds */}
         <div>
            <div className="flex items-center gap-2 mb-4 border-b border-slate-100 pb-2">
               <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider">Pass/Fail Thresholds</h4>
               <AlertCircle className="w-4 h-4 text-amber-500" />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-2">Minimum Pass Mark (Percentage)</label>
                  <div className="flex items-center gap-3">
                     <input type="number" defaultValue="40" className="w-24 bg-white border border-slate-200 rounded-lg px-4 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-purple-500 transition-all shadow-sm" />
                     <span className="text-sm font-medium text-slate-600">%</span>
                  </div>
               </div>

               <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-2">Distinction Mark (Percentage)</label>
                  <div className="flex items-center gap-3">
                     <input type="number" defaultValue="80" className="w-24 bg-white border border-slate-200 rounded-lg px-4 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-purple-500 transition-all shadow-sm" />
                     <span className="text-sm font-medium text-slate-600">%</span>
                  </div>
               </div>
            </div>
         </div>

      </div>
    </div>
  );
}
