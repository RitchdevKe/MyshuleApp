"use client";

import React, { useState } from "react";
import {
  Search, Plus, Filter, UserCheck, CheckCircle, Activity,
  Clock, MoreHorizontal, X, GraduationCap, Users,
  BookOpen, ChevronRight, Hash, ChevronDown
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Cell
} from "recharts";

// ── Data ──────────────────────────────────────────────────────────────────────
interface ClassRoster {
  className: string;
  students: { id: string; name: string; initials: string }[];
}

interface Allocation {
  id: number;
  teacher: string;
  initials: string;
  subject: string;
  classes: string[];
  lessons: number;
  status: "Optimal" | "Overloaded" | "Underutilized";
}

// Simulated class rosters — keyed by class name
const CLASS_ROSTERS: Record<string, { id: string; name: string; initials: string }[]> = {
  "Grade 4N": [
    { id: "STD-2601", name: "John Kamau",   initials: "JK" },
    { id: "STD-2604", name: "Sarah Mutiso", initials: "SM" },
    { id: "STD-2606", name: "Faith Njeri",  initials: "FN" },
    { id: "STD-2609", name: "Liam Omondi",  initials: "LO" },
  ],
  "Grade 4S": [
    { id: "STD-2602", name: "Mary Wanjiku",  initials: "MW" },
    { id: "STD-2605", name: "Kevin Kiprop",  initials: "KK" },
    { id: "STD-2611", name: "Moses Wekesa",  initials: "MoW" },
  ],
  "Grade 5E": [
    { id: "STD-2603", name: "David Ochieng",  initials: "DO" },
    { id: "STD-2608", name: "Amina Hassan",   initials: "AH" },
    { id: "STD-2612", name: "Diana Moraa",    initials: "DM" },
  ],
  "Grade 5W": [
    { id: "STD-2607", name: "Brian Otieno",   initials: "BO" },
    { id: "STD-2610", name: "Esther Achieng", initials: "EA" },
  ],
  "Grade 6N": [
    { id: "STD-2601", name: "John Kamau",    initials: "JK" },
    { id: "STD-2604", name: "Sarah Mutiso",  initials: "SM" },
  ],
  "Grade 6S": [
    { id: "STD-2605", name: "Kevin Kiprop",  initials: "KK" },
    { id: "STD-2609", name: "Liam Omondi",   initials: "LO" },
  ],
  "Grade 6W": [
    { id: "STD-2611", name: "Moses Wekesa",  initials: "MoW" },
    { id: "STD-2612", name: "Diana Moraa",   initials: "DM" },
  ],
};

const mockAllocations: Allocation[] = [
  { id: 1, teacher: "Sarah Mutiso",  initials: "SM", subject: "Mathematics",   classes: ["Grade 4N", "Grade 4S"],              lessons: 10, status: "Optimal" },
  { id: 2, teacher: "David Ochieng", initials: "DO", subject: "Science",        classes: ["Grade 5E", "Grade 5W", "Grade 6N"], lessons: 15, status: "Optimal" },
  { id: 3, teacher: "Mary Wanjiku",  initials: "MW", subject: "English",         classes: ["Grade 4N", "Grade 5E", "Grade 6S", "Grade 6W"], lessons: 22, status: "Overloaded" },
  { id: 4, teacher: "John Kamau",    initials: "JK", subject: "Social Studies", classes: ["Grade 4S", "Grade 5W"],              lessons: 8,  status: "Underutilized" },
];

const workloadData = [
  { name: "Sarah", load: 10, color: "#10b981" },
  { name: "David", load: 15, color: "#10b981" },
  { name: "Mary",  load: 22, color: "#fb7185" },
  { name: "John",  load: 8,  color: "#f59e0b" },
];

const avatarGrads = [
  "from-primary-700 to-primary-900",
  "from-indigo-500 to-violet-600",
  "from-emerald-500 to-teal-600",
  "from-sky-500 to-blue-600",
  "from-amber-500 to-orange-500",
];

// ── Class Roster Panel ────────────────────────────────────────────────────────
function ClassRosterPanel({
  allocation,
  className,
  onClose,
}: {
  allocation: Allocation;
  className: string;
  onClose: () => void;
}) {
  const roster = CLASS_ROSTERS[className] ?? [];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end">
      <div className="absolute inset-0 bg-primary-950/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-80 h-full bg-white shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-700 to-violet-700 px-5 py-4 flex-shrink-0">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                <GraduationCap className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-[10px] font-black text-white/50 uppercase tracking-wider">Class Roster</p>
                <h3 className="font-black text-white">{className}</h3>
              </div>
            </div>
            <button onClick={onClose} className="w-7 h-7 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="mt-3 flex flex-wrap gap-2 text-[11px]">
            <span className="bg-white/15 text-white/80 border border-white/20 px-2.5 py-1 rounded-lg font-black">
              <BookOpen className="w-3 h-3 inline mr-1" />{allocation.subject}
            </span>
            <span className="bg-white/15 text-white/80 border border-white/20 px-2.5 py-1 rounded-lg font-black">
              <Users className="w-3 h-3 inline mr-1" />{allocation.teacher}
            </span>
          </div>
        </div>

        {/* Student count */}
        <div className="px-5 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <span className="text-xs font-black text-slate-500 uppercase tracking-wider">
            {roster.length} student{roster.length !== 1 ? "s" : ""} enrolled
          </span>
          <button className="text-[11px] font-black text-indigo-600 hover:text-indigo-800 transition-colors flex items-center gap-1">
            Full Roster <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        {/* Student list */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
          {roster.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-slate-300">
              <Users className="w-10 h-10 mb-2" />
              <p className="text-sm font-bold text-slate-400">No students in roster</p>
            </div>
          ) : (
            roster.map((student, i) => (
              <div key={student.id} className="flex items-center gap-3 px-5 py-3 hover:bg-indigo-50/30 transition-colors">
                <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${avatarGrads[i % avatarGrads.length]} flex items-center justify-center text-white text-[10px] font-black flex-shrink-0`}>
                  {student.initials}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-slate-800 text-sm truncate">{student.name}</p>
                  <p className="text-[10px] font-black text-indigo-400">{student.id}</p>
                </div>
                <Hash className="w-3 h-3 text-slate-300 flex-shrink-0" />
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-slate-100 bg-slate-50/80 flex-shrink-0">
          <button className="w-full flex items-center justify-center gap-2 py-2.5 text-xs font-black text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors shadow-md">
            <Plus className="w-3.5 h-3.5" /> Add Student to {className}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function AllocationPage() {
  const [rosterPanel, setRosterPanel] = useState<{
    allocation: Allocation;
    className: string;
  } | null>(null);

  const getStatusStyle = (status: string) => {
    switch (status) {
      case "Optimal":      return "bg-emerald-100/80 text-emerald-700 border-emerald-200";
      case "Overloaded":   return "bg-rose-100/80 text-rose-700 border-rose-200";
      case "Underutilized":return "bg-amber-100/80 text-amber-700 border-amber-200";
      default:             return "bg-slate-100/80 text-slate-700 border-slate-200";
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
        <div className="bg-gradient-to-br from-primary-900 to-primary-800 p-6 rounded-3xl border border-primary-800 shadow-lg text-white relative overflow-hidden group hover:-translate-y-1 transition-all duration-300">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700" />
          <div className="flex justify-between items-start mb-4 relative z-10">
            <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-sm border border-white/10">
              <UserCheck className="w-6 h-6" />
            </div>
          </div>
          <p className="text-primary-100 font-bold mb-1 relative z-10">Total Teaching Staff</p>
          <h3 className="text-3xl font-black tracking-tight relative z-10">42</h3>
        </div>

        <div className="bg-white/60 backdrop-blur-xl p-6 rounded-3xl border border-white/60 shadow-lg relative overflow-hidden group hover:shadow-xl transition-all duration-300">
          <div className="flex justify-between items-start mb-4 relative z-10">
            <div className="p-3 bg-emerald-100 text-emerald-600 rounded-2xl"><CheckCircle className="w-6 h-6" /></div>
          </div>
          <p className="text-sm font-bold text-slate-500 mb-1 relative z-10">Optimal Workload</p>
          <h3 className="text-3xl font-black text-slate-800 tracking-tight relative z-10">35 <span className="text-sm font-bold text-slate-400">teachers</span></h3>
        </div>

        <div className="bg-white/60 backdrop-blur-xl p-6 rounded-3xl border border-white/60 shadow-lg relative overflow-hidden group hover:shadow-xl transition-all duration-300">
          <div className="absolute top-0 right-0 w-32 h-32 bg-rose-500/5 rounded-full blur-3xl group-hover:bg-rose-500/10 transition-colors duration-500" />
          <div className="flex justify-between items-start mb-4 relative z-10">
            <div className="p-3 bg-rose-100 text-rose-600 rounded-2xl"><Activity className="w-6 h-6" /></div>
          </div>
          <p className="text-sm font-bold text-slate-500 mb-1 relative z-10">Overloaded</p>
          <h3 className="text-3xl font-black text-slate-800 tracking-tight relative z-10">4 <span className="text-sm font-bold text-slate-400">teachers</span></h3>
        </div>

        <div className="bg-white/60 backdrop-blur-xl p-6 rounded-3xl border border-white/60 shadow-lg relative overflow-hidden group hover:shadow-xl transition-all duration-300">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl group-hover:bg-blue-500/10 transition-colors duration-500" />
          <div className="flex justify-between items-start mb-4 relative z-10">
            <div className="p-3 bg-blue-100 text-blue-600 rounded-2xl"><Clock className="w-6 h-6" /></div>
          </div>
          <p className="text-sm font-bold text-slate-500 mb-1 relative z-10">Unallocated Lessons</p>
          <h3 className="text-3xl font-black text-slate-800 tracking-tight relative z-10">12 <span className="text-sm font-bold text-slate-400">lessons</span></h3>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Main Table */}
        <div className="xl:col-span-2 bg-white/60 backdrop-blur-xl border border-white/60 rounded-3xl shadow-lg overflow-hidden flex flex-col">
          <div className="p-5 border-b border-slate-200/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="relative w-full sm:max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search teachers..."
                className="w-full pl-10 pr-4 py-2 text-sm font-bold bg-white/80 border border-slate-200/60 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-900 focus:border-primary-900 transition-all"
              />
            </div>
            <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-primary-900 rounded-xl hover:bg-primary-800 transition-colors shadow-sm">
              <Plus className="w-4 h-4" /> New Allocation
            </button>
          </div>

          <div className="flex-1 overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50/50 text-[10px] uppercase font-black text-slate-500 border-b border-slate-200/60 tracking-wider">
                <tr>
                  <th className="px-6 py-4">Teacher</th>
                  <th className="px-6 py-4">Subject</th>
                  <th className="px-6 py-4">Classes <span className="text-indigo-400 normal-case font-black">(click to view roster)</span></th>
                  <th className="px-6 py-4">Lessons/Wk</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/60">
                {mockAllocations.map((row, ri) => (
                  <tr key={row.id} className="hover:bg-white/80 transition-colors group">
                    {/* Teacher */}
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${avatarGrads[ri % avatarGrads.length]} flex items-center justify-center text-white text-[10px] font-black flex-shrink-0`}>
                          {row.initials}
                        </div>
                        <span className="font-bold text-slate-800">{row.teacher}</span>
                      </div>
                    </td>

                    {/* Subject */}
                    <td className="px-6 py-4 font-bold text-slate-600">{row.subject}</td>

                    {/* Classes — clickable class chips */}
                    <td className="px-6 py-4">
                      <div className="flex flex-wrap gap-1.5">
                        {row.classes.map(c => (
                          <button
                            key={c}
                            id={`class-chip-${row.id}-${c.replace(/\s/g, "-")}`}
                            onClick={() => setRosterPanel({ allocation: row, className: c })}
                            className="group/chip flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-indigo-50 text-slate-600 hover:text-indigo-700 rounded-lg border border-slate-200 hover:border-indigo-300 shadow-sm text-[10px] font-bold uppercase tracking-wider transition-all"
                          >
                            {c}
                            <ChevronRight className="w-2.5 h-2.5 opacity-0 group-hover/chip:opacity-100 transition-opacity" />
                          </button>
                        ))}
                      </div>
                    </td>

                    {/* Lessons */}
                    <td className="px-6 py-4 font-black text-slate-700">{row.lessons}</td>

                    {/* Status */}
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold border backdrop-blur-sm ${getStatusStyle(row.status)}`}>
                        {row.status}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="px-6 py-4 text-right">
                      <button className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100">
                        <MoreHorizontal className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Workload Chart */}
        <div className="bg-white/60 backdrop-blur-xl border border-white/60 rounded-3xl shadow-lg p-6 flex flex-col min-h-[400px]">
          <div className="mb-6 flex justify-between items-start">
            <div>
              <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-widest">Workload Dist.</h3>
              <p className="text-xs font-bold text-slate-400 mt-1">Lessons per week</p>
            </div>
            <button className="text-primary-900 hover:text-primary-800 text-xs font-bold transition-colors bg-white px-2 py-1 rounded-md shadow-sm border border-slate-100">
              View All
            </button>
          </div>
          <div className="flex-1 w-full min-h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={workloadData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                <XAxis type="number" tick={{ fill: "#64748b", fontSize: 11, fontWeight: 700 }} axisLine={false} tickLine={false} />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fill: "#64748b", fontSize: 11, fontWeight: 700 }} width={60} />
                <Tooltip
                  cursor={{ fill: "#f8fafc" }}
                  contentStyle={{ borderRadius: "16px", border: "none", boxShadow: "0 10px 15px -3px rgb(0 0 0 / 0.1)" }}
                  itemStyle={{ fontWeight: 800 }}
                />
                <Bar dataKey="load" radius={[0, 4, 4, 0]} barSize={20}>
                  {workloadData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Class Roster Slide Panel */}
      {rosterPanel && (
        <ClassRosterPanel
          allocation={rosterPanel.allocation}
          className={rosterPanel.className}
          onClose={() => setRosterPanel(null)}
        />
      )}
    </div>
  );
}