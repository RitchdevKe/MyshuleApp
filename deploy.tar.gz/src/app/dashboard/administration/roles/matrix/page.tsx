"use client";

import React from "react";
import { Search, Check, X, Filter } from "lucide-react";

export default function MatrixPage() {
  const modules = [
    { name: "Student Records", principal: true, teacher: true, bursar: false, parent: false },
    { name: "Financial Data", principal: true, teacher: false, bursar: true, parent: false },
    { name: "System Settings", principal: true, teacher: false, bursar: false, parent: false },
    { name: "Class Timetables", principal: true, teacher: true, bursar: false, parent: true },
    { name: "Staff Payroll", principal: true, teacher: false, bursar: true, parent: false },
    { name: "Exam Results", principal: true, teacher: true, bursar: false, parent: true },
  ];

  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden min-h-[500px]">
      <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50/50">
         <div className="flex items-center gap-2 w-full md:w-auto relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input type="text" placeholder="Search resources..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
         </div>
         <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
            <Filter className="w-4 h-4" />
            Filter by Role
         </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50 border-b border-slate-200/60">
              <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Module / Resource</th>
              <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-center">Principal</th>
              <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-center">Teacher</th>
              <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-center">Bursar</th>
              <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-center">Parent</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {modules.map((mod, idx) => (
              <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                <td className="py-4 px-6">
                   <div className="font-bold text-sm text-slate-800">{mod.name}</div>
                </td>
                <td className="py-4 px-6 text-center">
                   <div className="flex justify-center">
                      {mod.principal ? <Check className="w-5 h-5 text-emerald-500" /> : <X className="w-5 h-5 text-slate-300" />}
                   </div>
                </td>
                <td className="py-4 px-6 text-center">
                   <div className="flex justify-center">
                      {mod.teacher ? <Check className="w-5 h-5 text-emerald-500" /> : <X className="w-5 h-5 text-slate-300" />}
                   </div>
                </td>
                <td className="py-4 px-6 text-center">
                   <div className="flex justify-center">
                      {mod.bursar ? <Check className="w-5 h-5 text-emerald-500" /> : <X className="w-5 h-5 text-slate-300" />}
                   </div>
                </td>
                <td className="py-4 px-6 text-center">
                   <div className="flex justify-center">
                      {mod.parent ? <Check className="w-5 h-5 text-emerald-500" /> : <X className="w-5 h-5 text-slate-300" />}
                   </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
