"use client";

import React from "react";
import { Share2, Mail, Smartphone, BellRing, Settings2, CheckCircle2, AlertCircle } from "lucide-react";

export default function ChannelsPage() {
  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <div className="flex items-center gap-3 mb-8">
         <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center">
            <Share2 className="w-5 h-5" />
         </div>
         <div>
            <h3 className="text-xl font-black text-slate-800">Communication Channels</h3>
            <p className="text-sm font-medium text-slate-500">Configure your email servers, SMS gateways, and push notification providers.</p>
         </div>
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        
        {/* Email Gateway */}
        <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm hover:border-slate-300 transition-colors">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
               <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-sky-50 flex items-center justify-center text-sky-600">
                     <Mail className="w-6 h-6" />
                  </div>
                  <div>
                     <h4 className="font-black text-slate-800 text-lg">Email Gateway (SMTP)</h4>
                     <p className="text-sm text-slate-500 font-medium">Send bulk emails, newsletters, and invoices.</p>
                  </div>
               </div>
               <div className="flex items-center gap-2">
                  <span className="bg-emerald-50 text-emerald-700 text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-lg border border-emerald-100 flex items-center gap-1">
                     <CheckCircle2 className="w-3 h-3" /> Connected
                  </span>
                  <button className="p-2 text-slate-400 hover:text-sky-600 hover:bg-sky-50 rounded-xl transition-colors">
                     <Settings2 className="w-5 h-5" />
                  </button>
               </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50/50 p-4 rounded-xl border border-slate-100">
               <div>
                  <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">Provider</div>
                  <div className="text-sm font-bold text-slate-800">Amazon SES</div>
               </div>
               <div>
                  <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">From Address</div>
                  <div className="text-sm font-bold text-slate-800">notifications@kepler.edu</div>
               </div>
               <div>
                  <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">Monthly Limit</div>
                  <div className="text-sm font-bold text-slate-800">50,000 / 100,000</div>
                  <div className="w-full bg-slate-200 h-1.5 rounded-full mt-1.5">
                     <div className="bg-sky-500 h-1.5 rounded-full" style={{ width: '50%' }}></div>
                  </div>
               </div>
            </div>
        </div>

        {/* SMS Gateway */}
        <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm hover:border-slate-300 transition-colors">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
               <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-600">
                     <Smartphone className="w-6 h-6" />
                  </div>
                  <div>
                     <h4 className="font-black text-slate-800 text-lg">SMS Provider</h4>
                     <p className="text-sm text-slate-500 font-medium">Send instant alerts, OTPs, and short notifications.</p>
                  </div>
               </div>
               <div className="flex items-center gap-2">
                  <span className="bg-emerald-50 text-emerald-700 text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-lg border border-emerald-100 flex items-center gap-1">
                     <CheckCircle2 className="w-3 h-3" /> Connected
                  </span>
                  <button className="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition-colors">
                     <Settings2 className="w-5 h-5" />
                  </button>
               </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50/50 p-4 rounded-xl border border-slate-100">
               <div>
                  <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">Provider</div>
                  <div className="text-sm font-bold text-slate-800">Africa's Talking</div>
               </div>
               <div>
                  <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">Sender ID</div>
                  <div className="text-sm font-bold text-slate-800">KEPLER_SCH</div>
               </div>
               <div>
                  <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">Balance</div>
                  <div className="text-sm font-bold text-emerald-600">KSh 4,520.00</div>
               </div>
            </div>
        </div>

        {/* Push Notifications */}
        <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm hover:border-slate-300 transition-colors opacity-70">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
               <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-amber-50 flex items-center justify-center text-amber-600">
                     <BellRing className="w-6 h-6" />
                  </div>
                  <div>
                     <h4 className="font-black text-slate-800 text-lg">Push Notifications</h4>
                     <p className="text-sm text-slate-500 font-medium">Send alerts directly to the parent mobile app.</p>
                  </div>
               </div>
               <div className="flex items-center gap-2">
                  <span className="bg-amber-50 text-amber-700 text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-lg border border-amber-100 flex items-center gap-1">
                     <AlertCircle className="w-3 h-3" /> Setup Required
                  </span>
                  <button className="p-2 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-xl transition-colors">
                     <Settings2 className="w-5 h-5" />
                  </button>
               </div>
            </div>
            
            <div className="bg-amber-50/50 border border-amber-100 p-4 rounded-xl flex items-start gap-3">
               <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
               <div>
                  <h5 className="text-sm font-bold text-amber-800">Firebase Cloud Messaging (FCM) is not configured.</h5>
                  <p className="text-xs text-amber-700/80 font-medium mt-1">Provide your FCM server key to enable push notifications for the mobile application.</p>
               </div>
            </div>
        </div>

      </div>
    </div>
  );
}
