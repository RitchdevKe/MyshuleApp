import React from "react";
import { Target, Search, Filter, Activity, Plus } from "lucide-react";

export default function EngagementParticipationPage() {
  const activities = [
    { id: 1, name: "Debate Club", category: "Academic", members: 45, avgAttendance: "92%" },
    { id: 2, name: "Football U16", category: "Sports", members: 22, avgAttendance: "88%" },
    { id: 3, name: "Drama Club", category: "Arts", members: 30, avgAttendance: "75%" },
    { id: 4, name: "Chess Team", category: "Academic", members: 15, avgAttendance: "95%" },
  ];

  return (
    <div className="p-6">
      
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search activities..." 
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-secondary-500/20 focus:border-secondary-500 transition-all shadow-sm"
          />
        </div>
        
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors shadow-sm">
            <Filter className="w-4 h-4" /> Filter
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-white bg-primary-900 rounded-xl hover:bg-primary-800 transition-colors shadow-sm">
            <Plus className="w-4 h-4" /> Log Session
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {activities.map((activity) => (
          <div key={activity.id} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-xl bg-primary-50 flex items-center justify-center text-primary-900 mb-4 shadow-inner">
              <Activity className="w-5 h-5" />
            </div>
            
            <h3 className="font-bold text-slate-800 mb-1">{activity.name}</h3>
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 bg-slate-100 px-2 py-0.5 rounded-lg mb-4 inline-block">
              {activity.category}
            </span>

            <div className="pt-4 border-t border-slate-100 mt-2 space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span className="font-medium text-slate-500">Members</span>
                <span className="font-bold text-slate-800">{activity.members}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="font-medium text-slate-500">Avg. Attendance</span>
                <span className="font-bold text-emerald-600">{activity.avgAttendance}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
