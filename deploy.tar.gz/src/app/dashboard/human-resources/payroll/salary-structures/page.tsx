"use client";

import React from "react";
import { LayoutList, Plus, Edit, Users } from "lucide-react";

export default function SalaryStructuresPage() {
  const structures = [
    { id: "SS-001", name: "Senior Management", baseMin: "$6,000", baseMax: "$10,000", allowances: "Housing, Transport, Medical", employees: 4 },
    { id: "SS-002", name: "Head of Department", baseMin: "$4,500", baseMax: "$6,500", allowances: "Housing, Medical", employees: 8 },
    { id: "SS-003", name: "Senior Teacher", baseMin: "$3,000", baseMax: "$4,800", allowances: "Medical, Commuter", employees: 32 },
    { id: "SS-004", name: "Junior Teacher", baseMin: "$1,800", baseMax: "$3,200", allowances: "Medical", employees: 45 },
    { id: "SS-005", name: "Support Staff (Tier 1)", baseMin: "$1,200", baseMax: "$2,000", allowances: "Meals, Medical", employees: 25 },
    { id: "SS-006", name: "Support Staff (Tier 2)", baseMin: "$800", baseMax: "$1,500", allowances: "Meals", employees: 28 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div>
           <h2 className="text-lg font-black text-slate-800">Salary Structures & Bands</h2>
           <p className="text-sm font-medium text-slate-500">Manage pay grades, base salaries, and standard allowances.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
           <Plus className="w-4 h-4" />
           New Structure
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
         {structures.map((structure) => (
            <div key={structure.id} className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-6 hover:shadow-xl transition-all duration-300 group flex flex-col">
               <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                     <div className="w-10 h-10 rounded-xl bg-primary-50 text-primary-600 flex items-center justify-center shrink-0">
                        <LayoutList className="w-5 h-5" />
                     </div>
                     <div>
                        <h3 className="font-black text-slate-800">{structure.name}</h3>
                        <p className="text-xs font-bold text-slate-400">ID: {structure.id}</p>
                     </div>
                  </div>
                  <button className="text-slate-400 hover:text-primary-900 transition-colors p-1 rounded-lg hover:bg-slate-50 opacity-0 group-hover:opacity-100">
                     <Edit className="w-4 h-4" />
                  </button>
               </div>
               
               <div className="bg-slate-50 rounded-2xl p-4 mb-4 flex-grow">
                  <div className="mb-3">
                     <p className="text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Base Salary Range</p>
                     <p className="font-black text-slate-700">{structure.baseMin} - {structure.baseMax}</p>
                  </div>
                  <div>
                     <p className="text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Default Allowances</p>
                     <p className="text-sm font-medium text-slate-600">{structure.allowances}</p>
                  </div>
               </div>

               <div className="flex justify-between items-center pt-2 border-t border-slate-100">
                  <div className="flex items-center gap-1.5 text-sm font-bold text-slate-500">
                     <Users className="w-4 h-4 text-slate-400" />
                     {structure.employees} Employees
                  </div>
                  <button className="text-sm font-bold text-primary-600 hover:text-primary-800">
                     View Details
                  </button>
               </div>
            </div>
         ))}
      </div>
    </div>
  );
}
