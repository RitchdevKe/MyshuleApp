"use client";

import React, { useState } from "react";
import { Plus, Users, Library, Activity, BookOpen, AlertCircle, Building2, TrendingUp, Settings2 } from "lucide-react";

export default function ClassesPage() {
  const [activeBranch, setActiveBranch] = useState("all");

  const branches = [
    {
      id: "main",
      name: "Main Campus",
      capacity: "650",
      total: "800",
      utilization: 81,
      classes: [
        { name: "Pre-Primary", streams: ["PP1", "PP2"], count: 45, cap: 50 },
        { name: "Grade 1", streams: ["North", "South"], count: 80, cap: 90 },
        { name: "Grade 2", streams: ["North", "South", "East"], count: 110, cap: 120 },
        { name: "Grade 3", streams: ["North", "South"], count: 75, cap: 80 },
        { name: "Grade 4", streams: ["North", "South"], count: 85, cap: 80, overcap: true },
        { name: "Grade 5", streams: ["North", "South", "East"], count: 115, cap: 120 },
      ]
    },
    {
      id: "west",
      name: "West Wing Campus",
      capacity: "280",
      total: "400",
      utilization: 70,
      classes: [
        { name: "Grade 1", streams: ["West"], count: 40, cap: 45 },
        { name: "Grade 4", streams: ["West"], count: 10, cap: 40, undercap: true },
        { name: "Grade 5", streams: ["West"], count: 15, cap: 40, undercap: true },
        { name: "Grade 6", streams: ["West"], count: 35, cap: 40 },
      ]
    }
  ];

  const filteredBranches = activeBranch === "all" ? branches : branches.filter(b => b.id === activeBranch);

  return (
    <div className="space-y-6">

      {/* Toolbar */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-2xl px-5 py-4 flex flex-wrap items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-2 flex-wrap">
          <button 
            onClick={() => setActiveBranch("all")}
            className={`px-4 py-2 rounded-xl text-xs font-black transition-all ${activeBranch === "all" ? "bg-primary-900 text-white shadow-md" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}
          >
            All Campuses
          </button>
          {branches.map(b => (
            <button 
              key={b.id}
              onClick={() => setActiveBranch(b.id)}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all ${activeBranch === b.id ? "bg-primary-900 text-white shadow-md" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}
            >
              {b.name}
            </button>
          ))}
        </div>
        
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm">
            <Settings2 className="w-4 h-4" /> Manage Streams
          </button>
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all">
            <Plus className="w-4 h-4" /> Add Class
          </button>
        </div>
      </div>
      
      {filteredBranches.map((branch) => (
        <div key={branch.id} className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden flex flex-col relative">
          
          {/* Branch Header */}
          <div className="p-6 border-b border-slate-100 bg-white/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-md flex-shrink-0">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-black text-slate-800">{branch.name}</h2>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-lg border border-slate-200">Capacity: {branch.capacity} / {branch.total}</span>
                  <span className={`flex items-center gap-1 text-xs font-black px-2 py-0.5 rounded-lg border ${branch.utilization > 80 ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}`}>
                    <Activity className="w-3 h-3" /> {branch.utilization}% Utilisation
                  </span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-4 text-slate-500 text-sm font-bold bg-slate-50 px-4 py-2 rounded-xl border border-slate-200">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4" /> {branch.classes.length} Classes
              </div>
              <div className="w-1 h-1 rounded-full bg-slate-300"></div>
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4" /> {branch.classes.reduce((a,c) => a + c.streams.length, 0)} Streams
              </div>
            </div>
          </div>

          {/* Classes Grid */}
          <div className="p-6 bg-slate-50/30">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {branch.classes.map((cls, idx) => {
                const percent = Math.round((cls.count / cls.cap) * 100);
                const isOvercap = cls.overcap || percent > 100;
                const isUndercap = cls.undercap || percent < 50;

                return (
                  <div key={idx} className={`p-5 rounded-2xl border ${isOvercap ? 'border-rose-300 bg-rose-50/50' : isUndercap ? 'border-amber-300 bg-amber-50/50' : 'border-slate-200 bg-white/80'} shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all relative group cursor-pointer`}>
                    
                    {isOvercap && (
                      <div className="absolute -top-2.5 -right-2.5 bg-rose-500 text-white p-1.5 rounded-full shadow-lg border-2 border-white">
                        <AlertCircle className="w-3.5 h-3.5" />
                      </div>
                    )}
                    {isUndercap && (
                      <div className="absolute -top-2.5 -right-2.5 bg-amber-500 text-white p-1.5 rounded-full shadow-lg border-2 border-white">
                        <TrendingUp className="w-3.5 h-3.5 transform rotate-180" />
                      </div>
                    )}

                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-black text-slate-800 text-lg flex items-center gap-2">
                        <div className={`p-2 rounded-lg ${isOvercap ? 'bg-rose-100 text-rose-600' : isUndercap ? 'bg-amber-100 text-amber-600' : 'bg-indigo-50 text-indigo-600'}`}>
                          <Library className="w-4 h-4" />
                        </div>
                        {cls.name}
                      </h3>
                    </div>
                    
                    <div className="flex flex-wrap gap-1.5 mb-6">
                      {cls.streams.map(stream => (
                        <span key={stream} className="px-2 py-1 bg-white text-slate-600 rounded-lg border border-slate-200 text-[10px] font-black uppercase tracking-wider shadow-sm">
                          {stream}
                        </span>
                      ))}
                    </div>

                    <div className="mt-auto">
                      <div className="flex justify-between text-xs font-bold text-slate-600 mb-2">
                        <span>Enrolment</span>
                        <span className={isOvercap ? 'text-rose-600 font-black' : isUndercap ? 'text-amber-600 font-black' : 'text-emerald-600 font-black'}>{cls.count} / {cls.cap}</span>
                      </div>
                      <div className="h-2 bg-slate-200/50 rounded-full overflow-hidden shadow-inner">
                        <div 
                          className={`h-full rounded-full transition-all ${isOvercap ? 'bg-rose-500' : isUndercap ? 'bg-amber-500' : 'bg-emerald-500'}`}
                          style={{ width: `${Math.min(percent, 100)}%` }}
                        ></div>
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ))}
      
    </div>
  );
}