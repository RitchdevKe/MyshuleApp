"use client";

import React from "react";
import { Network, Plus, FolderTree, BookOpen, GraduationCap, ChevronRight } from "lucide-react";

export default function StructurePage() {
  const structure = [
    {
       level: "Early Years",
       icon: BookOpen,
       color: "text-amber-500",
       bg: "bg-amber-50",
       grades: ["Pre-KG", "KG 1", "KG 2"],
    },
    {
       level: "Primary School",
       icon: FolderTree,
       color: "text-emerald-500",
       bg: "bg-emerald-50",
       grades: ["Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6"],
    },
    {
       level: "Secondary School",
       icon: GraduationCap,
       color: "text-indigo-500",
       bg: "bg-indigo-50",
       grades: ["Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"],
    }
  ];

  return (
    <div className="p-6 md:p-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
         <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
               <Network className="w-5 h-5" />
            </div>
            <div>
               <h3 className="text-xl font-black text-slate-800">Academic Structure</h3>
               <p className="text-sm font-medium text-slate-500">Define educational phases, grades, and streams.</p>
            </div>
         </div>
         <button className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-xl text-sm font-bold shadow-sm hover:bg-slate-700 transition-colors">
            <Plus className="w-4 h-4" /> Add Phase
         </button>
      </div>
      
      <div className="space-y-6 max-w-4xl">
        {structure.map((phase, idx) => {
           const Icon = phase.icon;
           return (
              <div key={idx} className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden hover:border-slate-300 transition-all">
                 <div className="p-5 flex justify-between items-center border-b border-slate-100 bg-slate-50/50">
                    <div className="flex items-center gap-3">
                       <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${phase.bg} ${phase.color}`}>
                          <Icon className="w-4 h-4" />
                       </div>
                       <h4 className="text-base font-black text-slate-800">{phase.level}</h4>
                    </div>
                    <button className="text-xs font-bold text-slate-400 hover:text-indigo-600 transition-colors flex items-center">
                       Edit Phase <ChevronRight className="w-4 h-4 ml-1" />
                    </button>
                 </div>
                 <div className="p-5">
                    <div className="flex flex-wrap gap-2">
                       {phase.grades.map((grade, i) => (
                          <div key={i} className="group relative bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg flex items-center gap-2 cursor-pointer hover:bg-white hover:border-indigo-300 transition-all">
                             <span className="text-sm font-bold text-slate-700 group-hover:text-indigo-700">{grade}</span>
                             <span className="bg-slate-200 text-slate-500 text-[10px] font-black px-1.5 py-0.5 rounded">4 Streams</span>
                          </div>
                       ))}
                       <button className="border-2 border-dashed border-slate-200 text-slate-400 hover:text-indigo-500 hover:border-indigo-300 px-3 py-1.5 rounded-lg flex items-center gap-1 transition-all text-sm font-bold">
                          <Plus className="w-4 h-4" /> Add
                       </button>
                    </div>
                 </div>
              </div>
           );
        })}
      </div>
    </div>
  );
}
