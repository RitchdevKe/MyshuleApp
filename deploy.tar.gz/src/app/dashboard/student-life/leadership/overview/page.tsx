import React from "react";
import { Award, Vote, Shield, Users, TrendingUp } from "lucide-react";

export default function LeadershipOverviewPage() {
  return (
    <div className="p-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* Executive Council */}
        <div className="col-span-1 lg:col-span-2">
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-2">
            <Award className="w-5 h-5 text-secondary-500" /> Executive Council
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { name: "John Kamau", role: "School Captain", class: "Grade 11A" },
              { name: "Mary Wanjiku", role: "Deputy Captain", class: "Grade 11B" },
              { name: "Peter Otieno", role: "Sports Captain", class: "Grade 11C" },
              { name: "Jane Doe", role: "Welfare Captain", class: "Grade 10A" },
            ].map((leader, idx) => (
              <div key={idx} className="p-4 bg-white/60 backdrop-blur-md border border-white rounded-2xl shadow-sm flex items-center gap-4 hover:shadow-md hover:bg-white transition-all duration-300">
                <div className="w-12 h-12 rounded-full bg-primary-50 flex items-center justify-center font-black text-primary-900 text-lg shadow-inner">
                  {leader.name.charAt(0)}
                </div>
                <div>
                  <div className="text-[10px] font-black uppercase tracking-wider text-secondary-500 mb-0.5">{leader.role}</div>
                  <div className="font-bold text-slate-800">{leader.name}</div>
                  <div className="text-xs text-slate-500">{leader.class}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Election Status Widget */}
        <div className="bg-primary-900 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden group">
          <div className="absolute -top-10 -right-10 p-4 opacity-10 group-hover:opacity-20 transition-opacity duration-500 transform group-hover:scale-110">
            <Vote className="w-48 h-48" />
          </div>
          
          <div className="relative z-10 flex flex-col h-full justify-between">
            <div>
              <h3 className="text-xs font-black text-secondary-400 uppercase tracking-widest mb-6">2026 Prefect Elections</h3>
              
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-xs font-bold mb-1.5">
                    <span className="text-primary-100">Voting Progress</span>
                    <span className="text-white">68% Turnout</span>
                  </div>
                  <div className="w-full bg-primary-800 rounded-full h-2.5 shadow-inner">
                    <div className="bg-gradient-to-r from-secondary-500 to-amber-300 h-2.5 rounded-full relative" style={{ width: '68%' }}>
                       <div className="absolute right-0 top-0 bottom-0 w-2 bg-white/30 rounded-full"></div>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-primary-800">
                  <div className="text-3xl font-black tracking-tight mb-1">Ends Today</div>
                  <div className="text-xs font-medium text-primary-200">Results auto-publish at 4:00 PM</div>
                </div>
              </div>
            </div>

            <button className="w-full mt-6 bg-secondary-500 hover:bg-secondary-600 text-white font-bold py-3 px-4 rounded-xl transition-colors shadow-md shadow-secondary-500/20 flex items-center justify-center gap-2">
              <Vote className="w-4 h-4" /> Manage Election
            </button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="col-span-1 lg:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-6 mt-2">
          {[
            { label: "Active Roles", value: "24", icon: Shield, color: "text-blue-500", bg: "bg-blue-50" },
            { label: "Total Leaders", value: "32", icon: Users, color: "text-green-500", bg: "bg-green-50" },
            { label: "Initiatives", value: "8", icon: TrendingUp, color: "text-purple-500", bg: "bg-purple-50" },
          ].map((stat, idx) => {
             const Icon = stat.icon;
             return (
               <div key={idx} className="bg-white/60 backdrop-blur-md border border-white p-5 rounded-2xl shadow-sm flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl ${stat.bg} flex items-center justify-center`}>
                    <Icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <div>
                    <div className="text-2xl font-black text-slate-800">{stat.value}</div>
                    <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">{stat.label}</div>
                  </div>
               </div>
             )
          })}
        </div>

      </div>
    </div>
  );
}
