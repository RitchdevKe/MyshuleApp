"use client";

import React from "react";
import { Search, Filter, Scale, AlertOctagon, FileText, Download, ShieldAlert, AlertTriangle } from "lucide-react";

export default function DisciplinaryPage() {
  const infractions = [
    { id: "DISC-2024-01", employee: "David Kim", offense: "Unauthorized Absence", action: "Written Warning", date: "Aug 05, 2024", status: "Active" },
    { id: "DISC-2024-02", employee: "Jane Doe", offense: "Tardiness", action: "Verbal Warning", date: "Jul 28, 2024", status: "Active" },
    { id: "DISC-2024-03", employee: "Michael Ochieng", offense: "Policy Violation", action: "Suspension (3 Days)", date: "Jun 15, 2024", status: "Served" },
    { id: "DISC-2024-04", employee: "Sarah Connor", offense: "Insubordination", action: "Written Warning", date: "Jan 10, 2024", status: "Expired" },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50/50">
           <div className="flex items-center gap-4">
              <div className="p-3 bg-rose-50 text-rose-600 rounded-2xl hidden md:block">
                 <Scale className="w-6 h-6" />
              </div>
              <div>
                 <h2 className="text-lg font-black text-slate-800">Disciplinary Actions</h2>
                 <p className="text-sm font-medium text-slate-500">Log and manage employee infractions and corrective actions securely.</p>
              </div>
           </div>
           <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
              <AlertOctagon className="w-4 h-4" />
              Log Infraction
           </button>
        </div>

        <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4">
           <div className="flex items-center gap-2 w-full md:w-auto relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input type="text" placeholder="Search by employee or ID..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-slate-50 border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
           </div>
           <div className="flex gap-2">
              <select className="px-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-900 cursor-pointer">
                 <option>All Statuses</option>
                 <option>Active</option>
                 <option>Served</option>
                 <option>Expired</option>
              </select>
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
                 <Filter className="w-4 h-4" />
                 Filter
              </button>
           </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Record ID</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Employee</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Offense / Infraction</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Issued Action</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Documents</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {infractions.map((record) => (
                <tr key={record.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="py-4 px-6">
                    <span className="font-bold text-slate-700 text-sm">{record.id}</span>
                    <p className="text-[10px] font-bold text-slate-400 mt-0.5">{record.date}</p>
                  </td>
                  <td className="py-4 px-6">
                    <span className="font-bold text-slate-800 text-sm">{record.employee}</span>
                  </td>
                  <td className="py-4 px-6">
                    <p className="font-bold text-slate-800 text-sm">{record.offense}</p>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center gap-1.5 px-2 py-1 text-[10px] font-black uppercase tracking-wider rounded-md ${
                      record.action.includes('Suspension') ? 'bg-rose-50 text-rose-600' : 
                      record.action.includes('Written') ? 'bg-amber-50 text-amber-600' : 
                      'bg-slate-100 text-slate-600'
                    }`}>
                      {record.action.includes('Suspension') && <ShieldAlert className="w-3 h-3" />}
                      {record.action.includes('Written') && <AlertTriangle className="w-3 h-3" />}
                      {record.action}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-lg ${
                      record.status === 'Active' ? 'bg-rose-50 text-rose-600' : 
                      record.status === 'Served' ? 'bg-blue-50 text-blue-600' : 
                      'bg-slate-100 text-slate-600'
                    }`}>
                      {record.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                     <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-2 text-primary-600 hover:bg-primary-50 rounded-lg transition-colors tooltip-trigger" title="View Incident Report">
                           <FileText className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-primary-600 hover:bg-primary-50 rounded-lg transition-colors tooltip-trigger" title="Download Warning Letter">
                           <Download className="w-4 h-4" />
                        </button>
                     </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
