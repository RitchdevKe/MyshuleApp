"use client";

import React, { useState } from "react";
import { Search, Plus, Filter, Building2, MapPin, Users, Crown, Settings, Map, ChevronRight, ChevronLeft, Building } from "lucide-react";

const BRANCHES = [
  { id: "BR-001", name: "Main Campus",         type: "Primary",   address: "Nairobi CBD",      head: "Mrs. J. Kariuki", capacity: 800, current: 650, status: "Active",    founded: "2010", facilities: ["Library", "Pool", "Labs"] },
  { id: "BR-002", name: "West Wing Campus",    type: "Secondary", address: "Westlands",        head: "Mr. D. Omondi",   capacity: 400, current: 280, status: "Active",    founded: "2015", facilities: ["Sports Field", "Labs"] },
  { id: "BR-003", name: "Eastleigh Preparatory",type: "Nursery",   address: "Eastleigh Sec 2", head: "Ms. F. Ali",      capacity: 150, current: 145, status: "Full",      founded: "2018", facilities: ["Playground"] },
  { id: "BR-004", name: "South B Annex",       type: "Primary",   address: "South B",          head: "Mr. K. Mutua",    capacity: 300, current: 40,  status: "Onboarding",founded: "2026", facilities: ["Library"] },
];

export default function BranchesPage() {
  const [search, setSearch] = useState("");

  const filtered = BRANCHES.filter(b => 
    b.name.toLowerCase().includes(search.toLowerCase()) || 
    b.head.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Branches", value: "4",       icon: Building2, color: "from-primary-600 to-primary-800" },
          { label: "Total Capacity", value: "1,650",   icon: Users,     color: "from-indigo-500 to-violet-600" },
          { label: "Enrolled",       value: "1,115",   icon: Users,     color: "from-emerald-500 to-teal-600" },
          { label: "Avg Utilisation",value: "67%",     icon: Crown,     color: "from-amber-500 to-orange-500" },
        ].map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className={`bg-gradient-to-br ${c.color} rounded-2xl p-4 text-white shadow-md flex items-center gap-3`}>
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-black leading-tight">{c.value}</p>
                <p className="text-xs font-bold text-white/80">{c.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Table Card */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden">
        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search branches..."
              className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-64 placeholder:text-slate-400"
            />
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm">
              <Filter className="w-4 h-4" /> Filter
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all">
              <Plus className="w-4 h-4" /> Add Branch
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-primary-900 to-primary-800 text-white">
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Branch Details</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Location</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Head of School</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Capacity</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Status</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(b => {
                const isFull = b.status === "Full";
                const isActive = b.status === "Active";
                
                return (
                  <tr key={b.id} className="hover:bg-primary-50/40 border-l-4 border-transparent hover:border-l-secondary-500 transition-all group">
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 flex-shrink-0">
                          <Building className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-bold text-slate-800 text-sm">{b.name}</p>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <span className="text-[10px] font-black text-primary-700 bg-primary-50 px-1.5 py-0.5 rounded">{b.id}</span>
                            <span className="text-[10px] font-bold text-slate-500">• Founded {b.founded}</span>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex flex-col">
                        <span className="flex items-center gap-1 text-xs font-bold text-slate-700">
                          <MapPin className="w-3.5 h-3.5 text-slate-400" /> {b.address}
                        </span>
                        <span className="text-[10px] font-bold text-slate-500 mt-1 pl-4.5">{b.type} School</span>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <span className="flex items-center gap-2 text-xs font-bold text-slate-700">
                        <div className="w-6 h-6 rounded-full bg-slate-200 border border-slate-300 flex items-center justify-center text-[10px] uppercase text-slate-600">
                          {b.head.charAt(0)}
                        </div>
                        {b.head}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex flex-col gap-1 w-32">
                        <div className="flex justify-between text-xs font-bold">
                          <span className={isFull ? "text-rose-600" : "text-slate-700"}>{b.current} / {b.capacity}</span>
                          <span className="text-slate-500">{Math.round((b.current/b.capacity)*100)}%</span>
                        </div>
                        <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full ${isFull ? 'bg-rose-500' : isActive ? 'bg-emerald-500' : 'bg-amber-400'}`}
                            style={{ width: `${Math.min((b.current/b.capacity)*100, 100)}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-black border ${
                        isFull ? 'bg-rose-50 text-rose-700 border-rose-200' : 
                        isActive ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 
                        'bg-amber-50 text-amber-700 border-amber-200'
                      }`}>
                        {b.status}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-primary-600 bg-primary-50 hover:bg-primary-100 border border-primary-100 rounded-lg" title="Manage Facilities">
                          <Map className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 text-slate-400 hover:bg-slate-100 rounded-lg">
                          <Settings className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}