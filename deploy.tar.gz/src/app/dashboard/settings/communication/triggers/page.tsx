"use client";

import React, { useState } from "react";
import { Zap, Plus, Search, Filter, MoreVertical, Edit2, Play, Pause, Activity } from "lucide-react";

export default function TriggersPage() {
  const [activeTab, setActiveTab] = useState("all");

  const triggers = [
     { name: "Student Absentee Alert", event: "Attendance Marked as Absent", action: "Send 'Absentee Alert' SMS to Primary Guardian", status: "Active", executions: "142 this week" },
     { name: "Fee Payment Receipt", event: "Payment Logged Successfully", action: "Send 'Payment Receipt' Email to Fee Payer", status: "Active", executions: "89 this week" },
     { name: "Overdue Fee Reminder", event: "Invoice 7 days past due", action: "Send 'Fee Reminder' Email & SMS", status: "Paused", executions: "0 this week" },
     { name: "New Enrollment Welcome", event: "Student Admission Confirmed", action: "Send 'Welcome Email' to Guardians", status: "Active", executions: "4 this week" },
     { name: "Exam Results Published", event: "Term Results Finalized", action: "Send 'Exam Results' Email to Guardians", status: "Paused", executions: "0 this week" },
  ];

  const filteredTriggers = activeTab === "all" ? triggers : triggers.filter(t => t.status.toLowerCase() === activeTab);

  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-black text-slate-800">Automation & Triggers</h3>
            <p className="text-sm font-medium text-slate-500">Set up rules to automatically send messages based on system events.</p>
          </div>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-slate-800 rounded-xl hover:bg-slate-700 transition-colors shadow-sm">
          <Plus className="w-4 h-4" /> New Rule
        </button>
      </div>

      {/* Toolbar & Filters */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
         <div className="flex space-x-1 bg-slate-100/50 p-1 rounded-xl border border-slate-200">
            {['all', 'active', 'paused'].map((tab) => (
               <button 
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-1.5 text-xs font-bold rounded-lg capitalize transition-colors ${
                     activeTab === tab 
                        ? 'bg-white text-orange-700 shadow-sm border border-slate-200/50' 
                        : 'text-slate-500 hover:text-slate-700'
                  }`}
               >
                  {tab}
               </button>
            ))}
         </div>
         
         <div className="flex items-center gap-3 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
               <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
               <input 
                  type="text" 
                  placeholder="Search rules..." 
                  className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-sm font-medium text-slate-800 focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 transition-all shadow-sm"
               />
            </div>
            <button className="flex items-center gap-2 px-3 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl font-bold text-sm hover:bg-slate-50 transition-colors shadow-sm">
               <Filter className="w-4 h-4" /> Filter
            </button>
         </div>
      </div>

      {/* Triggers List */}
      <div className="space-y-4">
         {filteredTriggers.map((trigger, idx) => {
            const isActive = trigger.status === "Active";
            return (
               <div key={idx} className={`bg-white border p-5 rounded-2xl shadow-sm transition-all group ${isActive ? 'border-slate-200 hover:border-orange-300' : 'border-slate-200/60 opacity-75'}`}>
                  
                  <div className="flex justify-between items-start mb-4">
                     <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isActive ? 'bg-orange-50 text-orange-600' : 'bg-slate-100 text-slate-400'}`}>
                           {isActive ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                        </div>
                        <div>
                           <h4 className="font-black text-slate-800 text-base">{trigger.name}</h4>
                           <div className="flex items-center gap-2 mt-0.5">
                              <Activity className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-500' : 'text-slate-400'}`} />
                              <span className="text-xs font-bold text-slate-500">{trigger.executions}</span>
                           </div>
                        </div>
                     </div>
                     
                     <div className="flex items-center gap-2">
                        <div className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${isActive ? 'bg-orange-500' : 'bg-slate-200'}`}>
                           <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${isActive ? 'translate-x-6' : 'translate-x-1'}`} />
                        </div>
                        <button className="text-slate-400 hover:text-slate-700 transition-colors ml-2">
                           <MoreVertical className="w-4 h-4" />
                        </button>
                     </div>
                  </div>
                  
                  <div className="bg-slate-50/50 rounded-xl border border-slate-100 p-4">
                     <div className="flex flex-col sm:flex-row gap-4 sm:items-center">
                        <div className="flex-1">
                           <span className="text-[10px] uppercase tracking-wider font-black text-slate-400 block mb-1">When This Happens...</span>
                           <span className="text-sm font-bold text-slate-700 bg-white border border-slate-200 px-3 py-1.5 rounded-lg inline-block w-full">{trigger.event}</span>
                        </div>
                        
                        <div className="hidden sm:flex shrink-0 items-center justify-center text-slate-300 pt-5">
                           <Zap className="w-5 h-5 text-orange-400" />
                        </div>
                        
                        <div className="flex-1">
                           <span className="text-[10px] uppercase tracking-wider font-black text-slate-400 block mb-1">Do This Action...</span>
                           <span className="text-sm font-bold text-slate-700 bg-white border border-slate-200 px-3 py-1.5 rounded-lg inline-block w-full">{trigger.action}</span>
                        </div>
                     </div>
                  </div>
                  
               </div>
            );
         })}
         
         {filteredTriggers.length === 0 && (
            <div className="text-center py-12 bg-slate-50 rounded-2xl border border-slate-200">
               <Zap className="w-8 h-8 text-slate-300 mx-auto mb-3" />
               <h4 className="text-sm font-black text-slate-600">No rules found</h4>
               <p className="text-xs text-slate-500 mt-1">Try adjusting your filters or create a new automation rule.</p>
            </div>
         )}
      </div>
    </div>
  );
}
