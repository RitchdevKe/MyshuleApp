"use client";

import React, { useState } from "react";
import {
  Search, Plus, MoreHorizontal, CheckCircle2, Clock,
  XCircle, ChevronLeft, ChevronRight, Users, ArrowRightLeft,
  Eye, GraduationCap, Home
} from "lucide-react";

const ENROLLMENTS = [
  { id: "ENR-8840", name: "Joy Wangari",    adm: "ADM-1201", grade: "Form 1",    stream: "East",  date: "Jan 06, 2026", dormitory: "Sunrise Dorm", status: "Active",    initials: "JW" },
  { id: "ENR-8839", name: "Samuel Kimani",  adm: "ADM-1200", grade: "Form 2",    stream: "West",  date: "Jan 06, 2026", dormitory: "Day Scholar",  status: "Active",    initials: "SK" },
  { id: "ENR-8838", name: "Brian Mutua",    adm: "ADM-1199", grade: "Grade 7",   stream: "North", date: "Jan 07, 2026", dormitory: "Day Scholar",  status: "Active",    initials: "BM" },
  { id: "ENR-8837", name: "Faith Njeri",    adm: "ADM-1198", grade: "Form 1",    stream: "South", date: "Jan 07, 2026", dormitory: "Sunset Dorm",  status: "Deferred",  initials: "FN" },
  { id: "ENR-8836", name: "Dennis Omondi",  adm: "ADM-1197", grade: "Grade 6",   stream: "East",  date: "Jan 08, 2026", dormitory: "Day Scholar",  status: "Active",    initials: "DO" },
  { id: "ENR-8835", name: "Alice Mwangi",   adm: "ADM-1196", grade: "Form 3",    stream: "West",  date: "Jan 08, 2026", dormitory: "Sunrise Dorm", status: "Withdrawn", initials: "AM" },
  { id: "ENR-8834", name: "Peter Otieno",   adm: "ADM-1195", grade: "Form 4",    stream: "South", date: "Jan 09, 2026", dormitory: "Day Scholar",  status: "Active",    initials: "PO" },
  { id: "ENR-8833", name: "John Smith",     adm: "ADM-1194", grade: "Pre-Primary",stream: "A",   date: "Jan 12, 2026", dormitory: "Day Scholar",  status: "Deferred",  initials: "JS" },
  { id: "ENR-8832", name: "Jane Doe",       adm: "ADM-1193", grade: "Grade 1",   stream: "B",     date: "Jan 10, 2026", dormitory: "Day Scholar",  status: "Active",    initials: "JD" },
];

const statusConfig = {
  Active:    { pill: "bg-emerald-100 text-emerald-700 border border-emerald-200", icon: CheckCircle2 },
  Deferred:  { pill: "bg-amber-100 text-amber-700 border border-amber-200",       icon: Clock },
  Withdrawn: { pill: "bg-rose-100 text-rose-700 border border-rose-200",          icon: XCircle },
};

const avatarGrads = [
  "from-primary-700 to-primary-900",
  "from-secondary-500 to-secondary-700",
  "from-indigo-500 to-violet-600",
  "from-emerald-500 to-teal-600",
  "from-amber-500 to-orange-600",
  "from-sky-500 to-blue-600",
];

const FILTERS = ["All", "Active", "Deferred", "Withdrawn"];

export default function EnrollmentsPage() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");

  const filtered = ENROLLMENTS.filter(e => {
    const matchSearch = !search || e.name.toLowerCase().includes(search.toLowerCase()) || e.id.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === "All" || e.status === filter;
    return matchSearch && matchFilter;
  });

  const counts = {
    Active:    ENROLLMENTS.filter(e => e.status === "Active").length,
    Deferred:  ENROLLMENTS.filter(e => e.status === "Deferred").length,
    Withdrawn: ENROLLMENTS.filter(e => e.status === "Withdrawn").length,
  };

  return (
    <div className="space-y-4">

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Active Enrollments", value: counts.Active,    icon: CheckCircle2, color: "from-emerald-600 to-teal-600" },
          { label: "Deferred",           value: counts.Deferred,  icon: Clock,        color: "from-amber-500 to-orange-500" },
          { label: "Withdrawn",          value: counts.Withdrawn, icon: XCircle,      color: "from-rose-600 to-red-600" },
        ].map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className={`bg-gradient-to-br ${c.color} rounded-2xl p-4 text-white shadow-md flex items-center gap-3`}>
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-black">{c.value}</p>
                <p className="text-xs font-bold text-white/80">{c.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main table card */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden">

        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search enrollments..."
                className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-52 placeholder:text-slate-400"
              />
            </div>
            <div className="flex gap-1.5">
              {FILTERS.map(f => (
                <button key={f} onClick={() => setFilter(f)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all ${filter === f ? "bg-primary-900 text-white shadow-md shadow-primary-900/20" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}>
                  {f}
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm">
              <ArrowRightLeft className="w-4 h-4" /> Transfer
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all">
              <Plus className="w-4 h-4" /> Enroll Student
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-primary-900 to-primary-800 text-white">
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Enroll ID</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Student</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Adm No.</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Class / Stream</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Residence</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Date Enrolled</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Status</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((row, i) => {
                const cfg = statusConfig[row.status as keyof typeof statusConfig];
                const Icon = cfg.icon;
                return (
                  <tr key={row.id} className="hover:bg-primary-50/40 border-l-4 border-transparent hover:border-l-secondary-500 transition-all group">
                    <td className="px-5 py-3.5">
                      <span className="text-xs font-black text-primary-900 bg-primary-50 border border-primary-100 px-2 py-1 rounded-lg">{row.id}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${avatarGrads[i % avatarGrads.length]} flex items-center justify-center text-white text-[10px] font-black shadow-sm flex-shrink-0`}>
                          {row.initials}
                        </div>
                        <span className="font-bold text-slate-800">{row.name}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2 py-1 rounded-lg border border-slate-200">{row.adm}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-slate-700 flex items-center gap-1"><GraduationCap className="w-3 h-3 text-slate-400" />{row.grade}</span>
                        <span className="text-xs text-slate-400 font-bold">{row.stream}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="text-xs font-bold text-slate-500 flex items-center gap-1"><Home className="w-3 h-3 text-slate-400" />{row.dormitory}</span>
                    </td>
                    <td className="px-5 py-3.5 text-xs font-bold text-slate-500">{row.date}</td>
                    <td className="px-5 py-3.5">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-black ${cfg.pill}`}>
                        <Icon className="w-3 h-3" />{row.status}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-primary-600 bg-primary-50 hover:bg-primary-100 border border-primary-100 rounded-lg">
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button className="p-1.5 text-secondary-600 bg-secondary-50 hover:bg-secondary-100 border border-secondary-100 rounded-lg">
                          <ArrowRightLeft className="w-3.5 h-3.5" />
                        </button>
                        <button className="p-1.5 text-slate-500 hover:bg-slate-100 rounded-lg">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="px-5 py-3.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/60">
          <span className="font-bold">Showing <span className="text-primary-900">{filtered.length}</span> of {ENROLLMENTS.length} enrollments</span>
          <div className="flex items-center gap-1">
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg hover:bg-slate-50 disabled:opacity-40 font-bold" disabled>
              <ChevronLeft className="w-3.5 h-3.5" /> Prev
            </button>
            <button className="w-8 h-8 flex items-center justify-center rounded-lg bg-primary-900 text-white text-xs font-black">1</button>
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg hover:bg-slate-50 font-bold">
              Next <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}