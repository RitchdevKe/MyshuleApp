"use client";

import React, { useState } from "react";
import { Search, Filter, Plus, Users, BookOpen, Layers, CheckCircle2, MoreHorizontal, Sparkles } from "lucide-react";

const initialData = [
  { id: "1", grade: "Grade 1", stream: "North", capacity: 35, enrolled: 32, teacher: "Sarah Wanjiku", status: "Active" },
  { id: "2", grade: "Grade 1", stream: "South", capacity: 35, enrolled: 34, teacher: "John Ochieng", status: "Active" },
  { id: "3", grade: "Grade 2", stream: "North", capacity: 35, enrolled: 35, teacher: "Mary Mutua", status: "Full" },
  { id: "4", grade: "Grade 2", stream: "South", capacity: 35, enrolled: 30, teacher: "David Kamau", status: "Active" },
  { id: "5", grade: "Grade 3", stream: "East", capacity: 40, enrolled: 38, teacher: "Lucy Njoroge", status: "Active" },
  { id: "6", grade: "Grade 4", stream: "East", capacity: 40, enrolled: 41, teacher: "Peter Kipkorir", status: "Over-enrolled" },
  { id: "7", grade: "Grade 5", stream: "West", capacity: 40, enrolled: 39, teacher: "Grace Ndung'u", status: "Active" },
  { id: "8", grade: "Grade 6", stream: "West", capacity: 40, enrolled: 36, teacher: "Samuel Odhiambo", status: "Active" }
];

export default function ClassesStreamsPage() {
  const [data, setData] = useState(initialData);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredData = data.filter(item => 
    item.grade.toLowerCase().includes(searchTerm.toLowerCase()) || 
    item.stream.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.teacher.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Classes",    value: "24",  icon: Layers,        color: "from-primary-600 to-primary-800" },
          { label: "Total Students",   value: "845", icon: Users,         color: "from-emerald-500 to-teal-600" },
          { label: "Avg Class Size",   value: "35",  icon: BookOpen,      color: "from-blue-500 to-indigo-600" },
          { label: "Active Streams",   value: "24",  icon: CheckCircle2,  color: "from-rose-500 to-pink-600" },
        ].map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className={`bg-gradient-to-br ${c.color} rounded-2xl p-4 text-white shadow-md flex items-center gap-3 relative overflow-hidden group`}>
              <div className="absolute top-0 right-0 -mt-2 -mr-2 w-16 h-16 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700"></div>
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0 relative z-10">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div className="relative z-10">
                <p className="text-2xl font-black leading-tight">{c.value}</p>
                <p className="text-xs font-bold text-white/80">{c.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden flex flex-col min-h-[500px]">
        
        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search classes, streams..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-64 placeholder:text-slate-400"
            />
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm transition-colors">
              <Filter className="w-4 h-4" /> Filter
            </button>
            <button 
              onClick={() => {
                const newData = [...data, { id: `${data.length + 1}`, grade: "New Grade", stream: "New Stream", capacity: 40, enrolled: 0, teacher: "Unassigned", status: "Draft" }];
                setData(newData);
              }}
              className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all"
            >
              <Plus className="w-4 h-4" /> Add Stream
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-5">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredData.map((row) => {
              const capacityRatio = row.enrolled / row.capacity;
              const isFull = capacityRatio >= 1;
              const isWarning = capacityRatio >= 0.9 && !isFull;
              const isOverEnrolled = row.status === 'Over-enrolled' || capacityRatio > 1;
              
              let statusBg = "bg-emerald-50 text-emerald-700 border-emerald-100";
              let statusDot = "bg-emerald-500";
              
              if (isOverEnrolled) {
                statusBg = "bg-rose-50 text-rose-700 border-rose-100";
                statusDot = "bg-rose-500";
              } else if (isFull || isWarning) {
                statusBg = "bg-amber-50 text-amber-700 border-amber-100";
                statusDot = "bg-amber-500";
              } else if (row.status === 'Draft') {
                statusBg = "bg-slate-50 text-slate-600 border-slate-200";
                statusDot = "bg-slate-400";
              }
              
              return (
                <div key={row.id} className="bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300 group overflow-hidden flex flex-col relative">
                  
                  {/* Card Header */}
                  <div className="p-4 border-b border-slate-50 flex justify-between items-start bg-gradient-to-br from-slate-50 to-white">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-black text-slate-800 text-lg">{row.grade}</h3>
                        {/* Live Beacon - Simulated class in session */}
                        {row.status === 'Active' && (
                          <span className="relative flex h-2.5 w-2.5">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-secondary-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-secondary-500"></span>
                          </span>
                        )}
                      </div>
                      <p className="text-slate-500 font-bold text-xs flex items-center gap-1 mt-0.5 uppercase tracking-wider">
                        Stream: <span className="font-black text-primary-700">{row.stream}</span>
                      </p>
                    </div>
                    <button className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                      <MoreHorizontal className="w-4 h-4" />
                    </button>
                  </div>
                  
                  {/* Card Body */}
                  <div className="p-4 flex-1 flex flex-col gap-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center flex-shrink-0 text-slate-400">
                        <Users className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Class Teacher</p>
                        <p className="font-bold text-slate-800 text-sm">{row.teacher}</p>
                      </div>
                    </div>
                    
                    <div className="mt-auto pt-2">
                      <div className="flex justify-between items-end mb-2">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Enrollment</p>
                        <p className="text-xs font-black text-slate-600">
                          <span className={isOverEnrolled ? "text-rose-600" : isFull ? "text-amber-600" : ""}>{row.enrolled}</span> 
                          <span className="text-slate-400 mx-1">/</span> 
                          {row.capacity}
                        </p>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden shadow-inner">
                        <div 
                          className={`h-full rounded-full ${statusDot} transition-all duration-500`}
                          style={{ width: `${Math.min((row.enrolled / row.capacity) * 100, 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Card Footer */}
                  <div className="px-4 py-3 bg-slate-50/50 border-t border-slate-50 flex justify-between items-center mt-auto">
                    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-lg border text-[10px] font-black uppercase tracking-wider ${statusBg}`}>
                      {row.status}
                    </span>
                    <button className="text-[10px] font-black text-primary-600 hover:text-secondary-500 uppercase tracking-wider transition-colors">
                      View Roster
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
          
          {filteredData.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-slate-400">
              <Sparkles className="w-8 h-8 mb-3 opacity-20" />
              <p className="font-bold text-lg text-slate-500">No classes found</p>
              <p className="text-sm font-medium mt-1">Try adjusting your search criteria</p>
            </div>
          )}
        </div>
        
        {/* Footer */}
        <div className="px-5 py-3.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/60 mt-auto">
          <span className="font-bold">Showing <span className="text-primary-900">{filteredData.length}</span> streams</span>
        </div>
      </div>
    </div>
  );
}