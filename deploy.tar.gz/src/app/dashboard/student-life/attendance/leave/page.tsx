"use client";
import React, { useState } from "react";
import { Plus, Check, X, Clock, FileText } from "lucide-react";

export default function LeaveManagementTab() {
  const [requests, setRequests] = useState([
    { id: "LR-1024", student: "Sarah Wanjiku", grade: "Grade 10B", type: "Medical", duration: "3 Days", dates: "Oct 12 - Oct 14", status: "Pending", document: true },
    { id: "LR-1023", student: "Kevin Ochieng", grade: "Grade 8A", type: "Family Event", duration: "1 Day", dates: "Oct 11", status: "Approved", document: false },
    { id: "LR-1022", student: "Faith Mutheu", grade: "Grade 12C", type: "Sports Competition", duration: "2 Days", dates: "Oct 10 - Oct 11", status: "Rejected", document: true },
  ]);

  const handleAction = (id: string, action: string) => {
    setRequests(requests.map(r => r.id === id ? { ...r, status: action } : r));
  };

  return (
    <div className="p-6 space-y-6">
      
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-amber-50/80 backdrop-blur-md border border-amber-200 p-6 rounded-3xl shadow-sm relative overflow-hidden group">
          <div className="absolute right-4 top-4 bg-amber-100 p-3 rounded-2xl group-hover:scale-110 transition-transform">
            <Clock className="w-6 h-6 text-amber-600" />
          </div>
          <div className="text-4xl font-black text-amber-600 mb-1">14</div>
          <div className="text-sm font-bold text-amber-800 uppercase tracking-wider">Pending Requests</div>
        </div>
        <div className="bg-emerald-50/80 backdrop-blur-md border border-emerald-200 p-6 rounded-3xl shadow-sm relative overflow-hidden group">
          <div className="absolute right-4 top-4 bg-emerald-100 p-3 rounded-2xl group-hover:scale-110 transition-transform">
            <Check className="w-6 h-6 text-emerald-600" />
          </div>
          <div className="text-4xl font-black text-emerald-600 mb-1">82</div>
          <div className="text-sm font-bold text-emerald-800 uppercase tracking-wider">Approved (This Term)</div>
        </div>
        <div className="bg-rose-50/80 backdrop-blur-md border border-rose-200 p-6 rounded-3xl shadow-sm relative overflow-hidden group">
          <div className="absolute right-4 top-4 bg-rose-100 p-3 rounded-2xl group-hover:scale-110 transition-transform">
            <X className="w-6 h-6 text-rose-600" />
          </div>
          <div className="text-4xl font-black text-rose-600 mb-1">7</div>
          <div className="text-sm font-bold text-rose-800 uppercase tracking-wider">Rejected (This Term)</div>
        </div>
      </div>

      <div className="flex justify-between items-center bg-white/40 p-4 rounded-3xl border border-white/60 backdrop-blur-md shadow-sm">
        <h2 className="text-lg font-black text-slate-800">Leave Requests</h2>
        <button className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 text-white text-sm font-bold rounded-xl shadow-md shadow-indigo-600/20 hover:bg-indigo-700 transition-colors">
          <Plus className="w-4 h-4" /> Log New Leave
        </button>
      </div>

      <div className="bg-white/60 backdrop-blur-md border border-white rounded-3xl overflow-hidden shadow-sm">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50 border-b border-slate-200/50">
              <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider">Student</th>
              <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider">Details</th>
              <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider">Dates</th>
              <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider">Status</th>
              <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {requests.map(request => (
              <tr key={request.id} className="hover:bg-white/80 transition-colors">
                <td className="p-4">
                  <div className="font-bold text-slate-800 text-sm">{request.student}</div>
                  <div className="text-xs font-bold text-slate-400">{request.grade} • {request.id}</div>
                </td>
                <td className="p-4">
                  <div className="font-bold text-slate-700 text-sm">{request.type}</div>
                  <div className="text-xs font-bold text-slate-500 flex items-center gap-1 mt-0.5">
                    {request.duration}
                    {request.document && <FileText className="w-3 h-3 text-indigo-500 ml-1" />}
                  </div>
                </td>
                <td className="p-4">
                  <div className="font-bold text-slate-700 text-sm">{request.dates}</div>
                </td>
                <td className="p-4">
                  <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider ${
                    request.status === 'Approved' ? 'bg-emerald-100 text-emerald-700' :
                    request.status === 'Rejected' ? 'bg-rose-100 text-rose-700' :
                    'bg-amber-100 text-amber-700'
                  }`}>
                    {request.status}
                  </span>
                </td>
                <td className="p-4 text-right">
                  {request.status === 'Pending' ? (
                    <div className="flex justify-end gap-2">
                      <button onClick={() => handleAction(request.id, 'Approved')} className="p-2 bg-emerald-50 text-emerald-600 hover:bg-emerald-500 hover:text-white rounded-xl transition-colors border border-emerald-200">
                        <Check className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleAction(request.id, 'Rejected')} className="p-2 bg-rose-50 text-rose-600 hover:bg-rose-500 hover:text-white rounded-xl transition-colors border border-rose-200">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <span className="text-xs font-bold text-slate-400">Processed</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
