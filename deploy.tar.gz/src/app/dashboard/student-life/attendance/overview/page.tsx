"use client";
import React from "react";
import { AlertCircle } from "lucide-react";

export default function AttendanceOverviewTab() {
  return (
    <div className="p-6">
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
        <div className="col-span-1 md:col-span-2 bg-gradient-to-br from-indigo-500 to-indigo-700 text-white p-6 rounded-3xl shadow-lg shadow-indigo-600/20 border border-indigo-400/30 flex flex-col justify-center relative overflow-hidden group">
          <div className="absolute -right-10 -top-10 w-40 h-40 bg-white/10 rounded-full blur-2xl group-hover:bg-white/20 transition-all duration-500"></div>
          <div className="text-5xl font-black mb-2 tracking-tight">94.8%</div>
          <div className="text-sm font-bold uppercase tracking-wider text-indigo-100">Today's Attendance</div>
        </div>
        
        <div className="bg-white/60 backdrop-blur-md border border-white p-6 rounded-3xl shadow-sm text-center flex flex-col items-center justify-center hover:shadow-md transition-shadow">
          <div className="text-4xl font-black text-emerald-600 mb-2">3,842</div>
          <div className="text-xs font-black text-slate-500 uppercase tracking-wider">Present</div>
        </div>
        
        <div className="bg-white/60 backdrop-blur-md border border-white p-6 rounded-3xl shadow-sm text-center flex flex-col items-center justify-center hover:shadow-md transition-shadow">
          <div className="text-4xl font-black text-rose-600 mb-2">147</div>
          <div className="text-xs font-black text-slate-500 uppercase tracking-wider">Absent</div>
        </div>
        
        <div className="bg-white/60 backdrop-blur-md border border-white p-6 rounded-3xl shadow-sm text-center flex flex-col items-center justify-center hover:shadow-md transition-shadow">
          <div className="text-4xl font-black text-amber-500 mb-2">86</div>
          <div className="text-xs font-black text-slate-500 uppercase tracking-wider">Late</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Attendance by section */}
        <div className="bg-white/40 backdrop-blur-md rounded-3xl p-6 border border-white/60 shadow-sm">
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-6">Attendance by Section</h3>
          <div className="space-y-5">
            {[
              { section: "Preschool", rate: 97.2, color: "bg-emerald-500" },
              { section: "Primary", rate: 95.1, color: "bg-emerald-400" },
              { section: "Junior School", rate: 94.3, color: "bg-amber-400" },
              { section: "Secondary", rate: 92.8, color: "bg-rose-400" },
            ].map((s) => (
              <div key={s.section} className="group">
                <div className="flex justify-between text-xs font-bold text-slate-700 mb-1.5">
                  <span>{s.section}</span>
                  <span className="text-slate-900">{s.rate}%</span>
                </div>
                <div className="w-full bg-slate-200/50 rounded-full h-2.5 overflow-hidden border border-slate-200/50">
                  <div className={`${s.color} h-full rounded-full transition-all duration-1000 ease-out group-hover:opacity-80`} style={{ width: `${s.rate}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Alerts */}
        <div className="lg:col-span-2 bg-rose-50/50 backdrop-blur-md rounded-3xl p-6 border border-rose-100/60 shadow-sm">
          <h3 className="text-sm font-black text-rose-800 uppercase tracking-wider mb-5 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-rose-600" /> Attendance Exceptions
          </h3>
          <div className="space-y-3">
            {[
              { alert: "Brian Mwangi absent 3 consecutive days", type: "Chronic Absence", priority: "High" },
              { alert: "12 students have attendance below 80%", type: "Policy Breach", priority: "High" },
              { alert: "Grade 7B attendance fallen by 6% this week", type: "Trend Alert", priority: "Medium" },
              { alert: "Peter Otieno late 5 times this month", type: "Lateness", priority: "Low" },
            ].map((alert, idx) => (
              <div key={idx} className="p-4 bg-white/80 backdrop-blur-sm border border-rose-100 rounded-2xl flex items-center justify-between shadow-sm hover:shadow-md transition-shadow cursor-pointer">
                <div className="flex items-center gap-4">
                  <div className={`w-3 h-3 rounded-full shadow-inner ${alert.priority === 'High' ? 'bg-rose-500 shadow-rose-500/50' : alert.priority === 'Medium' ? 'bg-amber-500 shadow-amber-500/50' : 'bg-slate-400 shadow-slate-400/50'}`}></div>
                  <span className="text-sm font-bold text-slate-800">{alert.alert}</span>
                </div>
                <span className={`text-[10px] font-black uppercase tracking-wider px-3 py-1.5 rounded-xl ${
                  alert.type === 'Chronic Absence' ? 'text-rose-700 bg-rose-100' : 
                  alert.type === 'Policy Breach' ? 'text-orange-700 bg-orange-100' :
                  alert.type === 'Trend Alert' ? 'text-amber-700 bg-amber-100' : 'text-slate-600 bg-slate-100'
                }`}>{alert.type}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
