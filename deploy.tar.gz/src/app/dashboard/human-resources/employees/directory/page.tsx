"use client";

import React from "react";
import { Users, Filter, Mail, Phone, MoreVertical, ShieldCheck, GraduationCap, Building2, UserPlus, FileText } from "lucide-react";

export default function DirectoryPage() {
  const employees = [
    { id: "E001", name: "Jane Doe", role: "Senior Mathematics Teacher", department: "Academics", status: "Active", rating: 4.8, hired: "Aug 2020", type: "Full-Time" },
    { id: "E002", name: "John Smith", role: "Maintenance Supervisor", department: "Operations", status: "Active", rating: 4.5, hired: "Jan 2021", type: "Full-Time" },
    { id: "E003", name: "Emily Chen", role: "School Nurse", department: "Health", status: "On Leave", rating: 4.9, hired: "Mar 2022", type: "Part-Time" },
    { id: "E004", name: "Michael Ochieng", role: "IT Support Technician", department: "Administration", status: "Active", rating: 4.2, hired: "Jun 2023", type: "Contract" },
    { id: "E005", name: "Sarah Connor", role: "Head of Sciences", department: "Academics", status: "Active", rating: 5.0, hired: "Sep 2018", type: "Full-Time" },
    { id: "E006", name: "David Kim", role: "Bus Driver", department: "Transport", status: "Active", rating: 4.6, hired: "Feb 2024", type: "Contract" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-primary-50 text-primary-600 rounded-2xl">
             <Users className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Staff</p>
            <p className="text-2xl font-black text-slate-800">142</p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
             <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active</p>
            <p className="text-2xl font-black text-slate-800">135</p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl">
             <UserPlus className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">On Leave</p>
            <p className="text-2xl font-black text-slate-800">7</p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
             <FileText className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Contracts</p>
            <p className="text-2xl font-black text-slate-800">12<span className="text-sm text-slate-400">/mo</span></p>
          </div>
        </div>
      </div>

      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-4 flex flex-col md:flex-row justify-between items-center gap-4">
         <div className="flex items-center gap-2 w-full md:w-auto">
            <input type="text" placeholder="Search employees by name, role, or ID..." className="w-full md:w-80 px-4 py-2 bg-slate-50 border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
         </div>
         <div className="flex flex-wrap gap-2">
            <select className="px-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-900 cursor-pointer">
               <option>All Departments</option>
               <option>Academics</option>
               <option>Operations</option>
               <option>Health</option>
            </select>
            <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
               <Filter className="w-4 h-4" />
               More Filters
            </button>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
         {employees.map((emp) => (
            <div key={emp.id} className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-6 hover:shadow-xl transition-all duration-300 group">
               <div className="flex justify-between items-start mb-4">
                  <div className="flex gap-4">
                     <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400 font-black text-lg shrink-0 group-hover:bg-primary-50 group-hover:text-primary-600 transition-colors">
                        {emp.name.split(' ').map(n => n[0]).join('')}
                     </div>
                     <div>
                        <h3 className="font-black text-lg text-slate-800">{emp.name}</h3>
                        <p className="text-sm font-bold text-slate-500">{emp.role}</p>
                        <div className="flex items-center gap-2 mt-1.5">
                           <span className="text-[10px] uppercase tracking-wider font-black text-primary-600 bg-primary-50 px-2 py-0.5 rounded-md">{emp.department}</span>
                           <span className={`text-[10px] uppercase tracking-wider font-black px-2 py-0.5 rounded-md ${emp.status === 'Active' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                              {emp.status}
                           </span>
                        </div>
                     </div>
                  </div>
                  <button className="text-slate-400 hover:text-primary-900 transition-colors p-1 rounded-lg hover:bg-slate-50">
                     <MoreVertical className="w-5 h-5" />
                  </button>
               </div>
               
               <div className="grid grid-cols-2 gap-4 py-4 my-4 border-y border-slate-100">
                  <div>
                     <p className="text-xs font-bold text-slate-400 mb-1">Employee ID</p>
                     <p className="text-sm font-bold text-slate-700">{emp.id}</p>
                  </div>
                  <div>
                     <p className="text-xs font-bold text-slate-400 mb-1">Contract Type</p>
                     <p className="text-sm font-bold text-slate-700">{emp.type}</p>
                  </div>
                  <div>
                     <p className="text-xs font-bold text-slate-400 mb-1">Hired Date</p>
                     <p className="text-sm font-bold text-slate-700">{emp.hired}</p>
                  </div>
                  <div>
                     <p className="text-xs font-bold text-slate-400 mb-1">Perf. Rating</p>
                     <p className="text-sm font-bold text-slate-700 flex items-center gap-1">
                        <span className="text-amber-400">★</span> {emp.rating}/5.0
                     </p>
                  </div>
               </div>

               <div className="flex items-center justify-between">
                  <div className="flex gap-2">
                     <button className="p-2 bg-slate-50 hover:bg-primary-50 hover:text-primary-600 rounded-xl transition-colors tooltip-trigger" title="Send Email">
                        <Mail className="w-4 h-4 text-slate-500" />
                     </button>
                     <button className="p-2 bg-slate-50 hover:bg-primary-50 hover:text-primary-600 rounded-xl transition-colors tooltip-trigger" title="Call">
                        <Phone className="w-4 h-4 text-slate-500" />
                     </button>
                  </div>
                  <button className="px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white text-sm font-bold rounded-xl transition-colors shadow-sm shadow-primary-900/20">
                     View Profile
                  </button>
               </div>
            </div>
         ))}
      </div>
    </div>
  );
}
