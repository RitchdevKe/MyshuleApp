"use client";

import React from "react";
import { Files, Upload, Search, Filter, Folder, FileText, Image as ImageIcon, MoreVertical, ShieldCheck, AlertTriangle } from "lucide-react";

export default function DocumentsPage() {
  const folders = [
    { name: "Employee IDs", count: 142, icon: ImageIcon, color: "text-blue-500", bg: "bg-blue-50" },
    { name: "Tax Forms (KRA)", count: 135, icon: FileText, color: "text-emerald-500", bg: "bg-emerald-50" },
    { name: "Certifications", count: 89, icon: ShieldCheck, color: "text-indigo-500", bg: "bg-indigo-50" },
    { name: "Background Checks", count: 142, icon: AlertTriangle, color: "text-amber-500", bg: "bg-amber-50" },
  ];

  const recentDocs = [
    { id: 1, name: "JDoe_Passport.pdf", type: "ID Document", owner: "Jane Doe", size: "2.4 MB", date: "Today, 09:41 AM" },
    { id: 2, name: "MSmith_KRA_PIN.pdf", type: "Tax Form", owner: "Michael Smith", size: "1.1 MB", date: "Yesterday, 14:22 PM" },
    { id: 3, name: "Teacher_Cert_2024.jpg", type: "Certification", owner: "Sarah Connor", size: "4.8 MB", date: "Aug 09, 2024" },
    { id: 4, name: "Police_Clearance_E004.pdf", type: "Background Check", owner: "Emily Chen", size: "1.5 MB", date: "Aug 08, 2024" },
  ];

  return (
    <div className="space-y-6">
      
      {/* Folder Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {folders.map((folder, index) => {
          const Icon = folder.icon;
          return (
            <div key={index} className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm hover:shadow-md transition-all cursor-pointer group">
              <div className="flex justify-between items-start mb-4">
                <div className={`p-4 rounded-2xl ${folder.bg} ${folder.color} group-hover:scale-110 transition-transform`}>
                  <Icon className="w-8 h-8" />
                </div>
                <button className="text-slate-400 hover:text-primary-900 p-1">
                  <MoreVertical className="w-5 h-5" />
                </button>
              </div>
              <h3 className="font-black text-slate-800">{folder.name}</h3>
              <p className="text-sm font-bold text-slate-500 mt-1">{folder.count} Files</p>
            </div>
          );
        })}
      </div>

      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4">
           <div>
              <h2 className="text-lg font-black text-slate-800">Recent Uploads</h2>
              <p className="text-sm font-medium text-slate-500">Latest documents added to the repository</p>
           </div>
           <div className="flex gap-3">
              <div className="relative">
                 <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                 <input type="text" placeholder="Search files..." className="w-full md:w-64 pl-9 pr-4 py-2 bg-slate-50 border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
              </div>
              <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
                 <Upload className="w-4 h-4" />
                 Upload
              </button>
           </div>
        </div>
        
        <div className="overflow-x-auto p-2">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="text-slate-400">
                <th className="py-3 px-4 text-xs font-bold uppercase tracking-wider">File Name</th>
                <th className="py-3 px-4 text-xs font-bold uppercase tracking-wider">Type</th>
                <th className="py-3 px-4 text-xs font-bold uppercase tracking-wider">Owner</th>
                <th className="py-3 px-4 text-xs font-bold uppercase tracking-wider">Size</th>
                <th className="py-3 px-4 text-xs font-bold uppercase tracking-wider">Date Modified</th>
                <th className="py-3 px-4 text-xs font-bold uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {recentDocs.map((doc) => (
                <tr key={doc.id} className="hover:bg-slate-50/80 transition-colors group rounded-2xl">
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-3">
                       <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500">
                          {doc.name.endsWith('.pdf') ? <FileText className="w-5 h-5 text-red-500" /> : <ImageIcon className="w-5 h-5 text-blue-500" />}
                       </div>
                       <span className="font-bold text-slate-700 text-sm">{doc.name}</span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <span className="px-3 py-1 bg-slate-100 text-slate-600 text-xs font-bold rounded-lg">{doc.type}</span>
                  </td>
                  <td className="py-4 px-4">
                    <p className="font-bold text-slate-700 text-sm">{doc.owner}</p>
                  </td>
                  <td className="py-4 px-4 text-sm text-slate-500 font-medium">
                    {doc.size}
                  </td>
                  <td className="py-4 px-4 text-sm text-slate-500 font-medium">
                    {doc.date}
                  </td>
                  <td className="py-4 px-4 text-right">
                    <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                       <button className="p-2 text-primary-600 hover:bg-primary-50 rounded-lg transition-colors font-bold text-sm">Download</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
