"use client";

import React from "react";
import { Wallet } from "lucide-react";

export default function PaymentMethodsPage() {
  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden p-12 flex flex-col items-center justify-center text-center min-h-[400px]">
      <div className="w-16 h-16 bg-slate-100 text-slate-400 rounded-2xl flex items-center justify-center mb-4 shadow-inner">
        <Wallet className="w-8 h-8" />
      </div>
      <h3 className="text-xl font-black text-slate-800">Coming Soon</h3>
      <p className="text-sm font-medium text-slate-500 max-w-md mt-2">
        The Payment Methods configuration is currently being built.
      </p>
    </div>
  );
}
