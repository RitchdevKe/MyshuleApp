import React from "react";
import { Shield, Heart, GraduationCap, Award, BookOpen, Target, Download, Share2 } from "lucide-react";

export default function EngagementOverviewPage() {
  return (
    <div className="p-8">
      {/* The MyShule Student Passport Preview */}
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-secondary-500" /> MyShule Student Passport
          </h2>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-slate-100 text-slate-500 text-xs font-black uppercase tracking-wider rounded-lg border border-slate-200">Preview Mode</span>
            <button className="p-2 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"><Download className="w-4 h-4" /></button>
            <button className="p-2 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"><Share2 className="w-4 h-4" /></button>
          </div>
        </div>

        {/* Passport Header */}
        <div className="bg-white/60 backdrop-blur-md border border-white rounded-3xl p-8 shadow-sm mb-6 flex flex-col md:flex-row gap-8 items-start relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-secondary-500/5 rounded-full blur-3xl -z-10 pointer-events-none"></div>
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-primary-500/5 rounded-full blur-3xl -z-10 pointer-events-none"></div>

          <div className="w-32 h-32 rounded-3xl bg-primary-50 flex items-center justify-center border-4 border-white shadow-md shrink-0 relative group cursor-pointer">
            <span className="text-4xl font-black text-primary-900">JK</span>
            <div className="absolute inset-0 bg-black/40 rounded-3xl opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
               <span className="text-white text-[10px] font-bold uppercase tracking-wider">View Profile</span>
            </div>
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-start">
               <div>
                 <h1 className="text-4xl font-black text-slate-800 mb-1">John Kamau</h1>
                 <p className="text-sm font-bold text-slate-500 mb-6 flex items-center gap-2">
                   <span>Grade 11A</span> 
                   <span className="w-1 h-1 rounded-full bg-slate-300"></span> 
                   <span>ADM-2023-001</span>
                 </p>
               </div>
               <div className="text-right">
                  <div className="text-2xl font-black text-secondary-500">1,250</div>
                  <div className="text-[10px] font-black uppercase tracking-wider text-slate-400">Passport Points</div>
               </div>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1.5 bg-white/80 backdrop-blur text-primary-700 text-xs font-bold rounded-xl border border-primary-100 shadow-sm flex items-center gap-1.5"><Shield className="w-3.5 h-3.5" /> School Captain</span>
              <span className="px-3 py-1.5 bg-white/80 backdrop-blur text-secondary-700 text-xs font-bold rounded-xl border border-secondary-200 shadow-sm flex items-center gap-1.5"><Award className="w-3.5 h-3.5" /> Best Debater '25</span>
              <span className="px-3 py-1.5 bg-white/80 backdrop-blur text-rose-700 text-xs font-bold rounded-xl border border-rose-200 shadow-sm flex items-center gap-1.5"><Heart className="w-3.5 h-3.5" /> 45 Community Hrs</span>
            </div>
          </div>
        </div>

        {/* Passport Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Academics & Attendance */}
          <div className="bg-white/60 backdrop-blur-md rounded-3xl p-6 border border-white shadow-sm hover:shadow-md transition-shadow">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-indigo-500" /> Academic & Attendance
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center bg-white p-4 rounded-2xl border border-slate-100 shadow-sm hover:border-indigo-100 transition-colors">
                <span className="text-sm font-bold text-slate-600">Overall Attendance</span>
                <span className="font-black text-emerald-600">98.2%</span>
              </div>
              <div className="flex justify-between items-center bg-white p-4 rounded-2xl border border-slate-100 shadow-sm hover:border-indigo-100 transition-colors">
                <span className="text-sm font-bold text-slate-600">Behaviour Record</span>
                <span className="font-black text-emerald-600">Excellent</span>
              </div>
              <div className="flex justify-between items-center bg-white p-4 rounded-2xl border border-slate-100 shadow-sm hover:border-indigo-100 transition-colors">
                <span className="text-sm font-bold text-slate-600">Latest Academic Average</span>
                <span className="font-black text-indigo-600">A-</span>
              </div>
            </div>
          </div>

          {/* Extracurricular */}
          <div className="bg-white/60 backdrop-blur-md rounded-3xl p-6 border border-white shadow-sm hover:shadow-md transition-shadow">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Target className="w-5 h-5 text-secondary-500" /> Extracurricular
            </h3>
            <div className="space-y-3">
              <div className="p-4 bg-white border border-slate-100 rounded-2xl shadow-sm hover:border-secondary-200 transition-colors">
                <div className="text-sm font-bold text-slate-800">School Football U16</div>
                <div className="text-[10px] font-bold text-slate-400 uppercase mt-1">Team Captain • 2024-Present</div>
              </div>
              <div className="p-4 bg-white border border-slate-100 rounded-2xl shadow-sm hover:border-secondary-200 transition-colors">
                <div className="text-sm font-bold text-slate-800">Debate Club</div>
                <div className="text-[10px] font-bold text-slate-400 uppercase mt-1">Member • 2023-Present</div>
              </div>
              <div className="p-4 bg-white border border-slate-100 rounded-2xl shadow-sm hover:border-secondary-200 transition-colors flex justify-between items-center">
                <div>
                  <div className="text-sm font-bold text-slate-800">Tree Planting Initiative</div>
                  <div className="text-[10px] font-bold text-slate-400 uppercase mt-1">Community Service</div>
                </div>
                <span className="px-2 py-1 bg-green-50 text-green-700 text-xs font-bold rounded-lg border border-green-200">
                  24 Hrs
                </span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
