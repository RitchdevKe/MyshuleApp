"use client";

import React from "react";
import { Download, Search, CheckSquare, Clock, Filter, AlertCircle } from "lucide-react";

export default function TimesheetsPage() {
  const timesheets = [
    { id: "E001", name: "Jane Doe", role: "Senior Mathematics Teacher", week: "Aug 05 - Aug 11", regularHours: 40, overtime: 2.5, status: "Pending Approval" },
    { id: "E005", name: "Sarah Connor", role: "Head of Sciences", week: "Aug 05 - Aug 11", regularHours: 40, overtime: 5.0, status: "Approved" },
    { id: "E002", name: "John Smith", role: "Maintenance Supervisor", week: "Aug 05 - Aug 11", regularHours: 40, overtime: 8.5, status: "Approved" },
    { id: "E006", name: "David Kim", role: "Bus Driver", week: "Aug 05 - Aug 11", regularHours: 35, overtime: 0, status: "Draft" },
    { id: "E004", name: "Michael Ochieng", role: "IT Support", week: "Aug 05 - Aug 11", regularHours: 40, overtime: 12, status: "Pending Approval" },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4">
           <div>
              <h2 className="text-lg font-black text-slate-800">Weekly Timesheets</h2>
              <p className="text-sm font-medium text-slate-500">Review and approve employee logged hours.</p>
           </div>
           <div className="flex gap-3">
              <div className="relative">
                 <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                 <input type="text" placeholder="Search employees..." className="w-full md:w-64 pl-9 pr-4 py-2 bg-slate-50 border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
              </div>
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
                 <Filter className="w-4 h-4" />
                 Filter
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
                 <CheckSquare className="w-4 h-4" />
                 Approve All
              </button>
           </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Employee</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Period</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Regular Hrs</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Overtime</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Total</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {timesheets.map((ts) => (
                <tr key={ts.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="py-4 px-6">
                    <p className="font-bold text-slate-800 text-sm">{ts.name}</p>
                    <p className="text-xs text-slate-500 font-medium">{ts.role}</p>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm font-bold text-slate-600">{ts.week}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm font-bold text-slate-700">{ts.regularHours}h</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`text-sm font-bold ${ts.overtime > 0 ? 'text-amber-600' : 'text-slate-400'}`}>{ts.overtime}h</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm font-black text-slate-800">{ts.regularHours + ts.overtime}h</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-lg ${
                      ts.status === 'Approved' ? 'bg-emerald-50 text-emerald-600' : 
                      ts.status === 'Pending Approval' ? 'bg-amber-50 text-amber-600' : 
                      'bg-slate-100 text-slate-600'
                    }`}>
                      {ts.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    {ts.status === 'Pending Approval' ? (
                       <button className="text-sm font-bold text-white bg-primary-900 hover:bg-primary-800 px-3 py-1.5 rounded-lg transition-colors">Review</button>
                    ) : (
                       <button className="text-sm font-bold text-primary-600 hover:text-primary-800 hover:underline">View</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
