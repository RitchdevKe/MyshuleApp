"use client";

import React from "react";
import { ShieldCheck, AlertCircle } from "lucide-react";

export default function CenterPage() {
  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden p-6 space-y-6">
      
      {/* Security Score Widget */}
      <div className="bg-white border border-emerald-200 rounded-2xl p-6 shadow-sm flex items-center justify-between">
        <div>
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-2">Tenant Security Health</h3>
          <div className="flex items-center gap-4">
            <div className="text-5xl font-black text-emerald-600">91%</div>
            <div className="text-sm font-bold text-slate-500">Your tenant is secure. <br/> 2 minor issues detected.</div>
          </div>
        </div>
        <div className="w-24 h-24 rounded-full bg-emerald-50 flex items-center justify-center shrink-0">
          <ShieldCheck className="w-12 h-12 text-emerald-500" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Security Checklist */}
        <div className="bg-slate-50/50 border border-slate-200/60 rounded-2xl p-6 shadow-sm">
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4">Security Checklist</h3>
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 bg-white border border-emerald-100 rounded-xl">
              <div className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center text-white shrink-0">✓</div>
              <span className="text-sm font-bold text-slate-700">MFA enabled for Administrators</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white border border-emerald-100 rounded-xl">
              <div className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center text-white shrink-0">✓</div>
              <span className="text-sm font-bold text-slate-700">System backup is healthy</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white border border-amber-200 rounded-xl shadow-sm shadow-amber-500/10">
              <div className="w-5 h-5 rounded-full bg-amber-500 flex items-center justify-center text-white font-black text-xs shrink-0">!</div>
              <div className="flex-1">
                <span className="text-sm font-bold text-slate-800 block">7 dormant accounts detected</span>
                <button className="text-xs font-bold text-primary-600 hover:underline mt-1">Review Accounts</button>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white border border-amber-200 rounded-xl shadow-sm shadow-amber-500/10">
              <div className="w-5 h-5 rounded-full bg-amber-500 flex items-center justify-center text-white font-black text-xs shrink-0">!</div>
              <div className="flex-1">
                <span className="text-sm font-bold text-slate-800 block">Weak password policy for students</span>
                <button className="text-xs font-bold text-primary-600 hover:underline mt-1">Update Policy</button>
              </div>
            </div>
          </div>
        </div>

        {/* Active Sessions Overview */}
        <div className="bg-white border border-slate-200/60 rounded-2xl p-6 shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider">Active Sessions (Admins)</h3>
            <button className="text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 px-3 py-1.5 rounded-lg transition-colors shadow-sm shadow-rose-600/20">Force Revoke All</button>
          </div>
          
          <div className="space-y-4">
            {[
              { user: "Jane Wanjiku", device: "Chrome — Windows", location: "Nairobi", time: "Active now" },
              { user: "Peter Kamau", device: "Safari — MacOS", location: "Nairobi", time: "Active now" },
              { user: "Jane Wanjiku", device: "MyShuleApp — Android", location: "Mombasa", time: "12 mins ago" },
            ].map((sess, idx) => (
              <div key={idx} className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex justify-between items-start">
                <div>
                  <div className="font-bold text-sm text-slate-800">{sess.user}</div>
                  <div className="text-xs text-slate-500 mt-0.5">{sess.device} • {sess.location}</div>
                  <div className="text-[10px] font-black uppercase tracking-wider text-primary-500 mt-1">{sess.time}</div>
                </div>
                <button className="text-[10px] font-black uppercase tracking-wider bg-white border border-slate-200 text-slate-500 px-2 py-1 rounded shadow-sm hover:text-rose-600">Revoke</button>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
