"use client";

import React, { useState } from "react";
import { Search, Filter, Plus, MoreHorizontal, Mail, Smartphone, MessageSquare, ChevronLeft, ChevronRight, CheckCircle2, Send, Clock, Sparkles } from "lucide-react";

const MESSAGES = [
  { id: "MSG-001", date: "Oct 12, 2026", recipient: "All Grade 1 Parents", type: "SMS",   summary: "School Trip reminder for Friday. Ensure students carry packed lunch.", status: "Sent" },
  { id: "MSG-002", date: "Oct 10, 2026", recipient: "Grace Njenga",        type: "Email", summary: "Fee Balance statement for Term 3. Kindly clear before midterm.",     status: "Delivered" },
  { id: "MSG-003", date: "Oct 09, 2026", recipient: "PTA Committee",       type: "Email", summary: "Minutes for the last meeting and agenda for upcoming AGM.",          status: "Read" },
  { id: "MSG-004", date: "Oct 08, 2026", recipient: "Paul Kiprotich",      type: "SMS",   summary: "Mercy was absent today. Kindly confirm if she is well.",             status: "Failed" },
  { id: "MSG-005", date: "Oct 08, 2026", recipient: "All Parents",         type: "App",   summary: "Mid-term break starts on 15th. Check calendar for details.",         status: "Scheduled" },
];

const typeConfig: Record<string, { bg: string, text: string, border: string, icon: React.ElementType }> = {
  "SMS":   { bg: "bg-emerald-50", text: "text-emerald-700", border: "border-emerald-200", icon: Smartphone },
  "Email": { bg: "bg-blue-50",    text: "text-blue-700",    border: "border-blue-200",    icon: Mail },
  "App":   { bg: "bg-indigo-50",  text: "text-indigo-700",  border: "border-indigo-200",  icon: MessageSquare },
};

export default function CommunicationPage() {
  const [search, setSearch] = useState("");

  const filtered = MESSAGES.filter(m => 
    m.recipient.toLowerCase().includes(search.toLowerCase()) || 
    m.summary.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Messages Sent",   value: "1,245", icon: Send,         color: "from-primary-600 to-primary-800" },
          { label: "Delivery Rate",   value: "98%",   icon: CheckCircle2, color: "from-emerald-500 to-teal-600" },
          { label: "Scheduled",       value: "12",    icon: Clock,        color: "from-amber-500 to-orange-500" },
          { label: "Email Campaigns", value: "3",     icon: Mail,         color: "from-blue-500 to-indigo-600" },
        ].map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className={`bg-gradient-to-br ${c.color} rounded-2xl p-4 text-white shadow-md flex items-center gap-3 relative overflow-hidden group`}>
              <div className="absolute top-0 right-0 -mt-2 -mr-2 w-16 h-16 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700"></div>
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0 relative z-10">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div className="relative z-10">
                <p className="text-2xl font-black leading-tight">{c.value}</p>
                <p className="text-xs font-bold text-white/80">{c.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main card */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden flex flex-col min-h-[500px]">

        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search recipients or content..."
              className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-64 placeholder:text-slate-400"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm transition-colors">
              <MessageSquare className="w-4 h-4" /> Templates
            </button>
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm transition-colors">
              <Filter className="w-4 h-4" /> Filter
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all">
              <Plus className="w-4 h-4" /> New Message
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-primary-900 to-primary-800 text-white">
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Date</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Recipient</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Type</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Message Summary</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Status</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((row) => {
                const typeCfg = typeConfig[row.type] || { bg: "bg-slate-50", text: "text-slate-700", border: "border-slate-200", icon: Mail };
                const Icon = typeCfg.icon;

                return (
                  <tr key={row.id} className="hover:bg-primary-50/40 border-l-4 border-transparent hover:border-l-secondary-500 transition-all group">
                    <td className="px-5 py-4">
                      <div className="font-bold text-slate-800">{row.date}</div>
                      <div className="text-[10px] font-black text-primary-700 bg-primary-50 px-1.5 py-0.5 rounded mt-0.5 w-fit">{row.id}</div>
                    </td>
                    <td className="px-5 py-4 font-bold text-slate-700">{row.recipient}</td>
                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold border ${typeCfg.bg} ${typeCfg.text} ${typeCfg.border}`}>
                        <Icon className="w-3 h-3" /> {row.type}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-slate-500 font-medium max-w-xs truncate">
                      {row.summary}
                    </td>
                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider border ${
                        row.status === 'Sent' || row.status === 'Delivered' || row.status === 'Read' 
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : row.status === 'Failed'
                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                            : 'bg-amber-50 text-amber-700 border-amber-200'
                      }`}>
                        {row.status}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          
          {filtered.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-slate-400">
              <Sparkles className="w-12 h-12 mb-3 opacity-20" />
              <p className="font-bold text-lg text-slate-500">No messages found</p>
            </div>
          )}
        </div>

        {/* Pagination */}
        <div className="px-5 py-3.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/60 mt-auto">
          <span className="font-bold">Showing <span className="text-primary-900">{filtered.length}</span> messages</span>
          <div className="flex items-center gap-1">
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg font-bold disabled:opacity-40" disabled>
              <ChevronLeft className="w-3.5 h-3.5" /> Prev
            </button>
            <button className="w-8 h-8 flex items-center justify-center rounded-lg bg-primary-900 text-white text-xs font-black">1</button>
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg font-bold">
              Next <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}