"use client";

import React, { useState } from "react";
import { Filter, Search, MoreHorizontal, Plus, ShieldAlert } from "lucide-react";

export default function DisciplineCases() {
  const [searchTerm, setSearchTerm] = useState("");

  const cases = [
    { id: "INC-2026-00182", type: "Bullying", student: "Brian Mwangi", grade: "Grade 10", status: "Investigation", severity: "High", date: "Oct 12, 2026", reporter: "Mr. Omondi" },
    { id: "INC-2026-00181", type: "Late Arrival", student: "Peter Otieno", grade: "Grade 8", status: "Parent Communication", severity: "Low", date: "Oct 11, 2026", reporter: "System" },
    { id: "INC-2026-00180", type: "Academic Misconduct", student: "John Kamau", grade: "Grade 11", status: "Resolved", severity: "Medium", date: "Oct 10, 2026", reporter: "Mrs. Kariuki" },
    { id: "INC-2026-00179", type: "Vandalism", student: "Samuel Njoroge", grade: "Grade 9", status: "Open", severity: "High", date: "Oct 09, 2026", reporter: "Security" },
    { id: "INC-2026-00178", type: "Disruption", student: "Alice Wambui", grade: "Grade 7", status: "Resolved", severity: "Low", date: "Oct 08, 2026", reporter: "Mr. Kiprono" },
  ];

  return (
    <div className="p-8 space-y-6 bg-white/30 backdrop-blur-md rounded-3xl min-h-[600px]">
      
      {/* Header & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white/60 p-4 rounded-2xl border border-white/60 shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-slate-800">Case Management</h2>
            <p className="text-xs font-bold text-slate-500">Track and resolve discipline incidents</p>
          </div>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-sm">
          <Plus className="w-4 h-4" /> New Case
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4 bg-white/40 p-4 rounded-2xl border border-white/60 shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search student or case ID..." 
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <select className="bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20">
            <option>All Statuses</option>
            <option>Open</option>
            <option>Investigation</option>
            <option>Resolved</option>
          </select>
          <select className="bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20">
            <option>All Severities</option>
            <option>High</option>
            <option>Medium</option>
            <option>Low</option>
          </select>
        </div>
      </div>

      {/* Cases List */}
      <div className="bg-white/80 border border-slate-200/60 rounded-3xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-200/60">
                <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider">Case ID / Date</th>
                <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider">Student</th>
                <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider">Incident Type</th>
                <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider">Severity</th>
                <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider">Status</th>
                <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100/80">
              {cases.map((c, i) => (
                <tr key={i} className="hover:bg-slate-50/50 transition-colors group cursor-pointer">
                  <td className="p-4">
                    <div className="text-sm font-bold text-slate-700 group-hover:text-indigo-600 transition-colors">{c.id}</div>
                    <div className="text-xs text-slate-500 font-medium">{c.date}</div>
                  </td>
                  <td className="p-4">
                    <div className="text-sm font-bold text-slate-700">{c.student}</div>
                    <div className="text-xs text-slate-500 font-medium">{c.grade}</div>
                  </td>
                  <td className="p-4">
                    <div className="text-sm font-medium text-slate-700">{c.type}</div>
                    <div className="text-[10px] text-slate-400 font-bold uppercase mt-0.5">By {c.reporter}</div>
                  </td>
                  <td className="p-4">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] font-black uppercase tracking-wider border ${
                      c.severity === 'High' ? 'bg-rose-50 text-rose-700 border-rose-200 shadow-[0_0_8px_rgba(244,63,94,0.15)]' :
                      c.severity === 'Medium' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                      'bg-slate-100 text-slate-600 border-slate-200'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        c.severity === 'High' ? 'bg-rose-500' :
                        c.severity === 'Medium' ? 'bg-amber-500' :
                        'bg-slate-400'
                      }`}></span>
                      {c.severity}
                    </span>
                  </td>
                  <td className="p-4">
                    <span className={`px-2.5 py-1 text-[10px] font-black uppercase tracking-wider border rounded shadow-sm ${
                      c.status === 'Resolved' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' :
                      c.status === 'Open' ? 'bg-rose-50 text-rose-600 border-rose-200' :
                      'bg-indigo-50 text-indigo-600 border-indigo-100'
                    }`}>
                      {c.status}
                    </span>
                  </td>
                  <td className="p-4 text-right">
                    <button className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
                      <MoreHorizontal className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
