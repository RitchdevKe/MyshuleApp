"use client";

import React from "react";
import { ChevronLeft, ChevronRight, Filter, Calendar as CalendarIcon, User, Plus } from "lucide-react";

export default function CalendarPage() {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  
  // Static mock calendar for August 2024
  // 1st is Thursday.
  const dates = Array.from({ length: 31 }, (_, i) => i + 1);
  const leadingEmptyDays = 3; // Aug 1 is Thu, so Mon, Tue, Wed are empty

  const events = [
    { date: 12, name: "Emily Chen", type: "Sick Leave", color: "bg-red-500" },
    { date: 13, name: "Emily Chen", type: "Sick Leave", color: "bg-red-500" },
    { date: 14, name: "Emily Chen", type: "Sick Leave", color: "bg-red-500" },
    { date: 20, name: "John Smith", type: "Annual PTO", color: "bg-emerald-500" },
    { date: 21, name: "John Smith", type: "Annual PTO", color: "bg-emerald-500" },
    { date: 22, name: "John Smith", type: "Annual PTO", color: "bg-emerald-500" },
    { date: 23, name: "John Smith", type: "Annual PTO", color: "bg-emerald-500" },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden p-6">
        
        {/* Calendar Header */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
           <div className="flex items-center gap-4">
              <h2 className="text-2xl font-black text-slate-800">August 2024</h2>
              <div className="flex gap-1">
                 <button className="p-2 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors">
                    <ChevronLeft className="w-5 h-5 text-slate-600" />
                 </button>
                 <button className="p-2 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors">
                    <ChevronRight className="w-5 h-5 text-slate-600" />
                 </button>
              </div>
           </div>
           
           <div className="flex gap-2">
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
                 <Filter className="w-4 h-4" />
                 Filter Dept
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
                 <Plus className="w-4 h-4" />
                 Add Event
              </button>
           </div>
        </div>

        {/* Legend */}
        <div className="flex gap-4 mb-6">
           <div className="flex items-center gap-2 text-sm font-bold text-slate-600">
              <div className="w-3 h-3 rounded-full bg-emerald-500"></div> Annual PTO
           </div>
           <div className="flex items-center gap-2 text-sm font-bold text-slate-600">
              <div className="w-3 h-3 rounded-full bg-red-500"></div> Sick Leave
           </div>
           <div className="flex items-center gap-2 text-sm font-bold text-slate-600">
              <div className="w-3 h-3 rounded-full bg-blue-500"></div> Maternity/Paternity
           </div>
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-px bg-slate-200 rounded-2xl overflow-hidden border border-slate-200">
           {days.map((day) => (
              <div key={day} className="bg-slate-50 py-3 text-center text-xs font-bold text-slate-500 uppercase tracking-wider">
                 {day}
              </div>
           ))}
           
           {Array.from({ length: leadingEmptyDays }).map((_, i) => (
              <div key={`empty-${i}`} className="bg-white min-h-[120px] p-2 opacity-50"></div>
           ))}
           
           {dates.map((date) => {
              const dayEvents = events.filter(e => e.date === date);
              return (
                 <div key={date} className="bg-white min-h-[120px] p-2 border-t border-slate-100 hover:bg-slate-50 transition-colors group">
                    <span className={`text-sm font-bold ${date === 12 ? 'bg-primary-900 text-white w-7 h-7 flex items-center justify-center rounded-full' : 'text-slate-700'}`}>
                       {date}
                    </span>
                    <div className="mt-2 space-y-1">
                       {dayEvents.map((event, idx) => (
                          <div key={idx} className={`${event.color} text-white text-[10px] font-bold px-2 py-1 rounded shadow-sm truncate`} title={`${event.name} - ${event.type}`}>
                             {event.name}
                          </div>
                       ))}
                    </div>
                 </div>
              );
           })}
           
           {/* Trailing empty days to fill the grid (Aug has 31 days + 3 leading = 34 cells. 35 cells total = 1 trailing) */}
           <div className="bg-white min-h-[120px] p-2 opacity-50"></div>
        </div>
      </div>
    </div>
  );
}
