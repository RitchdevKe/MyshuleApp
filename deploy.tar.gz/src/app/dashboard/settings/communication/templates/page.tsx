"use client";

import React, { useState, useEffect } from "react";
import { LayoutTemplate, Plus, Search, Filter, Mail, MessageSquare, MoreVertical, Edit2, X, AlertCircle } from "lucide-react";

type TemplateType = "Email" | "SMS" | "In-App";

interface Template {
  name: string;
  type: TemplateType;
  description: string;
  lastUpdated: string;
  status: "Active" | "Draft";
  subject?: string;
  body?: string;
}

const INITIAL_TEMPLATES: Template[] = [
  { name: "Welcome Email", type: "Email", description: "Sent to new parents upon enrollment", lastUpdated: "2 days ago", status: "Active", subject: "Welcome to Kepler!", body: "Dear Parent, welcome to our school..." },
  { name: "Fee Reminder", type: "Email", description: "Automated reminder 7 days before due date", lastUpdated: "1 week ago", status: "Active", subject: "Fee Reminder", body: "Please note that fees are due next week." },
  { name: "Absentee Alert", type: "SMS", description: "Immediate alert to guardian when student is marked absent", lastUpdated: "3 weeks ago", status: "Active", body: "Dear Parent, your child was marked absent today." },
  { name: "Event Notification", type: "Email", description: "General template for school events (Sports day, PTA)", lastUpdated: "1 month ago", status: "Active", subject: "Upcoming School Event", body: "Join us for our upcoming event!" },
  { name: "Emergency Broadcast", type: "SMS", description: "High priority alert for school closures or emergencies", lastUpdated: "2 months ago", status: "Active", body: "URGENT: School will be closed tomorrow due to weather." },
  { name: "Exam Results", type: "Email", description: "Termly exam result notification and link to portal", lastUpdated: "3 months ago", status: "Draft", subject: "Term Results Published", body: "Your child's results are now available on the portal." },
];

export default function TemplatesPage() {
  const [activeTab, setActiveTab] = useState("all");
  const [templates, setTemplates] = useState<Template[]>(INITIAL_TEMPLATES);
  
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [form, setForm] = useState<Template>({ name: "", type: "SMS", description: "", lastUpdated: "Just now", status: "Draft", body: "" });

  const filteredTemplates = activeTab === "all" ? templates : templates.filter(t => t.type.toLowerCase() === activeTab);

  const openNew = () => {
    setForm({ name: "", type: "SMS", description: "", lastUpdated: "Just now", status: "Draft", body: "" });
    setEditingIndex(null);
    setIsEditing(true);
  };

  const openEdit = (idx: number) => {
    setForm({ ...templates[idx] });
    setEditingIndex(idx);
    setIsEditing(true);
  };

  const closeEdit = () => {
    setIsEditing(false);
  };

  const handleSave = () => {
    const updatedForm = { ...form, lastUpdated: "Just now" };
    if (editingIndex !== null) {
      const newTemplates = [...templates];
      newTemplates[editingIndex] = updatedForm;
      setTemplates(newTemplates);
    } else {
      setTemplates([updatedForm, ...templates]);
    }
    closeEdit();
  };

  const isUnicode = (text: string) => {
    for (let i = 0; i < text.length; i++) {
      if (text.charCodeAt(i) > 127) return true;
    }
    return false;
  };

  const getSmsLimit = (text: string) => {
    return isUnicode(text) ? 70 : 160;
  };
  
  const getSmsParts = (text: string) => {
    if (!text) return 1;
    const limit = getSmsLimit(text);
    // Standard multipart limit logic for GSM is 153, Unicode is 67. We'll simplify per prompt to standard limits.
    const partLimit = isUnicode(text) ? 67 : 153;
    if (text.length <= limit) return 1;
    return Math.ceil(text.length / partLimit);
  };

  const charCount = form.body?.length || 0;
  const currentLimit = getSmsLimit(form.body || "");
  const smsParts = getSmsParts(form.body || "");
  const charDisplayLimit = smsParts > 1 ? (isUnicode(form.body || "") ? 67 * smsParts : 153 * smsParts) : currentLimit;
  
  const isAmber = charCount >= 130;
  const isRed = charCount >= currentLimit && smsParts > 1; // It goes to multipart

  return (
    <div className="p-6 md:p-8 max-w-5xl relative">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center">
            <LayoutTemplate className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-black text-slate-800">Message Templates</h3>
            <p className="text-sm font-medium text-slate-500">Design and manage predefined templates for Email and SMS.</p>
          </div>
        </div>
        <button onClick={openNew} className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-slate-800 rounded-xl hover:bg-slate-700 transition-colors shadow-sm">
          <Plus className="w-4 h-4" /> New Template
        </button>
      </div>

      {/* Toolbar & Filters */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
         <div className="flex space-x-1 bg-slate-100/50 p-1 rounded-xl border border-slate-200">
            {['all', 'email', 'sms'].map((tab) => (
               <button 
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-1.5 text-xs font-bold rounded-lg capitalize transition-colors ${
                     activeTab === tab 
                        ? 'bg-white text-violet-700 shadow-sm border border-slate-200/50' 
                        : 'text-slate-500 hover:text-slate-700'
                  }`}
               >
                  {tab}
               </button>
            ))}
         </div>
         
         <div className="flex items-center gap-3 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
               <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
               <input 
                  type="text" 
                  placeholder="Search templates..." 
                  className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-sm font-medium text-slate-800 focus:outline-none focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 transition-all shadow-sm"
               />
            </div>
            <button className="flex items-center gap-2 px-3 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl font-bold text-sm hover:bg-slate-50 transition-colors shadow-sm">
               <Filter className="w-4 h-4" /> Filter
            </button>
         </div>
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
         {filteredTemplates.map((template, idx) => {
            const isEmail = template.type === "Email";
            const realIndex = templates.findIndex(t => t === template);
            return (
               <div key={idx} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm hover:border-slate-300 transition-colors group flex flex-col justify-between h-full">
                  <div>
                     <div className="flex justify-between items-start mb-3">
                        <div className="flex items-center gap-3">
                           <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isEmail ? 'bg-sky-50 text-sky-600' : 'bg-emerald-50 text-emerald-600'}`}>
                              {isEmail ? <Mail className="w-4 h-4" /> : <MessageSquare className="w-4 h-4" />}
                           </div>
                           <h4 className="font-black text-slate-800 text-base group-hover:text-violet-700 transition-colors">{template.name}</h4>
                        </div>
                        <button className="text-slate-400 hover:text-slate-700 transition-colors">
                           <MoreVertical className="w-4 h-4" />
                        </button>
                     </div>
                     <p className="text-sm text-slate-500 font-medium mb-4 line-clamp-2">
                        {template.description}
                     </p>
                  </div>
                  
                  <div className="flex justify-between items-center pt-4 border-t border-slate-100">
                     <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400">
                        Updated {template.lastUpdated}
                     </span>
                     <div className="flex items-center gap-2">
                        {template.status === "Draft" ? (
                           <span className="text-[10px] font-black uppercase tracking-wider text-amber-600 bg-amber-50 px-2 py-1 rounded-md">Draft</span>
                        ) : (
                           <span className="text-[10px] font-black uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md">Active</span>
                        )}
                        <button onClick={() => openEdit(realIndex)} className="text-slate-400 hover:text-violet-600 transition-colors">
                           <Edit2 className="w-4 h-4" />
                        </button>
                     </div>
                  </div>
               </div>
            );
         })}
      </div>
      
      {filteredTemplates.length === 0 && (
         <div className="text-center py-12 bg-slate-50 rounded-2xl border border-slate-200">
            <LayoutTemplate className="w-8 h-8 text-slate-300 mx-auto mb-3" />
            <h4 className="text-sm font-black text-slate-600">No templates found</h4>
            <p className="text-xs text-slate-500 mt-1">Try adjusting your filters or create a new template.</p>
         </div>
      )}

      {/* Slide-in Edit Drawer */}
      {isEditing && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-slate-900/30 backdrop-blur-sm" onClick={closeEdit}></div>
          <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col border-l border-slate-200 animate-in slide-in-from-right duration-300">
            
            <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-white">
              <h3 className="text-lg font-black text-slate-800">
                {editingIndex !== null ? "Edit Template" : "New Template"}
              </h3>
              <button onClick={closeEdit} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-5 bg-slate-50/50">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase tracking-wider">Template Name</label>
                <input 
                  type="text" 
                  value={form.name}
                  onChange={(e) => setForm({...form, name: e.target.value})}
                  className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-800 focus:outline-none focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 transition-all shadow-sm"
                  placeholder="e.g. Exam Results Alert"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase tracking-wider">Type</label>
                <div className="flex bg-slate-100 p-1 rounded-xl">
                  {["Email", "SMS", "In-App"].map(type => (
                    <button
                      key={type}
                      onClick={() => setForm({...form, type: type as TemplateType})}
                      className={`flex-1 py-2 text-sm font-bold rounded-lg transition-colors ${form.type === type ? "bg-white text-violet-700 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase tracking-wider">Description</label>
                <input 
                  type="text" 
                  value={form.description}
                  onChange={(e) => setForm({...form, description: e.target.value})}
                  className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-800 focus:outline-none focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 transition-all shadow-sm"
                  placeholder="What is this used for?"
                />
              </div>

              {form.type === "Email" && (
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase tracking-wider">Subject Line</label>
                  <input 
                    type="text" 
                    value={form.subject || ""}
                    onChange={(e) => setForm({...form, subject: e.target.value})}
                    className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-800 focus:outline-none focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 transition-all shadow-sm"
                    placeholder="Email subject..."
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase tracking-wider">Message Body</label>
                <textarea 
                  value={form.body || ""}
                  onChange={(e) => setForm({...form, body: e.target.value})}
                  rows={6}
                  className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-medium text-slate-800 focus:outline-none focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 transition-all shadow-sm resize-none"
                  placeholder="Type your message here..."
                />
                
                {form.type === "SMS" && (
                  <div className="mt-3 p-4 bg-white border border-slate-200 rounded-xl shadow-sm">
                    <div className="flex justify-between items-end mb-2">
                      <div>
                        <span className="text-xs font-black text-slate-400 uppercase tracking-wider">Character Count</span>
                        <div className={`text-2xl font-black ${isRed ? 'text-rose-500' : isAmber ? 'text-amber-500' : 'text-slate-700'}`}>
                          {charCount} <span className="text-sm font-bold text-slate-400">/ {charDisplayLimit}</span>
                        </div>
                      </div>
                      <div className="px-2.5 py-1 bg-slate-100 text-slate-600 text-xs font-bold rounded-lg border border-slate-200">
                        {smsParts} SMS {smsParts > 1 ? 'Parts' : 'Part'}
                      </div>
                    </div>
                    
                    <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden mb-3">
                      <div 
                        className={`h-full rounded-full transition-all duration-300 ${isRed ? 'bg-rose-500' : isAmber ? 'bg-amber-500' : 'bg-violet-500'}`}
                        style={{ width: `${Math.min((charCount / charDisplayLimit) * 100, 100)}%` }}
                      />
                    </div>
                    
                    <p className="text-[10px] text-slate-500 flex items-start gap-1.5 leading-tight font-medium">
                      <AlertCircle className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />
                      Unicode characters (e.g. emoji) reduce limit to 70 per SMS.
                    </p>
                  </div>
                )}
              </div>

            </div>

            <div className="p-6 bg-white border-t border-slate-100 flex gap-3">
              <button 
                onClick={closeEdit}
                className="flex-1 py-2.5 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleSave}
                className="flex-1 py-2.5 text-sm font-bold text-white bg-violet-600 rounded-xl hover:bg-violet-700 transition-colors shadow-sm shadow-violet-600/20"
              >
                Save Template
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
