"use client";

import React from "react";
import { ShieldAlert, Lock, ShieldCheck, CheckCircle2 } from "lucide-react";

export default function ControlsPage() {
  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <div className="flex items-center gap-3 mb-8">
         <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
            <ShieldAlert className="w-5 h-5" />
         </div>
         <div>
            <h3 className="text-xl font-black text-slate-800">Financial Controls</h3>
            <p className="text-sm font-medium text-slate-500">Manage approval workflows, expense limits, and accounting period locks.</p>
         </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Approval Thresholds */}
        <div>
          <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">Approval Thresholds (Expenses)</h4>
          
          <div className="space-y-4">
            
            <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm hover:border-slate-300 transition-colors">
              <div className="flex justify-between items-start mb-4">
                  <div>
                     <span className="font-black text-slate-800 text-lg">≤ KSh 10,000</span>
                     <p className="text-xs text-slate-500 font-medium mt-0.5">Petty cash and minor expenses</p>
                  </div>
                  <span className="bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-md flex items-center gap-1">
                     <CheckCircle2 className="w-3 h-3" /> Auto-Approve
                  </span>
              </div>
              <input type="range" className="w-full accent-emerald-500" min="0" max="50000" defaultValue="10000" />
            </div>
            
            <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm hover:border-slate-300 transition-colors">
              <div className="flex justify-between items-start mb-2">
                  <div>
                     <span className="font-black text-slate-800 text-lg">KSh 10,001 — KSh 100,000</span>
                     <p className="text-xs text-slate-500 font-medium mt-0.5">Standard operational expenses</p>
                  </div>
                  <span className="bg-sky-100 text-sky-700 text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-md flex items-center gap-1">
                     <ShieldCheck className="w-3 h-3" /> Requires Bursar
                  </span>
              </div>
            </div>

            <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm hover:border-slate-300 transition-colors">
              <div className="flex justify-between items-start mb-2">
                  <div>
                     <span className="font-black text-rose-700 text-lg">&gt; KSh 100,000</span>
                     <p className="text-xs text-slate-500 font-medium mt-0.5">Major capital expenditures</p>
                  </div>
                  <span className="bg-rose-100 text-rose-700 text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-md flex items-center gap-1">
                     <ShieldAlert className="w-3 h-3" /> Requires Director
                  </span>
              </div>
            </div>

          </div>
        </div>

        {/* Period Locking */}
        <div>
          <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">Period Locking</h4>
          <p className="text-sm text-slate-500 font-medium mb-6">Locking a period prevents any new transactions or modifications to existing transactions within that month, securing historical financial records.</p>
          
          <div className="space-y-3">
            
            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200/60 opacity-80">
              <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center">
                     <Lock className="w-4 h-4 text-slate-500" />
                  </div>
                  <div>
                     <span className="font-black text-slate-700 block">January 2026</span>
                     <span className="text-xs text-slate-500 font-medium">Reconciled</span>
                  </div>
              </div>
              <span className="text-[10px] font-black uppercase tracking-wider text-rose-600 bg-rose-50 border border-rose-100 px-3 py-1.5 rounded-lg">
                Locked
              </span>
            </div>

            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200/60 opacity-80">
              <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center">
                     <Lock className="w-4 h-4 text-slate-500" />
                  </div>
                  <div>
                     <span className="font-black text-slate-700 block">February 2026</span>
                     <span className="text-xs text-slate-500 font-medium">Reconciled</span>
                  </div>
              </div>
              <span className="text-[10px] font-black uppercase tracking-wider text-rose-600 bg-rose-50 border border-rose-100 px-3 py-1.5 rounded-lg">
                Locked
              </span>
            </div>

            <div className="flex items-center justify-between p-4 bg-white border border-emerald-200 shadow-sm shadow-emerald-500/10 rounded-2xl group hover:border-emerald-300 transition-all">
              <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full border-4 border-emerald-100 flex items-center justify-center relative">
                    <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></div>
                  </div>
                  <div>
                     <span className="font-black text-slate-800 block">March 2026</span>
                     <span className="text-xs text-emerald-600 font-bold uppercase tracking-wider">Current Period</span>
                  </div>
              </div>
              <button className="text-[10px] font-black uppercase tracking-wider text-emerald-700 bg-emerald-50 hover:bg-emerald-100 hover:text-emerald-800 px-4 py-2 rounded-xl transition-colors border border-emerald-200">
                Lock Period
              </button>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
}
