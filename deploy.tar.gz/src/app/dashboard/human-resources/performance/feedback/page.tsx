"use client";

import React from "react";
import { MessageCircle, Heart, Lightbulb, Users, Plus, Star, Filter } from "lucide-react";

export default function FeedbackPage() {
  const feedbacks = [
    { id: "FB-1", recipient: "Jane Doe", sender: "Alice Wanjiku", type: "Leadership", date: "2 days ago", content: "Jane showed exceptional leadership during the science fair preparations, coordinating seamlessly across three different departments.", icon: Star, color: "text-amber-600", bg: "bg-amber-50" },
    { id: "FB-2", recipient: "Sarah Connor", sender: "Robert Kiprono", type: "Teamwork", date: "1 week ago", content: "Thanks for stepping in to cover my classes while I was out sick. Your lesson plans were incredibly detailed and helpful!", icon: Users, color: "text-blue-600", bg: "bg-blue-50" },
    { id: "FB-3", recipient: "John Smith", sender: "David Mwangi", type: "Innovation", date: "2 weeks ago", content: "The new automated reporting script you built for the maintenance logs has saved us hours of manual data entry. Brilliant work.", icon: Lightbulb, color: "text-emerald-600", bg: "bg-emerald-50" },
    { id: "FB-4", recipient: "Michael Ochieng", sender: "Jane Doe", type: "Core Values", date: "3 weeks ago", content: "Always bringing a positive attitude to the morning briefings. It really sets the tone for the entire staff.", icon: Heart, color: "text-rose-600", bg: "bg-rose-50" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div>
           <h2 className="text-lg font-black text-slate-800">Continuous Feedback</h2>
           <p className="text-sm font-medium text-slate-500">Peer-to-peer recognition and 360-degree feedback log.</p>
        </div>
        <div className="flex gap-2">
           <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
              <Filter className="w-4 h-4" />
              Filter
           </button>
           <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
              <Plus className="w-4 h-4" />
              Give Feedback
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
         {feedbacks.map((fb) => {
            const Icon = fb.icon;
            return (
               <div key={fb.id} className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-6 hover:shadow-lg transition-all duration-300 flex gap-4">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${fb.bg} ${fb.color}`}>
                     <Icon className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                     <div className="flex justify-between items-start mb-1">
                        <div>
                           <p className="text-sm font-bold text-slate-800">To: {fb.recipient}</p>
                           <p className="text-xs font-medium text-slate-500">From: {fb.sender}</p>
                        </div>
                        <span className="text-xs font-bold text-slate-400">{fb.date}</span>
                     </div>
                     <div className="mt-3 mb-3">
                        <span className={`inline-block px-2.5 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg mb-2 ${fb.bg} ${fb.color}`}>
                           {fb.type}
                        </span>
                        <p className="text-sm text-slate-600 leading-relaxed font-medium">"{fb.content}"</p>
                     </div>
                     <div className="flex items-center gap-3 pt-3 border-t border-slate-100">
                        <button className="flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-rose-500 transition-colors">
                           <Heart className="w-4 h-4" />
                           Like
                        </button>
                        <button className="flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-primary-600 transition-colors">
                           <MessageCircle className="w-4 h-4" />
                           Comment
                        </button>
                     </div>
                  </div>
               </div>
            );
         })}
      </div>
    </div>
  );
}
