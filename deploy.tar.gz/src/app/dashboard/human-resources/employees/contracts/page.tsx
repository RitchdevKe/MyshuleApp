"use client";

import React from "react";
import { FileSignature, Plus, Search, Filter, AlertCircle, CheckCircle2, Clock } from "lucide-react";

export default function ContractsPage() {
  const contracts = [
    { id: "CNT-2024-001", employee: "Jane Doe", role: "Senior Mathematics Teacher", type: "Permanent", startDate: "01 Aug 2020", endDate: "N/A", status: "Active" },
    { id: "CNT-2024-042", employee: "Michael Ochieng", role: "IT Support Technician", type: "Fixed-Term (1 Yr)", startDate: "01 Jun 2023", endDate: "31 May 2024", status: "Expiring Soon" },
    { id: "CNT-2023-112", employee: "David Kim", role: "Bus Driver", type: "Fixed-Term (6 Mo)", startDate: "01 Feb 2024", endDate: "31 Jul 2024", status: "Active" },
    { id: "CNT-2022-089", employee: "Emily Chen", role: "School Nurse", type: "Part-Time", startDate: "01 Mar 2022", endDate: "N/A", status: "Active" },
    { id: "CNT-2023-005", employee: "Sarah Connor", role: "Head of Sciences", type: "Permanent", startDate: "01 Sep 2018", endDate: "N/A", status: "Active" },
    { id: "CNT-2023-099", employee: "John Smith", role: "Maintenance Supervisor", type: "Contractor", startDate: "01 Jan 2023", endDate: "31 Dec 2023", status: "Expired" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
             <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Contracts</p>
            <p className="text-2xl font-black text-slate-800">128</p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl">
             <Clock className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Expiring in 30 Days</p>
            <p className="text-2xl font-black text-slate-800">14</p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-red-50 text-red-600 rounded-2xl">
             <AlertCircle className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Expired</p>
            <p className="text-2xl font-black text-slate-800">3</p>
          </div>
        </div>
      </div>

      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4">
           <div className="flex items-center gap-2 w-full md:w-auto relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input type="text" placeholder="Search contracts..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-slate-50 border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
           </div>
           <div className="flex gap-2">
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
                 <Filter className="w-4 h-4" />
                 Status Filter
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
                 <Plus className="w-4 h-4" />
                 Generate Contract
              </button>
           </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Contract ID</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Employee</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Type</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Duration</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {contracts.map((contract) => (
                <tr key={contract.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="py-4 px-6">
                    <span className="font-bold text-slate-700 text-sm">{contract.id}</span>
                  </td>
                  <td className="py-4 px-6">
                    <p className="font-bold text-slate-800 text-sm">{contract.employee}</p>
                    <p className="text-xs text-slate-500 font-medium">{contract.role}</p>
                  </td>
                  <td className="py-4 px-6">
                    <span className="px-3 py-1 bg-slate-100 text-slate-600 text-xs font-bold rounded-lg">{contract.type}</span>
                  </td>
                  <td className="py-4 px-6">
                    <p className="text-sm text-slate-600 font-medium">{contract.startDate}</p>
                    <p className="text-xs text-slate-400">to {contract.endDate}</p>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-lg ${
                      contract.status === 'Active' ? 'bg-emerald-50 text-emerald-600' : 
                      contract.status === 'Expiring Soon' ? 'bg-amber-50 text-amber-600' : 
                      'bg-red-50 text-red-600'
                    }`}>
                      {contract.status === 'Active' && <CheckCircle2 className="w-3.5 h-3.5" />}
                      {contract.status === 'Expiring Soon' && <Clock className="w-3.5 h-3.5" />}
                      {contract.status === 'Expired' && <AlertCircle className="w-3.5 h-3.5" />}
                      {contract.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <button className="text-sm font-bold text-primary-600 hover:text-primary-800 hover:underline mr-4">View</button>
                    {contract.status !== 'Active' && (
                      <button className="text-sm font-bold text-white bg-primary-900 hover:bg-primary-800 px-3 py-1.5 rounded-lg transition-colors">Renew</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
