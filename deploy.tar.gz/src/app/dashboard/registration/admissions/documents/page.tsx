"use client";

import React, { useState } from "react";
import {
  Search, Plus, MoreHorizontal, CheckCircle2, Clock,
  XCircle, Eye, Download, Upload, FileText, FileBadge,
  FileCheck, ChevronLeft, ChevronRight, AlertTriangle
} from "lucide-react";

const DOCUMENTS = [
  { id: "DOC-001", student: "Samuel Njenga",   adm: "ADM-1201", docType: "Birth Certificate",      uploaded: "Oct 12, 2026", verifiedBy: "Admin",      status: "Verified",  size: "1.2 MB", initials: "SN" },
  { id: "DOC-002", student: "Mercy Kiprotich", adm: "ADM-1200", docType: "KCPE Results Slip",       uploaded: "Oct 13, 2026", verifiedBy: "—",          status: "Pending",   size: "0.8 MB", initials: "MK" },
  { id: "DOC-003", student: "Liam Omondi",     adm: "ADM-1199", docType: "Medical Certificate",     uploaded: "Oct 14, 2026", verifiedBy: "—",          status: "Pending",   size: "2.1 MB", initials: "LO" },
  { id: "DOC-004", student: "Fatuma Ali",       adm: "ADM-1198", docType: "Parent ID (Copy)",        uploaded: "Oct 10, 2026", verifiedBy: "Registrar",  status: "Verified",  size: "0.5 MB", initials: "FA" },
  { id: "DOC-005", student: "Brian Mutua",      adm: "ADM-1197", docType: "Transfer Certificate",    uploaded: "Oct 08, 2026", verifiedBy: "—",          status: "Rejected",  size: "1.7 MB", initials: "BM" },
  { id: "DOC-006", student: "Chacha Wekesa",   adm: "ADM-1196", docType: "Immunization Card",       uploaded: "Oct 13, 2026", verifiedBy: "Nurse",      status: "Verified",  size: "0.3 MB", initials: "CW" },
  { id: "DOC-007", student: "Amina Hassan",    adm: "ADM-1195", docType: "NHIF Card (Parent)",      uploaded: "Oct 11, 2026", verifiedBy: "—",          status: "Pending",   size: "0.6 MB", initials: "AH" },
  { id: "DOC-008", student: "John Doe",         adm: "ADM-1194", docType: "School Leaving Cert",    uploaded: "Oct 14, 2026", verifiedBy: "Registrar",  status: "Verified",  size: "1.1 MB", initials: "JD" },
];

const DOC_ICONS: Record<string, React.ElementType> = {
  "Birth Certificate":    FileBadge,
  "KCPE Results Slip":   FileCheck,
  "Medical Certificate":  FileText,
  "Parent ID (Copy)":    FileText,
  "Transfer Certificate": FileCheck,
  "Immunization Card":   FileBadge,
  "NHIF Card (Parent)":  FileText,
  "School Leaving Cert": FileCheck,
};

const statusConfig = {
  Verified: { pill: "bg-emerald-100 text-emerald-700 border border-emerald-200", icon: CheckCircle2 },
  Pending:  { pill: "bg-amber-100 text-amber-700 border border-amber-200",       icon: Clock },
  Rejected: { pill: "bg-rose-100 text-rose-700 border border-rose-200",          icon: XCircle },
};

const avatarGrads = [
  "from-primary-700 to-primary-900",
  "from-secondary-500 to-secondary-700",
  "from-indigo-500 to-violet-600",
  "from-emerald-500 to-teal-600",
  "from-amber-500 to-orange-600",
  "from-sky-500 to-blue-600",
];

const FILTERS = ["All", "Verified", "Pending", "Rejected"];

export default function DocumentsPage() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");

  const filtered = DOCUMENTS.filter(d => {
    const matchSearch = !search || d.student.toLowerCase().includes(search.toLowerCase()) || d.docType.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === "All" || d.status === filter;
    return matchSearch && matchFilter;
  });

  const counts = {
    Verified: DOCUMENTS.filter(d => d.status === "Verified").length,
    Pending:  DOCUMENTS.filter(d => d.status === "Pending").length,
    Rejected: DOCUMENTS.filter(d => d.status === "Rejected").length,
  };

  return (
    <div className="space-y-4">

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Verified Documents", value: counts.Verified, icon: CheckCircle2, color: "from-emerald-600 to-teal-600" },
          { label: "Pending Verification", value: counts.Pending, icon: AlertTriangle, color: "from-amber-500 to-orange-500" },
          { label: "Rejected / Resubmit", value: counts.Rejected, icon: XCircle, color: "from-rose-600 to-red-600" },
        ].map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className={`bg-gradient-to-br ${c.color} rounded-2xl p-4 text-white shadow-md flex items-center gap-3`}>
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-black">{c.value}</p>
                <p className="text-xs font-bold text-white/80">{c.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Upload drop-zone */}
      <div className="border-2 border-dashed border-primary-200 bg-primary-50/50 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary-900 rounded-xl flex items-center justify-center shadow-md">
            <Upload className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="font-black text-primary-900 text-sm">Upload Documents</p>
            <p className="text-xs text-primary-600 font-medium">Drag & drop files here, or click to browse (PDF, JPG, PNG — max 5MB)</p>
          </div>
        </div>
        <div className="flex gap-2 flex-shrink-0">
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all">
            <Upload className="w-4 h-4" /> Upload
          </button>
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-primary-700 bg-white border border-primary-200 rounded-xl hover:bg-primary-50 transition-colors">
            Request Doc
          </button>
        </div>
      </div>

      {/* Table card */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden">

        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search documents..."
                className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-52 placeholder:text-slate-400"
              />
            </div>
            <div className="flex gap-1.5">
              {FILTERS.map(f => (
                <button key={f} onClick={() => setFilter(f)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all ${filter === f ? "bg-primary-900 text-white shadow-md shadow-primary-900/20" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}>
                  {f}
                </button>
              ))}
            </div>
          </div>
          <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm">
            <Download className="w-4 h-4" /> Export
          </button>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-primary-900 to-primary-800 text-white">
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Doc ID</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Student</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Adm No.</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Document Type</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Uploaded</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Size</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Verified By</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Status</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((doc, i) => {
                const cfg = statusConfig[doc.status as keyof typeof statusConfig];
                const StatusIcon = cfg.icon;
                const DocIcon = DOC_ICONS[doc.docType] || FileText;
                return (
                  <tr key={doc.id} className="hover:bg-primary-50/40 border-l-4 border-transparent hover:border-l-secondary-500 transition-all group">
                    <td className="px-5 py-3.5">
                      <span className="text-xs font-black text-primary-900 bg-primary-50 border border-primary-100 px-2 py-1 rounded-lg">{doc.id}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${avatarGrads[i % avatarGrads.length]} flex items-center justify-center text-white text-[10px] font-black shadow-sm flex-shrink-0`}>
                          {doc.initials}
                        </div>
                        <span className="font-bold text-slate-800">{doc.student}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2 py-1 rounded-lg border border-slate-200">{doc.adm}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 bg-primary-50 border border-primary-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <DocIcon className="w-3.5 h-3.5 text-primary-700" />
                        </div>
                        <span className="text-sm font-medium text-slate-700">{doc.docType}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-xs font-bold text-slate-500">{doc.uploaded}</td>
                    <td className="px-5 py-3.5 text-xs font-bold text-slate-400">{doc.size}</td>
                    <td className="px-5 py-3.5 text-xs font-bold text-slate-500">{doc.verifiedBy}</td>
                    <td className="px-5 py-3.5">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-black ${cfg.pill}`}>
                        <StatusIcon className="w-3 h-3" />{doc.status}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-primary-600 bg-primary-50 hover:bg-primary-100 border border-primary-100 rounded-lg" title="View">
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button className="p-1.5 text-secondary-600 bg-secondary-50 hover:bg-secondary-100 border border-secondary-100 rounded-lg" title="Download">
                          <Download className="w-3.5 h-3.5" />
                        </button>
                        <button className="p-1.5 text-slate-500 hover:bg-slate-100 rounded-lg" title="More">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-5 py-16 text-center">
                    <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                    <p className="font-bold text-slate-500">No documents found</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="px-5 py-3.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/60">
          <span className="font-bold">Showing <span className="text-primary-900">{filtered.length}</span> of {DOCUMENTS.length} documents</span>
          <div className="flex items-center gap-1">
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg hover:bg-slate-50 disabled:opacity-40 font-bold" disabled>
              <ChevronLeft className="w-3.5 h-3.5" /> Prev
            </button>
            <button className="w-8 h-8 flex items-center justify-center rounded-lg bg-primary-900 text-white text-xs font-black">1</button>
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg hover:bg-slate-50 font-bold">
              Next <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}