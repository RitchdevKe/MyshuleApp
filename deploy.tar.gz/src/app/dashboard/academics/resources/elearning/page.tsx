"use client";
import React from "react";
import { Search, Plus, MoreHorizontal, MonitorPlay, ExternalLink, PlayCircle } from "lucide-react";

const mockModules = [
  { id: "EL-001", title: "Interactive Math: Fractions", target: "Grade 4", completions: 85, rating: "4.8", status: "Published" },
  { id: "EL-002", title: "Science Lab Simulation", target: "Grade 5", completions: 42, rating: "4.5", status: "Published" },
  { id: "EL-003", title: "Grammar Basics", target: "Grade 4", completions: 0, rating: "-", status: "Draft" },
  { id: "EL-004", title: "History of Kenya Map Game", target: "Grade 6", completions: 120, rating: "4.9", status: "Published" },
];

export default function ELearningPage() {
  const getStatusStyle = (status: string) => {
    switch (status) {
      case "Published": return "bg-emerald-100/80 text-emerald-700 border-emerald-200";
      case "Draft": return "bg-slate-100/80 text-slate-700 border-slate-200";
      default: return "bg-slate-100/80 text-slate-700 border-slate-200";
    }
  };

  return (
    <div className="bg-white/60 backdrop-blur-xl border border-white/60 rounded-3xl shadow-lg overflow-hidden flex flex-col min-h-[400px]">
      
      {/* Toolbar */}
      <div className="p-5 border-b border-slate-200/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative w-full sm:max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search interactive modules..." 
            className="w-full pl-10 pr-4 py-2.5 text-sm font-bold bg-white/80 border border-slate-200/60 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-900 focus:border-primary-900 transition-shadow"
          />
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-white bg-primary-900 rounded-xl hover:bg-primary-800 transition-colors shadow-sm">
            <Plus className="w-4 h-4" /> Create Module
          </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-x-auto">
        <table className="w-full text-left text-sm text-slate-600">
          <thead className="bg-slate-50/50 text-[10px] uppercase font-black text-slate-500 border-b border-slate-200/60 tracking-wider">
            <tr>
              <th className="px-6 py-4">Module Details</th>
              <th className="px-6 py-4">Target Class</th>
              <th className="px-6 py-4">Completions</th>
              <th className="px-6 py-4">Avg Rating</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200/60">
            {mockModules.map((row, i) => (
              <tr key={i} className="hover:bg-white/80 transition-colors group">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-primary-50 text-primary-900 rounded-lg group-hover:bg-primary-100 transition-colors">
                      <MonitorPlay className="w-4 h-4" />
                    </div>
                    <div className="flex flex-col">
                      <span className="font-bold text-slate-800">{row.title}</span>
                      <span className="text-xs font-bold text-slate-400">{row.id}</span>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 font-bold text-slate-700">{row.target}</td>
                <td className="px-6 py-4 font-black text-slate-800">{row.completions}</td>
                <td className="px-6 py-4 font-bold text-slate-600">⭐ {row.rating}</td>
                <td className="px-6 py-4">
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold border backdrop-blur-sm ${getStatusStyle(row.status)}`}>
                    {row.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-1.5 text-slate-400 hover:text-primary-900 hover:bg-slate-100 rounded-lg transition-colors">
                      <PlayCircle className="w-4 h-4" />
                    </button>
                    <button className="p-1.5 text-slate-400 hover:text-primary-900 hover:bg-slate-100 rounded-lg transition-colors">
                      <MoreHorizontal className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Footer */}
      <div className="p-4 border-t border-slate-200/60 flex items-center justify-between text-sm font-bold text-slate-500 bg-white/40 mt-auto">
        <span>Showing 4 of 24 modules</span>
        <div className="flex gap-2">
          <button className="px-4 py-2 border border-slate-200 bg-white rounded-xl hover:bg-slate-50 disabled:opacity-50 transition-colors shadow-sm" disabled>Prev</button>
          <button className="px-4 py-2 border border-slate-200 bg-white rounded-xl hover:bg-slate-50 transition-colors shadow-sm">Next</button>
        </div>
      </div>
    </div>
  );
}
