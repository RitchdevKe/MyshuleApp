import React from "react";
import { Activity, Search, Filter, Calendar, Users, Target, ArrowRight } from "lucide-react";

export default function LeadershipActivitiesPage() {
  const initiatives = [
    { id: 1, title: "Campus Cleanup Drive", status: "In Progress", leader: "John Kamau", date: "Oct 30, 2025", type: "Community", impact: "High" },
    { id: 2, title: "Peer Tutoring Program", status: "Planning", leader: "Mary Wanjiku", date: "Nov 5, 2025", type: "Academic", impact: "Medium" },
    { id: 3, title: "Mental Health Awareness", status: "Completed", leader: "Jane Doe", date: "Sep 15, 2025", type: "Welfare", impact: "High" },
  ];

  return (
    <div className="p-6">
      
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search initiatives..." 
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-secondary-500/20 focus:border-secondary-500 transition-all shadow-sm"
          />
        </div>
        
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors shadow-sm">
            <Filter className="w-4 h-4" /> Filter
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-white bg-primary-900 rounded-xl hover:bg-primary-800 transition-colors shadow-sm">
            <Activity className="w-4 h-4" /> New Initiative
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {initiatives.map((initiative) => (
          <div key={initiative.id} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-shadow group flex flex-col">
            
            <div className="flex justify-between items-start mb-4">
              <span className={`px-2.5 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg border
                ${initiative.type === 'Community' ? 'bg-blue-50 text-blue-600 border-blue-200' : 
                  initiative.type === 'Academic' ? 'bg-indigo-50 text-indigo-600 border-indigo-200' : 
                  'bg-rose-50 text-rose-600 border-rose-200'}`}>
                {initiative.type}
              </span>

              <span className={`px-2.5 py-1 text-[10px] font-bold rounded-lg border
                ${initiative.status === 'In Progress' ? 'bg-amber-50 text-amber-700 border-amber-200' : 
                  initiative.status === 'Completed' ? 'bg-green-50 text-green-700 border-green-200' : 
                  'bg-slate-100 text-slate-600 border-slate-200'}`}>
                {initiative.status}
              </span>
            </div>

            <h3 className="font-bold text-slate-800 mb-1">{initiative.title}</h3>
            
            <div className="flex items-center gap-2 mb-4">
               <div className="w-5 h-5 rounded-full bg-slate-200 flex items-center justify-center text-[8px] font-bold text-slate-600">
                  {initiative.leader.charAt(0)}
               </div>
               <p className="text-xs font-medium text-slate-500">Led by <span className="font-bold text-slate-700">{initiative.leader}</span></p>
            </div>

            <div className="mt-auto pt-4 border-t border-slate-100 space-y-3">
               <div className="flex items-center justify-between text-xs font-medium text-slate-500">
                  <span className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" /> {initiative.date}</span>
                  <span className="flex items-center gap-1.5"><Target className="w-3.5 h-3.5" /> {initiative.impact} Impact</span>
               </div>
               <button className="w-full flex items-center justify-center gap-2 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 transition-colors">
                 View Details <ArrowRight className="w-3.5 h-3.5" />
               </button>
            </div>
            
          </div>
        ))}
      </div>

    </div>
  );
}
