"use client";

import React, { useState } from "react";
import {
  Search, Plus, MoreHorizontal, Eye, ChevronLeft, ChevronRight,
  TrendingUp, TrendingDown, Minus, GraduationCap, CheckCircle2,
  Clock, AlertTriangle, ArrowRight, BarChart2, Sparkles
} from "lucide-react";

const PROMOTIONS = [
  { id: "STD-2601", name: "John Kamau",     initials: "JK", from: "Grade 3",   to: "Grade 4",   avg: "A",  score: 88, status: "Promoted",  term: "Term 3 2025" },
  { id: "STD-2602", name: "Mary Wanjiku",   initials: "MW", from: "PP2",       to: "Grade 1",   avg: "A-", score: 82, status: "Promoted",  term: "Term 3 2025" },
  { id: "STD-2603", name: "David Ochieng",  initials: "DO", from: "Form 1",    to: "Form 2",    avg: "C+", score: 51, status: "Pending",   term: "Term 3 2025" },
  { id: "STD-2604", name: "Sarah Mutiso",   initials: "SM", from: "Grade 2",   to: "Grade 3",   avg: "A",  score: 94, status: "Promoted",  term: "Term 3 2025" },
  { id: "STD-2605", name: "Kevin Kiprop",   initials: "KK", from: "Grade 4",   to: "Grade 5",   avg: "B+", score: 76, status: "Promoted",  term: "Term 3 2025" },
  { id: "STD-2606", name: "Faith Njeri",    initials: "FN", from: "Grade 1",   to: "Grade 2",   avg: "B",  score: 71, status: "Promoted",  term: "Term 3 2025" },
  { id: "STD-2607", name: "Brian Otieno",   initials: "BO", from: "Form 2",    to: "Form 3",    avg: "B-", score: 65, status: "Promoted",  term: "Term 3 2025" },
  { id: "STD-2608", name: "Amina Hassan",   initials: "AH", from: "PP1",       to: "PP2",       avg: "A",  score: 91, status: "Promoted",  term: "Term 3 2025" },
  { id: "STD-2609", name: "Liam Omondi",    initials: "LO", from: "Grade 5",   to: "Grade 6",   avg: "D",  score: 38, status: "Repeat",    term: "Term 3 2025" },
  { id: "STD-2610", name: "Esther Achieng", initials: "EA", from: "Grade 6",   to: "Grade 7",   avg: "B+", score: 78, status: "Promoted",  term: "Term 3 2025" },
];

const statusConfig = {
  Promoted: { pill: "bg-emerald-50 text-emerald-700 border-emerald-200", icon: CheckCircle2 },
  Pending:  { pill: "bg-amber-50 text-amber-700 border-amber-200",       icon: Clock },
  Repeat:   { pill: "bg-rose-50 text-rose-700 border-rose-200",          icon: TrendingDown },
};

const gradeColor = (avg: string) => {
  if (avg.startsWith("A")) return "bg-emerald-50 text-emerald-700 border-emerald-200";
  if (avg.startsWith("B")) return "bg-blue-50 text-blue-700 border-blue-200";
  if (avg.startsWith("C")) return "bg-amber-50 text-amber-700 border-amber-200";
  return "bg-rose-50 text-rose-700 border-rose-200";
};

const avatarGrads = [
  "from-primary-700 to-primary-900", "from-secondary-500 to-secondary-700",
  "from-indigo-500 to-violet-600",   "from-emerald-500 to-teal-600",
  "from-amber-500 to-orange-500",    "from-sky-500 to-blue-600",
  "from-pink-500 to-rose-600",       "from-cyan-500 to-blue-500",
];

const STATUSES = ["All", "Promoted", "Pending", "Repeat"];
const TERMS    = ["Term 3 2025", "Term 2 2025", "Term 1 2025"];

export default function ProgressPage() {
  const [search, setSearch]     = useState("");
  const [statusF, setStatusF]   = useState("All");
  const [term, setTerm]         = useState("Term 3 2025");

  const filtered = PROMOTIONS.filter(r => {
    const matchSearch = !search || r.name.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusF === "All" || r.status === statusF;
    return matchSearch && matchStatus;
  });

  const counts = {
    Promoted: PROMOTIONS.filter(r => r.status === "Promoted").length,
    Pending:  PROMOTIONS.filter(r => r.status === "Pending").length,
    Repeat:   PROMOTIONS.filter(r => r.status === "Repeat").length,
  };

  return (
    <div className="space-y-4">

      {/* Summary cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { label: "Promoted Students", value: counts.Promoted, icon: TrendingUp,   color: "from-emerald-500 to-teal-600" },
          { label: "Pending Reviews",   value: counts.Pending,  icon: Clock,         color: "from-amber-500 to-orange-500" },
          { label: "Repeating Class",   value: counts.Repeat,   icon: TrendingDown, color: "from-rose-500 to-red-600" },
        ].map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className={`bg-gradient-to-br ${c.color} rounded-2xl p-4 text-white shadow-md flex items-center gap-3 relative overflow-hidden group`}>
              <div className="absolute top-0 right-0 -mt-2 -mr-2 w-16 h-16 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700"></div>
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0 relative z-10">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div className="relative z-10">
                <p className="text-2xl font-black leading-tight">{c.value}</p>
                <p className="text-xs font-bold text-white/80 leading-tight">{c.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Table card */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden flex flex-col min-h-[500px]">
        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search students..."
                className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-64 placeholder:text-slate-400"
              />
            </div>
            <div className="flex gap-1.5 p-1 bg-slate-100 rounded-xl">
              {STATUSES.map(s => (
                <button key={s} onClick={() => setStatusF(s)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${statusF === s ? "bg-white text-primary-900 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>
                  {s}
                </button>
              ))}
            </div>
            <select
              value={term}
              onChange={e => setTerm(e.target.value)}
              className="px-3 py-2 text-sm font-bold text-slate-700 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 shadow-sm"
            >
              {TERMS.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm transition-colors">
              <BarChart2 className="w-4 h-4" /> Allocate Streams
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all">
              <Plus className="w-4 h-4" /> Promote Class
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-primary-900 to-primary-800 text-white">
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Student</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">From</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider"></th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">To</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Term Avg</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Score</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Status</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((row, i) => {
                const cfg = statusConfig[row.status as keyof typeof statusConfig];
                const StatusIcon = cfg.icon;
                return (
                  <tr key={row.id} className="hover:bg-primary-50/40 border-l-4 border-transparent hover:border-l-secondary-500 transition-all group">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${avatarGrads[i % avatarGrads.length]} flex items-center justify-center text-white text-[10px] font-black shadow-sm flex-shrink-0`}>
                          {row.initials}
                        </div>
                        <div>
                          <p className="font-bold text-slate-800 text-sm">{row.name}</p>
                          <p className="text-[10px] font-black text-primary-700 bg-primary-50 px-1.5 py-0.5 rounded mt-0.5 inline-block">{row.id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="text-xs font-bold text-slate-600 bg-slate-100 border border-slate-200 px-2 py-1 rounded-lg">{row.from}</span>
                    </td>
                    <td className="px-3 py-3.5">
                      <ArrowRight className="w-4 h-4 text-slate-300" />
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="text-xs font-bold text-primary-800 bg-primary-50 border border-primary-100 px-2 py-1 rounded-lg">{row.to}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`text-xs font-black px-2.5 py-1 rounded-lg border ${gradeColor(row.avg)}`}>{row.avg}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${row.score >= 70 ? "bg-emerald-500" : row.score >= 50 ? "bg-amber-500" : "bg-rose-500"}`}
                            style={{ width: `${row.score}%` }}
                          />
                        </div>
                        <span className="text-xs font-black text-slate-600">{row.score}%</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] uppercase tracking-wider font-black border w-fit ${cfg.pill}`}>
                        <StatusIcon className="w-3 h-3" />{row.status}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          
          {filtered.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-slate-400">
              <Sparkles className="w-12 h-12 mb-3 opacity-20" />
              <p className="font-bold text-lg text-slate-500">No promotion records found</p>
            </div>
          )}
        </div>

        {/* Pagination */}
        <div className="px-5 py-3.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/60 mt-auto">
          <span className="font-bold">Showing <span className="text-primary-900">{filtered.length}</span> of {PROMOTIONS.length} records</span>
          <div className="flex items-center gap-1">
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg hover:bg-slate-50 disabled:opacity-40 font-bold" disabled>
              <ChevronLeft className="w-3.5 h-3.5" /> Prev
            </button>
            <button className="w-8 h-8 flex items-center justify-center rounded-lg bg-primary-900 text-white text-xs font-black">1</button>
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg hover:bg-slate-50 font-bold">
              Next <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}