﻿'use server';

import prisma from '@/lib/prisma';
import { revalidatePath } from 'next/cache';

const DEFAULT_TENANT_ID = '1e8a93ff-1533-4f1a-b337-1473919ff7f2';

export async function getStudentsDirectory() {
  try {
    const students = await prisma.student.findMany({
      where: { tenantId: DEFAULT_TENANT_ID },
      include: {
        enrollments: {
          include: { class: true, stream: true },
          orderBy: { createdAt: 'desc' },
          take: 1
        },
        parents: {
          include: { parent: true }
        }
      },
      orderBy: { firstName: 'asc' }
    });

    return { success: true, data: students };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}
