import { redirect } from 'next/navigation';

export default function ResourcesPage() {
  redirect('/dashboard/operations/resources/calendar');
}