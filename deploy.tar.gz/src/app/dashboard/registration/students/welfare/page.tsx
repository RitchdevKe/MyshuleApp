"use client";

import React, { useState } from "react";
import {
  Search, Plus, MoreHorizontal, Eye, ChevronLeft, ChevronRight,
  HeartPulse, ShieldAlert, Star, Activity, AlertTriangle,
  CheckCircle2, XCircle, Pill, ClipboardList, Sparkles
} from "lucide-react";

const WELFARE = [
  { id: "STD-2601", name: "John Kamau",     initials: "JK", attendance: 95, discipline: "None",             medical: "None",          rewards: "Star of the Week",   counselling: false, flag: "Good" },
  { id: "STD-2602", name: "Mary Wanjiku",   initials: "MW", attendance: 88, discipline: "Late arrival ×2",  medical: "None",          rewards: "—",                  counselling: false, flag: "Good" },
  { id: "STD-2603", name: "David Ochieng",  initials: "DO", attendance: 65, discipline: "Suspended 3 days", medical: "None",          rewards: "—",                  counselling: true,  flag: "Critical" },
  { id: "STD-2604", name: "Sarah Mutiso",   initials: "SM", attendance: 98, discipline: "None",             medical: "None",          rewards: "Best in Science",    counselling: false, flag: "Good" },
  { id: "STD-2605", name: "Kevin Kiprop",   initials: "KK", attendance: 92, discipline: "None",             medical: "Asthma (Mild)", rewards: "—",                  counselling: false, flag: "Good" },
  { id: "STD-2606", name: "Faith Njeri",    initials: "FN", attendance: 90, discipline: "None",             medical: "None",          rewards: "Perfect Attendance", counselling: false, flag: "Good" },
  { id: "STD-2607", name: "Brian Otieno",   initials: "BO", attendance: 87, discipline: "Uniform violation",medical: "None",          rewards: "—",                  counselling: false, flag: "Monitor" },
  { id: "STD-2608", name: "Amina Hassan",   initials: "AH", attendance: 96, discipline: "None",             medical: "Allergy (Food)",rewards: "Best Pupil",         counselling: false, flag: "Good" },
  { id: "STD-2609", name: "Liam Omondi",    initials: "LO", attendance: 72, discipline: "Bullying report",  medical: "None",          rewards: "—",                  counselling: true,  flag: "Critical" },
  { id: "STD-2610", name: "Esther Achieng", initials: "EA", attendance: 93, discipline: "None",             medical: "Epilepsy",      rewards: "—",                  counselling: false, flag: "Monitor" },
];

const flagConfig = {
  Good:     { pill: "bg-emerald-50 text-emerald-700 border-emerald-200", icon: CheckCircle2 },
  Monitor:  { pill: "bg-amber-50 text-amber-700 border-amber-200",       icon: AlertTriangle },
  Critical: { pill: "bg-rose-50 text-rose-700 border-rose-200",          icon: XCircle },
};

const avatarGrads = [
  "from-primary-700 to-primary-900", "from-secondary-500 to-secondary-700",
  "from-indigo-500 to-violet-600",   "from-emerald-500 to-teal-600",
  "from-amber-500 to-orange-500",    "from-sky-500 to-blue-600",
  "from-pink-500 to-rose-600",       "from-cyan-500 to-blue-500",
];

const FLAGS = ["All", "Good", "Monitor", "Critical"];

export default function WelfarePage() {
  const [search, setSearch]  = useState("");
  const [flagF, setFlagF]    = useState("All");

  const filtered = WELFARE.filter(r => {
    const matchSearch = !search || r.name.toLowerCase().includes(search.toLowerCase());
    const matchFlag   = flagF === "All" || r.flag === flagF;
    return matchSearch && matchFlag;
  });

  const counts = {
    Good:     WELFARE.filter(r => r.flag === "Good").length,
    Monitor:  WELFARE.filter(r => r.flag === "Monitor").length,
    Critical: WELFARE.filter(r => r.flag === "Critical").length,
    Counselling: WELFARE.filter(r => r.counselling).length,
  };

  return (
    <div className="space-y-4">

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "In Good Standing", value: counts.Good,        icon: CheckCircle2, color: "from-emerald-500 to-teal-600" },
          { label: "Monitoring",       value: counts.Monitor,     icon: Activity,      color: "from-amber-500 to-orange-500" },
          { label: "Critical Cases",   value: counts.Critical,    icon: ShieldAlert,   color: "from-rose-500 to-red-600" },
          { label: "Counselling",      value: counts.Counselling, icon: HeartPulse,    color: "from-primary-600 to-primary-800" },
        ].map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className={`bg-gradient-to-br ${c.color} rounded-2xl p-4 text-white shadow-md flex items-center gap-3 relative overflow-hidden group`}>
              <div className="absolute top-0 right-0 -mt-2 -mr-2 w-16 h-16 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700"></div>
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0 relative z-10">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div className="relative z-10">
                <p className="text-2xl font-black leading-tight">{c.value}</p>
                <p className="text-xs font-bold text-white/80 leading-tight">{c.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Table card */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden flex flex-col min-h-[500px]">

        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search students..."
                className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-64 placeholder:text-slate-400"
              />
            </div>
            <div className="flex gap-1.5 p-1 bg-slate-100 rounded-xl">
              {FLAGS.map(f => (
                <button key={f} onClick={() => setFlagF(f)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${flagF === f ? "bg-white text-primary-900 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>
                  {f}
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm transition-colors">
              <ClipboardList className="w-4 h-4" /> Mark Attendance
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all">
              <Plus className="w-4 h-4" /> Log Incident
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-primary-900 to-primary-800 text-white">
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Student</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Attendance</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Discipline</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Medical</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Counselling</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Rewards</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Flag</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((row, i) => {
                const cfg = flagConfig[row.flag as keyof typeof flagConfig];
                const FlagIcon = cfg.icon;
                const attColor = row.attendance >= 90 ? "bg-emerald-500" : row.attendance >= 75 ? "bg-amber-500" : "bg-rose-500";
                return (
                  <tr key={row.id} className="hover:bg-primary-50/40 border-l-4 border-transparent hover:border-l-secondary-500 transition-all group">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${avatarGrads[i % avatarGrads.length]} flex items-center justify-center text-white text-[10px] font-black shadow-sm flex-shrink-0`}>
                          {row.initials}
                        </div>
                        <div>
                          <p className="font-bold text-slate-800 text-sm">{row.name}</p>
                          <p className="text-[10px] font-black text-primary-700 bg-primary-50 px-1.5 py-0.5 rounded mt-0.5 inline-block">{row.id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <div className="w-14 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div className={`h-full ${attColor} rounded-full`} style={{ width: `${row.attendance}%` }} />
                        </div>
                        <span className="text-xs font-black text-slate-600">{row.attendance}%</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      {row.discipline === "None" ? (
                        <span className="text-xs font-bold text-slate-400">—</span>
                      ) : (
                        <span className="flex items-center gap-1 text-xs font-bold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-1 rounded-lg w-fit">
                          <ShieldAlert className="w-3 h-3" /> {row.discipline}
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-3.5">
                      {row.medical === "None" ? (
                        <span className="text-xs font-bold text-slate-400">—</span>
                      ) : (
                        <span className="flex items-center gap-1 text-xs font-bold text-violet-700 bg-violet-50 border border-violet-200 px-2 py-1 rounded-lg w-fit">
                          <Pill className="w-3 h-3" /> {row.medical}
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-3.5">
                      {row.counselling ? (
                        <span className="flex items-center gap-1 text-xs font-bold text-primary-700 bg-primary-50 border border-primary-200 px-2 py-1 rounded-lg w-fit">
                          <HeartPulse className="w-3 h-3" /> Active
                        </span>
                      ) : (
                        <span className="text-xs font-bold text-slate-400">—</span>
                      )}
                    </td>
                    <td className="px-5 py-3.5">
                      {row.rewards !== "—" ? (
                        <span className="flex items-center gap-1 text-xs font-bold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-1 rounded-lg w-fit">
                          <Star className="w-3 h-3 fill-amber-400" /> {row.rewards}
                        </span>
                      ) : (
                        <span className="text-xs font-bold text-slate-400">—</span>
                      )}
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] uppercase tracking-wider font-black border w-fit ${cfg.pill}`}>
                        <FlagIcon className="w-3 h-3" />{row.flag}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {filtered.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-slate-400">
              <Sparkles className="w-12 h-12 mb-3 opacity-20" />
              <p className="font-bold text-lg text-slate-500">No student records found</p>
            </div>
          )}
        </div>

        {/* Pagination */}
        <div className="px-5 py-3.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/60 mt-auto">
          <span className="font-bold">Showing <span className="text-primary-900">{filtered.length}</span> of {WELFARE.length} students</span>
          <div className="flex items-center gap-1">
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg hover:bg-slate-50 disabled:opacity-40 font-bold" disabled>
              <ChevronLeft className="w-3.5 h-3.5" /> Prev
            </button>
            <button className="w-8 h-8 flex items-center justify-center rounded-lg bg-primary-900 text-white text-xs font-black">1</button>
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg hover:bg-slate-50 font-bold">
              Next <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}