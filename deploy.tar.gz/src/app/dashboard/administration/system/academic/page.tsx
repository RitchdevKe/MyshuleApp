"use client";

import React, { useState } from "react";
import { BookOpen, Calendar, Award, CheckCircle2, AlertCircle } from "lucide-react";

export default function AcademicPage() {
  const [activeYear, setActiveYear] = useState("2024-2025");

  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden min-h-[500px]">
      <div className="p-6 border-b border-slate-200/60 bg-slate-50/50">
         <h2 className="text-xl font-black text-slate-800">Academic Setup</h2>
         <p className="text-sm font-medium text-slate-500 mt-1">Configure academic years, terms/semesters, and global grading scales.</p>
      </div>

      <div className="p-6 space-y-8">
         {/* Academic Years */}
         <div>
            <div className="flex justify-between items-center mb-4">
               <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-slate-400" /> Academic Years
               </h3>
               <button className="text-xs font-bold text-primary-600 hover:text-primary-800 transition-colors">+ New Academic Year</button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
               {['2023-2024', '2024-2025', '2025-2026'].map((year) => (
                  <div key={year} className={`border rounded-2xl p-5 relative transition-all cursor-pointer ${
                     activeYear === year 
                     ? 'bg-primary-900 border-primary-900 text-white shadow-md' 
                     : 'bg-white border-slate-200 hover:border-primary-300'
                  }`} onClick={() => setActiveYear(year)}>
                     {activeYear === year && (
                        <div className="absolute top-3 right-3 text-secondary-500">
                           <CheckCircle2 className="w-5 h-5" />
                        </div>
                     )}
                     <h4 className={`text-lg font-black mb-1 ${activeYear === year ? 'text-white' : 'text-slate-800'}`}>{year}</h4>
                     <p className={`text-xs font-medium ${activeYear === year ? 'text-primary-200' : 'text-slate-500'}`}>
                        {year === '2024-2025' ? 'Aug 1, 2024 - Jul 31, 2025' : 'Dates configured'}
                     </p>
                  </div>
               ))}
            </div>
         </div>

         {/* Terms / Semesters */}
         <div>
            <div className="flex justify-between items-center mb-4">
               <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-slate-400" /> Terms & Semesters
               </h3>
            </div>
            <div className="bg-white border border-slate-200/60 rounded-2xl shadow-sm overflow-hidden">
               <table className="w-full text-left border-collapse">
                  <thead>
                     <tr className="bg-slate-50/50 border-b border-slate-100">
                        <th className="py-3 px-5 text-xs font-bold text-slate-500 uppercase tracking-wider">Term Name</th>
                        <th className="py-3 px-5 text-xs font-bold text-slate-500 uppercase tracking-wider">Start Date</th>
                        <th className="py-3 px-5 text-xs font-bold text-slate-500 uppercase tracking-wider">End Date</th>
                        <th className="py-3 px-5 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                        <th className="py-3 px-5 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Action</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                     {[
                        { name: "Term 1", start: "Aug 15, 2024", end: "Nov 30, 2024", status: "Active" },
                        { name: "Term 2", start: "Jan 10, 2025", end: "Apr 05, 2025", status: "Upcoming" },
                        { name: "Term 3", start: "May 01, 2025", end: "Jul 25, 2025", status: "Upcoming" }
                     ].map((term, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                           <td className="py-3 px-5 font-bold text-sm text-slate-800">{term.name}</td>
                           <td className="py-3 px-5 text-sm font-medium text-slate-600">{term.start}</td>
                           <td className="py-3 px-5 text-sm font-medium text-slate-600">{term.end}</td>
                           <td className="py-3 px-5">
                              {term.status === 'Active' ? (
                                 <span className="inline-flex items-center px-2 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg bg-emerald-100 text-emerald-700">Active</span>
                              ) : (
                                 <span className="inline-flex items-center px-2 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg bg-slate-100 text-slate-600">{term.status}</span>
                              )}
                           </td>
                           <td className="py-3 px-5 text-right">
                              <button className="text-xs font-bold text-primary-600 hover:underline">Edit</button>
                           </td>
                        </tr>
                     ))}
                  </tbody>
               </table>
            </div>
         </div>

         {/* Global Grading Scale */}
         <div>
            <div className="flex justify-between items-center mb-4">
               <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                  <Award className="w-4 h-4 text-slate-400" /> Global Grading Scale
               </h3>
               <button className="text-xs font-bold text-primary-600 hover:text-primary-800 transition-colors">Edit Scale</button>
            </div>
            
            <div className="bg-slate-50 border border-slate-200/60 rounded-2xl p-6 flex flex-wrap gap-4 items-center">
               <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-xl flex items-center justify-center font-black text-xl">A</div>
                  <div className="text-sm font-bold text-slate-700">90 - 100</div>
               </div>
               <div className="w-px h-8 bg-slate-200 mx-2"></div>
               <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center font-black text-xl">B</div>
                  <div className="text-sm font-bold text-slate-700">80 - 89</div>
               </div>
               <div className="w-px h-8 bg-slate-200 mx-2"></div>
               <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center font-black text-xl">C</div>
                  <div className="text-sm font-bold text-slate-700">70 - 79</div>
               </div>
               <div className="w-px h-8 bg-slate-200 mx-2"></div>
               <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-amber-100 text-amber-700 rounded-xl flex items-center justify-center font-black text-xl">D</div>
                  <div className="text-sm font-bold text-slate-700">60 - 69</div>
               </div>
               <div className="w-px h-8 bg-slate-200 mx-2"></div>
               <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-rose-100 text-rose-700 rounded-xl flex items-center justify-center font-black text-xl">F</div>
                  <div className="text-sm font-bold text-slate-700">0 - 59</div>
               </div>
            </div>
            <div className="mt-4 flex items-center gap-2 text-xs font-bold text-slate-500 bg-white border border-slate-200 p-3 rounded-lg w-fit shadow-sm">
               <AlertCircle className="w-4 h-4 text-slate-400" />
               Departments can override this global scale if necessary.
            </div>
         </div>

      </div>
    </div>
  );
}
