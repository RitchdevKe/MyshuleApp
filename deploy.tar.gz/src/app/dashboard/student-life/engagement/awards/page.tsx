import React from "react";
import { Award, Search, Filter, Plus, Star } from "lucide-react";

export default function EngagementAwardsPage() {
  const awards = [
    { id: 1, title: "Student of the Year", category: "Excellence", recipients: 1, date: "Dec 10, 2024" },
    { id: 2, title: "Best Debater", category: "Academic", recipients: 3, date: "Nov 15, 2024" },
    { id: 3, title: "Community Service Gold", category: "Service", recipients: 12, date: "Oct 20, 2024" },
    { id: 4, title: "Sports Personality", category: "Athletics", recipients: 2, date: "Sep 05, 2024" },
  ];

  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search awards..." 
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-secondary-500/20 focus:border-secondary-500 transition-all shadow-sm"
          />
        </div>
        
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors shadow-sm">
            <Filter className="w-4 h-4" /> Filter
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-white bg-primary-900 rounded-xl hover:bg-primary-800 transition-colors shadow-sm">
            <Plus className="w-4 h-4" /> Issue Award
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {awards.map((award) => (
          <div key={award.id} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
            
            <div className="absolute -right-4 -top-4 opacity-5 group-hover:opacity-10 transition-opacity transform group-hover:scale-110">
              <Award className="w-24 h-24 text-amber-500" />
            </div>

            <div className="relative z-10">
              <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center text-amber-500 mb-4 shadow-inner">
                <Star className="w-5 h-5 fill-amber-500" />
              </div>
              
              <h3 className="font-bold text-slate-800 mb-1">{award.title}</h3>
              <span className="text-[10px] font-black uppercase tracking-wider text-amber-600 bg-amber-50 px-2 py-0.5 rounded-lg mb-4 inline-block border border-amber-200">
                {award.category}
              </span>

              <div className="pt-4 border-t border-slate-100 mt-2 space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span className="font-medium text-slate-500">Recipients</span>
                  <span className="font-bold text-slate-800">{award.recipients}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="font-medium text-slate-500">Last Issued</span>
                  <span className="font-bold text-slate-600">{award.date}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
