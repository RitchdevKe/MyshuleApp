"use client";

import React from "react";
import { Search, Filter, Key, Shield, UserX, Unlock, Download } from "lucide-react";

export default function AuditPage() {
  const auditLogs = [
    { id: 1, event: "Role Assigned", user: "Admin (Superuser)", target: "Jane Wanjiku", detail: "Assigned 'Bursar' role to Jane Wanjiku", time: "Aug 11, 2024 14:32", ip: "192.168.1.105", icon: Shield, color: "text-emerald-600 bg-emerald-50" },
    { id: 2, event: "Failed Login Attempt", user: "Unknown User", target: "System", detail: "5 consecutive failed login attempts for user 'admin'", time: "Aug 11, 2024 09:15", ip: "45.22.11.90", icon: UserX, color: "text-rose-600 bg-rose-50" },
    { id: 3, event: "Policy Modified", user: "Principal", target: "Access Policies", detail: "Disabled 'Off-Campus Access Restriction' policy", time: "Aug 10, 2024 16:45", ip: "192.168.1.42", icon: Key, color: "text-amber-600 bg-amber-50" },
    { id: 4, event: "Permission Granted", user: "System", target: "API Service", detail: "Granted read access to Financial Data for Integration Sync", time: "Aug 10, 2024 02:00", ip: "127.0.0.1", icon: Unlock, color: "text-blue-600 bg-blue-50" },
  ];

  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden min-h-[500px]">
      <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50/50">
         <div className="flex items-center gap-2 w-full md:w-auto relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input type="text" placeholder="Search audit logs..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
         </div>
         <div className="flex gap-2">
            <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
               <Filter className="w-4 h-4" />
               Filter Logs
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
               <Download className="w-4 h-4" />
               Export CSV
            </button>
         </div>
      </div>

      <div className="p-6">
         <div className="overflow-x-auto">
           <table className="w-full text-left border-collapse">
             <thead>
               <tr className="bg-slate-50/50 border-b border-slate-200/60">
                 <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Event</th>
                 <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Actor / Target</th>
                 <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Timestamp & IP</th>
                 <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Details</th>
               </tr>
             </thead>
             <tbody className="divide-y divide-slate-100">
               {auditLogs.map((log) => {
                 const Icon = log.icon;
                 return (
                 <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                   <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                         <div className={`w-8 h-8 rounded-lg flex items-center justify-center shadow-inner shrink-0 ${log.color}`}>
                            <Icon className="w-4 h-4" />
                         </div>
                         <span className="font-bold text-sm text-slate-800">{log.event}</span>
                      </div>
                   </td>
                   <td className="py-4 px-6">
                      <div className="text-sm font-bold text-slate-700">{log.user}</div>
                      <div className="text-xs font-medium text-slate-500 flex items-center gap-1 mt-1">
                         <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">Target:</span> {log.target}
                      </div>
                   </td>
                   <td className="py-4 px-6">
                      <div className="text-sm font-bold text-slate-700">{log.time}</div>
                      <div className="text-xs font-medium text-slate-500 mt-1">IP: {log.ip}</div>
                   </td>
                   <td className="py-4 px-6">
                      <p className="text-sm font-medium text-slate-600 max-w-sm">{log.detail}</p>
                   </td>
                 </tr>
                 );
               })}
             </tbody>
           </table>
         </div>
      </div>
    </div>
  );
}
