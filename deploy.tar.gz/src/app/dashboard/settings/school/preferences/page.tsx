"use client";

import React, { useState } from "react";
import { Sliders, Globe, DollarSign, Calendar as CalendarIcon, Clock, Lock } from "lucide-react";

export default function PreferencesPage() {
  const [toggles, setToggles] = useState({
     autoBackup: true,
     maintenanceMode: false,
     studentPortal: true,
     parentPortal: true,
     teacherPortal: true,
     twoFactorAdmin: true,
  });

  const handleToggle = (key: keyof typeof toggles) => {
     setToggles(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <div className="flex items-center gap-3 mb-8">
         <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center">
            <Sliders className="w-5 h-5" />
         </div>
         <div>
            <h3 className="text-xl font-black text-slate-800">Global Preferences</h3>
            <p className="text-sm font-medium text-slate-500">System-wide operational defaults and access toggles.</p>
         </div>
      </div>
      
      <div className="space-y-10">
        
        {/* Localization & Formatting */}
        <div>
           <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">Localization & Formatting</h4>
           
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 flex items-start gap-4">
                 <Globe className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
                 <div className="w-full">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Default Language</label>
                    <select className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-slate-500 transition-all shadow-sm">
                       <option>English (UK)</option>
                       <option>English (US)</option>
                       <option>Swahili</option>
                       <option>French</option>
                    </select>
                 </div>
              </div>

              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 flex items-start gap-4">
                 <DollarSign className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
                 <div className="w-full">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Base Currency</label>
                    <select className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-slate-500 transition-all shadow-sm">
                       <option>KES - Kenyan Shilling</option>
                       <option>USD - US Dollar</option>
                       <option>EUR - Euro</option>
                       <option>UGX - Ugandan Shilling</option>
                    </select>
                 </div>
              </div>

              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 flex items-start gap-4">
                 <CalendarIcon className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
                 <div className="w-full">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Date Format</label>
                    <select className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-slate-500 transition-all shadow-sm">
                       <option>DD/MM/YYYY (UK)</option>
                       <option>MM/DD/YYYY (US)</option>
                       <option>YYYY-MM-DD (ISO)</option>
                    </select>
                 </div>
              </div>

              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100 flex items-start gap-4">
                 <Clock className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
                 <div className="w-full">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Time Format</label>
                    <select className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-slate-500 transition-all shadow-sm">
                       <option>12-hour (AM/PM)</option>
                       <option>24-hour</option>
                    </select>
                 </div>
              </div>
           </div>
        </div>

        {/* System Access & Toggles */}
        <div>
           <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-2">
              <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                 <Lock className="w-4 h-4" /> System Access & Toggles
              </h4>
           </div>
           
           <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden divide-y divide-slate-100">
              
              <div className="p-5 flex items-center justify-between hover:bg-slate-50 transition-colors">
                 <div>
                    <div className="font-bold text-slate-800 text-sm">Parent Portal Access</div>
                    <div className="text-xs font-medium text-slate-500">Allow parents to log in and view student progress.</div>
                 </div>
                 <button 
                    onClick={() => handleToggle('parentPortal')}
                    className={`w-12 h-6 rounded-full relative transition-colors ${toggles.parentPortal ? 'bg-indigo-500' : 'bg-slate-300'}`}
                 >
                    <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${toggles.parentPortal ? 'left-7' : 'left-1'}`}></div>
                 </button>
              </div>

              <div className="p-5 flex items-center justify-between hover:bg-slate-50 transition-colors">
                 <div>
                    <div className="font-bold text-slate-800 text-sm">Student Portal Access</div>
                    <div className="text-xs font-medium text-slate-500">Allow students to log in and view assignments/grades.</div>
                 </div>
                 <button 
                    onClick={() => handleToggle('studentPortal')}
                    className={`w-12 h-6 rounded-full relative transition-colors ${toggles.studentPortal ? 'bg-indigo-500' : 'bg-slate-300'}`}
                 >
                    <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${toggles.studentPortal ? 'left-7' : 'left-1'}`}></div>
                 </button>
              </div>

              <div className="p-5 flex items-center justify-between hover:bg-slate-50 transition-colors">
                 <div>
                    <div className="font-bold text-slate-800 text-sm">2FA for Administrators</div>
                    <div className="text-xs font-medium text-slate-500">Require Two-Factor Authentication for all admin accounts.</div>
                 </div>
                 <button 
                    onClick={() => handleToggle('twoFactorAdmin')}
                    className={`w-12 h-6 rounded-full relative transition-colors ${toggles.twoFactorAdmin ? 'bg-indigo-500' : 'bg-slate-300'}`}
                 >
                    <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${toggles.twoFactorAdmin ? 'left-7' : 'left-1'}`}></div>
                 </button>
              </div>

              <div className="p-5 flex items-center justify-between hover:bg-slate-50 transition-colors bg-rose-50/30">
                 <div>
                    <div className="font-bold text-rose-700 text-sm">Maintenance Mode</div>
                    <div className="text-xs font-medium text-rose-600">Disable all non-admin access and show a maintenance page.</div>
                 </div>
                 <button 
                    onClick={() => handleToggle('maintenanceMode')}
                    className={`w-12 h-6 rounded-full relative transition-colors ${toggles.maintenanceMode ? 'bg-rose-500' : 'bg-slate-300'}`}
                 >
                    <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${toggles.maintenanceMode ? 'left-7' : 'left-1'}`}></div>
                 </button>
              </div>

           </div>
        </div>

      </div>
    </div>
  );
}
