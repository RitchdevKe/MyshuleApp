import { redirect } from 'next/navigation';

export default function AccountingPage() {
  redirect('/dashboard/finance/accounting/chart-of-accounts');
}