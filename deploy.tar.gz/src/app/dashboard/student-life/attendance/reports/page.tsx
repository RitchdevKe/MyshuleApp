"use client";
import React from "react";
import { Download, FileText, FileSpreadsheet, Calendar, Filter, BarChart } from "lucide-react";

export default function AttendanceReportsTab() {
  return (
    <div className="p-6 h-full flex flex-col md:flex-row gap-6">
      
      {/* Report Configuration Sidebar */}
      <div className="w-full md:w-1/3 bg-white/40 backdrop-blur-md rounded-3xl border border-white/60 p-6 shadow-sm flex flex-col gap-6">
        <div>
          <h2 className="text-xl font-black text-slate-800 tracking-tight flex items-center gap-2">
            <BarChart className="w-6 h-6 text-indigo-500" /> Generate Report
          </h2>
          <p className="text-sm font-medium text-slate-500 mt-1">Select parameters to generate an attendance export.</p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-black uppercase tracking-wider text-slate-600 mb-2">Report Type</label>
            <select className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:border-indigo-500">
              <option>Detailed Attendance Log</option>
              <option>Chronic Absenteeism Summary</option>
              <option>Leave Request History</option>
            </select>
          </div>
          
          <div>
            <label className="block text-xs font-black uppercase tracking-wider text-slate-600 mb-2">Cohort</label>
            <select className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:border-indigo-500">
              <option>Whole School</option>
              <option>Primary</option>
              <option>Secondary</option>
              <option>Grade 8</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-black uppercase tracking-wider text-slate-600 mb-2">Date Range</label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Calendar className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input type="date" className="w-full pl-9 pr-2 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-600 shadow-sm focus:outline-none focus:border-indigo-500" />
              </div>
              <div className="flex items-center text-slate-400">-</div>
              <div className="relative flex-1">
                <Calendar className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input type="date" className="w-full pl-9 pr-2 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-600 shadow-sm focus:outline-none focus:border-indigo-500" />
              </div>
            </div>
          </div>
        </div>

        <div className="mt-auto space-y-3">
          <button className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 text-white font-bold rounded-xl shadow-md shadow-indigo-600/20 hover:bg-indigo-700 transition-colors">
            <Download className="w-5 h-5" /> Generate Report
          </button>
          
          <div className="flex gap-3">
            <button className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-white border border-slate-200 text-slate-600 font-bold rounded-xl hover:bg-slate-50 transition-colors shadow-sm">
              <FileText className="w-4 h-4 text-rose-500" /> PDF
            </button>
            <button className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-white border border-slate-200 text-slate-600 font-bold rounded-xl hover:bg-slate-50 transition-colors shadow-sm">
              <FileSpreadsheet className="w-4 h-4 text-emerald-500" /> CSV
            </button>
          </div>
        </div>
      </div>

      {/* Preview Area */}
      <div className="w-full md:w-2/3 bg-white/60 backdrop-blur-md rounded-3xl border border-white p-6 shadow-sm flex flex-col items-center justify-center text-center">
        <div className="w-20 h-20 bg-slate-100 rounded-3xl flex items-center justify-center mb-4 text-slate-300">
          <FileText className="w-10 h-10" />
        </div>
        <h3 className="text-xl font-black text-slate-800">Preview Data</h3>
        <p className="text-sm font-medium text-slate-500 max-w-md mt-2">
          Configure the report parameters on the left and click "Generate Report" to preview the data here before exporting.
        </p>
      </div>

    </div>
  );
}
