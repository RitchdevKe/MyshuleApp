"use client";

import React from "react";
import { Search, Users, Plus, Edit, Trash2 } from "lucide-react";

export default function GroupsPage() {
  const groups = [
    { id: 1, name: "All Teachers", description: "All teaching staff across all grades.", members: 142, roleType: "Staff" },
    { id: 2, name: "PTA Board", description: "Members of the Parent-Teacher Association board.", members: 12, roleType: "Mixed" },
    { id: 3, name: "Grade 10 Parents", description: "Parents and guardians of Grade 10 students.", members: 215, roleType: "Parent" },
    { id: 4, name: "System Admins", description: "IT support and high-level system administrators.", members: 4, roleType: "Admin" },
  ];

  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden min-h-[500px]">
      <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50/50">
         <div className="flex items-center gap-2 w-full md:w-auto relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input type="text" placeholder="Search groups..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
         </div>
         <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
            <Plus className="w-4 h-4" />
            Create Group
         </button>
      </div>

      <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
         {groups.map((group) => (
            <div key={group.id} className="border border-slate-200 p-5 rounded-2xl hover:border-primary-400 hover:shadow-md transition-all group">
               <div className="flex justify-between items-start mb-3">
                  <div className="p-2.5 rounded-xl bg-primary-50 text-primary-600">
                     <Users className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 bg-slate-100 px-2 py-1 rounded-lg">
                     {group.roleType}
                  </span>
               </div>
               <h4 className="font-bold text-slate-800 text-lg mb-1">{group.name}</h4>
               <p className="text-sm text-slate-500 font-medium mb-4">{group.description}</p>
               
               <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                  <div className="text-xs font-bold text-slate-600">
                     <span className="text-primary-600">{group.members}</span> Members
                  </div>
                  <div className="flex gap-2">
                     <button className="p-2 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                        <Edit className="w-4 h-4" />
                     </button>
                     <button className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4" />
                     </button>
                  </div>
               </div>
            </div>
         ))}
      </div>
    </div>
  );
}
