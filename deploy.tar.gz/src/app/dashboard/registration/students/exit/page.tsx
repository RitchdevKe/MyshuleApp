"use client";

import React, { useState } from "react";
import {
  Search, Plus, MoreHorizontal, Eye, Download,
  ChevronLeft, ChevronRight, GraduationCap, ArrowRightLeft,
  LogOut, CheckCircle2, Clock, XCircle, FileCheck, AlertTriangle,
  Building, Sparkles
} from "lucide-react";

const EXITS = [
  { id: "STD-2550", name: "Peter Otieno",    initials: "PO", grade: "Form 4",  exitType: "Graduation",  date: "15/11/25", destination: "Strathmore University", clearance: "Cleared",      fees: "Settled",  status: "Complete" },
  { id: "STD-2551", name: "Grace Njau",       initials: "GN", grade: "Grade 7", exitType: "Transfer",    date: "02/09/25", destination: "Brookside Academy",     clearance: "Cleared",      fees: "Settled",  status: "Complete" },
  { id: "STD-2552", name: "Michael Auma",     initials: "MA", grade: "Form 2",  exitType: "Withdrawal",  date: "10/10/25", destination: "Family relocation",     clearance: "Pending",      fees: "Balance",  status: "Pending" },
  { id: "STD-2553", name: "Joy Chebet",       initials: "JC", grade: "Form 4",  exitType: "Graduation",  date: "15/11/25", destination: "University of Nairobi", clearance: "Cleared",      fees: "Settled",  status: "Complete" },
  { id: "STD-2554", name: "Dennis Kariuki",   initials: "DK", grade: "Grade 5", exitType: "Transfer",    date: "20/08/25", destination: "Green Valley School",   clearance: "Cleared",      fees: "Settled",  status: "Complete" },
  { id: "STD-2555", name: "Naomi Wambua",     initials: "NW", grade: "Form 3",  exitType: "Expulsion",   date: "05/06/25", destination: "—",                     clearance: "Not Cleared",  fees: "Balance",  status: "Incomplete" },
  { id: "STD-2556", name: "Samuel Lesiit",    initials: "SL", grade: "Grade 3", exitType: "Transfer",    date: "15/09/25", destination: "Rift Valley Academy",   clearance: "Pending",      fees: "Settled",  status: "Pending" },
];

const exitTypeConfig: Record<string, { color: string; icon: React.ElementType }> = {
  Graduation: { color: "bg-emerald-50 text-emerald-700 border-emerald-200", icon: GraduationCap },
  Transfer:   { color: "bg-sky-50 text-sky-700 border-sky-200",             icon: ArrowRightLeft },
  Withdrawal: { color: "bg-amber-50 text-amber-700 border-amber-200",       icon: LogOut },
  Expulsion:  { color: "bg-rose-50 text-rose-700 border-rose-200",          icon: XCircle },
};

const statusConfig = {
  Complete:   { pill: "bg-emerald-50 text-emerald-700 border-emerald-200", icon: CheckCircle2 },
  Pending:    { pill: "bg-amber-50 text-amber-700 border-amber-200",       icon: Clock },
  Incomplete: { pill: "bg-rose-50 text-rose-700 border-rose-200",          icon: AlertTriangle },
};

const clearanceConfig: Record<string, string> = {
  "Cleared":      "text-emerald-700 bg-emerald-50 border-emerald-200",
  "Pending":      "text-amber-700 bg-amber-50 border-amber-200",
  "Not Cleared":  "text-rose-700 bg-rose-50 border-rose-200",
};

const feesConfig: Record<string, string> = {
  "Settled": "text-emerald-700 bg-emerald-50 border-emerald-200",
  "Balance": "text-rose-700 bg-rose-50 border-rose-200",
};

const avatarGrads = [
  "from-primary-700 to-primary-900", "from-secondary-500 to-secondary-700",
  "from-indigo-500 to-violet-600",   "from-emerald-500 to-teal-600",
  "from-amber-500 to-orange-500",    "from-sky-500 to-blue-600",
  "from-pink-500 to-rose-600",
];

const EXIT_TYPES = ["All", "Graduation", "Transfer", "Withdrawal", "Expulsion"];
const STATUSES   = ["All", "Complete", "Pending", "Incomplete"];

export default function ExitPage() {
  const [search, setSearch]  = useState("");
  const [typeF, setTypeF]    = useState("All");
  const [statusF, setStatusF] = useState("All");

  const filtered = EXITS.filter(r => {
    const matchSearch = !search || r.name.toLowerCase().includes(search.toLowerCase());
    const matchType   = typeF === "All" || r.exitType === typeF;
    const matchStatus = statusF === "All" || r.status === statusF;
    return matchSearch && matchType && matchStatus;
  });

  const counts = {
    Complete:   EXITS.filter(r => r.status === "Complete").length,
    Pending:    EXITS.filter(r => r.status === "Pending").length,
    Incomplete: EXITS.filter(r => r.status === "Incomplete").length,
    Total:      EXITS.length,
  };

  return (
    <div className="space-y-4">

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Exits",       value: counts.Total,      icon: LogOut,       color: "from-primary-600 to-primary-800" },
          { label: "Cleared",           value: counts.Complete,   icon: CheckCircle2, color: "from-emerald-500 to-teal-600" },
          { label: "Pending Clearance", value: counts.Pending,    icon: Clock,         color: "from-amber-500 to-orange-500" },
          { label: "Incomplete",        value: counts.Incomplete, icon: AlertTriangle, color: "from-rose-500 to-red-600" },
        ].map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className={`bg-gradient-to-br ${c.color} rounded-2xl p-4 text-white shadow-md flex items-center gap-3 relative overflow-hidden group`}>
              <div className="absolute top-0 right-0 -mt-2 -mr-2 w-16 h-16 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700"></div>
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0 relative z-10">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div className="relative z-10">
                <p className="text-2xl font-black leading-tight">{c.value}</p>
                <p className="text-xs font-bold text-white/80 leading-tight">{c.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Table card */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden flex flex-col min-h-[500px]">

        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search students..."
                className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-64 placeholder:text-slate-400"
              />
            </div>

            {/* Exit type filters */}
            <div className="flex gap-1.5 p-1 bg-slate-100 rounded-xl flex-wrap">
              {EXIT_TYPES.map(t => (
                <button key={t} onClick={() => setTypeF(t)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${typeF === t ? "bg-white text-primary-900 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>
                  {t}
                </button>
              ))}
            </div>

            {/* Status filters */}
            <div className="flex gap-1.5 p-1 bg-slate-100 rounded-xl flex-wrap">
              {STATUSES.map(s => (
                <button key={s} onClick={() => setStatusF(s)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${statusF === s ? "bg-white text-primary-900 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm transition-colors">
              <FileCheck className="w-4 h-4" /> Generate Certificate
            </button>
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm transition-colors">
              <Download className="w-4 h-4" /> Export
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all">
              <Plus className="w-4 h-4" /> Process Exit
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-primary-900 to-primary-800 text-white">
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Student</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Grade</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Exit Type</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Exit Date</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Destination</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Clearance</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Fees</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Status</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((row, i) => {
                const stCfg  = statusConfig[row.status as keyof typeof statusConfig];
                const etCfg  = exitTypeConfig[row.exitType] || exitTypeConfig.Transfer;
                const StatusIcon = stCfg.icon;
                const ExitIcon   = etCfg.icon;
                return (
                  <tr key={row.id} className="hover:bg-primary-50/40 border-l-4 border-transparent hover:border-l-secondary-500 transition-all group">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${avatarGrads[i % avatarGrads.length]} flex items-center justify-center text-white text-[10px] font-black shadow-sm flex-shrink-0`}>
                          {row.initials}
                        </div>
                        <div>
                          <p className="font-bold text-slate-800 text-sm">{row.name}</p>
                          <p className="text-[10px] font-black text-primary-700 bg-primary-50 px-1.5 py-0.5 rounded mt-0.5 inline-block">{row.id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="text-xs font-bold text-slate-600 bg-slate-100 border border-slate-200 px-2 py-1 rounded-lg flex items-center gap-1 w-fit">
                        <GraduationCap className="w-3 h-3 text-slate-400" />{row.grade}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`flex items-center gap-1.5 text-xs font-black px-2.5 py-1 rounded-lg border ${etCfg.color} w-fit`}>
                        <ExitIcon className="w-3 h-3" />{row.exitType}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-xs font-bold text-slate-500">{row.date}</td>
                    <td className="px-5 py-3.5">
                      <span className="flex items-center gap-1 text-xs font-bold text-slate-600">
                        <Building className="w-3 h-3 text-slate-400" />{row.destination}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`text-xs font-black px-2.5 py-1 rounded-lg border w-fit inline-block ${clearanceConfig[row.clearance]}`}>{row.clearance}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`text-xs font-black px-2.5 py-1 rounded-lg border w-fit inline-block ${feesConfig[row.fees]}`}>{row.fees}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] uppercase tracking-wider font-black border w-fit ${stCfg.pill}`}>
                        <StatusIcon className="w-3 h-3" />{row.status}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                          <FileCheck className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {filtered.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-slate-400">
              <Sparkles className="w-12 h-12 mb-3 opacity-20" />
              <p className="font-bold text-lg text-slate-500">No exit records found</p>
            </div>
          )}
        </div>

        {/* Pagination */}
        <div className="px-5 py-3.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50/60 mt-auto">
          <span className="font-bold">Showing <span className="text-primary-900">{filtered.length}</span> of {EXITS.length} exit records</span>
          <div className="flex items-center gap-1">
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg hover:bg-slate-50 disabled:opacity-40 font-bold" disabled>
              <ChevronLeft className="w-3.5 h-3.5" /> Prev
            </button>
            <button className="w-8 h-8 flex items-center justify-center rounded-lg bg-primary-900 text-white text-xs font-black">1</button>
            <button className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg hover:bg-slate-50 font-bold">
              Next <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}