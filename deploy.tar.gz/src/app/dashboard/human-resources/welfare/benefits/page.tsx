"use client";

import React from "react";
import { HeartPulse, Plus, Search, Filter, ShieldPlus, Users, Activity, ExternalLink } from "lucide-react";

export default function BenefitsPage() {
  const benefits = [
    { id: "BEN-01", title: "Comprehensive Medical", provider: "Jubilee Insurance", type: "Health", enrolled: 142, limit: "KES 1M Inpatient", status: "Active", bg: "bg-emerald-50", color: "text-emerald-600", icon: ShieldPlus },
    { id: "BEN-02", title: "Dental & Optical", provider: "AAR Insurance", type: "Health", enrolled: 142, limit: "KES 50K per year", status: "Active", bg: "bg-blue-50", color: "text-blue-600", icon: HeartPulse },
    { id: "BEN-03", title: "Mental Health Support", provider: "Wazi", type: "Wellness", enrolled: 35, limit: "12 Sessions/yr", status: "Active", bg: "bg-amber-50", color: "text-amber-600", icon: Activity },
    { id: "BEN-04", title: "Gym Membership Subsidy", provider: "SmartGyms", type: "Wellness", enrolled: 68, limit: "50% Corporate", status: "Active", bg: "bg-rose-50", color: "text-rose-600", icon: Activity },
  ];

  return (
    <div className="space-y-6">
      {/* Top Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-primary-50 text-primary-600 rounded-2xl">
             <ShieldPlus className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Health Plans</p>
            <p className="text-2xl font-black text-slate-800">2</p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl">
             <Activity className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Wellness Programs</p>
            <p className="text-2xl font-black text-slate-800">4</p>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
             <Users className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Enrolled Staff</p>
            <p className="text-2xl font-black text-slate-800">142</p>
          </div>
        </div>
      </div>

      <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-2">
         <div className="flex items-center gap-2 w-full md:w-auto relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input type="text" placeholder="Search benefits..." className="w-full md:w-80 pl-9 pr-4 py-2.5 bg-white border border-slate-200/60 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-primary-900 shadow-sm" />
         </div>
         <div className="flex gap-2">
            <button className="flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
               <Filter className="w-4 h-4" />
               Filter
            </button>
            <button className="flex items-center gap-2 px-4 py-2.5 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
               <Plus className="w-4 h-4" />
               New Benefit
            </button>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
         {benefits.map((benefit) => {
            const Icon = benefit.icon;
            return (
               <div key={benefit.id} className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-6 hover:shadow-xl transition-all duration-300 group flex flex-col">
                  <div className="flex justify-between items-start mb-4">
                     <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${benefit.bg} ${benefit.color}`}>
                           <Icon className="w-6 h-6" />
                        </div>
                        <div>
                           <div className="flex items-center gap-2 mb-1">
                              <span className={`px-2 py-0.5 text-[10px] font-black uppercase tracking-wider rounded-md ${benefit.type === 'Health' ? 'bg-blue-50 text-blue-600' : 'bg-amber-50 text-amber-600'}`}>
                                 {benefit.type}
                              </span>
                           </div>
                           <h3 className="font-black text-lg text-slate-800 leading-tight">{benefit.title}</h3>
                           <p className="text-xs font-bold text-slate-400 mt-0.5">Provider: <span className="text-slate-600">{benefit.provider}</span></p>
                        </div>
                     </div>
                  </div>
                  
                  <div className="bg-slate-50 rounded-2xl p-4 mb-4 flex-grow flex justify-between items-center">
                     <div>
                        <p className="text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Coverage / Limit</p>
                        <p className="font-bold text-slate-700 text-sm">{benefit.limit}</p>
                     </div>
                     <div className="text-right">
                        <p className="text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">Enrolled</p>
                        <div className="flex items-center justify-end gap-1 font-black text-slate-800">
                           <Users className="w-3.5 h-3.5 text-primary-500" />
                           {benefit.enrolled}
                        </div>
                     </div>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-slate-100">
                     <div className="flex items-center gap-1.5">
                        <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                        <span className="text-xs font-bold text-slate-500">Active Plan</span>
                     </div>
                     <button className="flex items-center gap-1.5 text-sm font-bold text-primary-600 hover:text-primary-800 transition-colors">
                        Manage Plan <ExternalLink className="w-3.5 h-3.5" />
                     </button>
                  </div>
               </div>
            );
         })}
      </div>
    </div>
  );
}
