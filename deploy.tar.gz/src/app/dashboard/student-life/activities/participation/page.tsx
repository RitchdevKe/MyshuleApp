"use client";

import React, { useState } from "react";
import { Star, Search, Filter } from "lucide-react";

export default function ParticipationPage() {
  const students = [
    { name: "Mary Wanjiku", grade: "Grade 10", activities: 4, points: 120, status: "Highly Active" },
    { name: "John Kamau", grade: "Grade 11", activities: 2, points: 45, status: "Active" },
    { name: "Brian Mwangi", grade: "Grade 8", activities: 0, points: 0, status: "Inactive" },
    { name: "Alice Wambui", grade: "Grade 9", activities: 3, points: 85, status: "Active" },
  ];

  return (
    <div className="p-8 space-y-6 bg-white/30 backdrop-blur-md rounded-3xl min-h-[600px]">
      
      {/* Header & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white/60 p-4 rounded-2xl border border-white/60 shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center">
            <Star className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-slate-800">Student Participation</h2>
            <p className="text-xs font-bold text-slate-500">Track extracurricular engagement levels</p>
          </div>
        </div>
      </div>

      <div className="bg-white/80 border border-slate-200/60 rounded-3xl overflow-hidden shadow-sm">
        <div className="p-4 border-b border-slate-100 flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search student..." 
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 transition-all"
            />
          </div>
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-slate-600 bg-slate-50 border border-slate-200 rounded-xl hover:bg-slate-100 transition-colors">
            <Filter className="w-4 h-4" /> Filter
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-200/60">
                <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider">Student</th>
                <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">Activities Enrolled</th>
                <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider text-center">Engagement Points</th>
                <th className="p-4 text-xs font-black text-slate-500 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100/80">
              {students.map((s, i) => (
                <tr key={i} className="hover:bg-purple-50/30 transition-colors cursor-pointer">
                  <td className="p-4">
                    <div className="text-sm font-bold text-slate-800">{s.name}</div>
                    <div className="text-xs font-medium text-slate-500">{s.grade}</div>
                  </td>
                  <td className="p-4 text-center">
                    <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-slate-100 font-black text-slate-700">
                      {s.activities}
                    </span>
                  </td>
                  <td className="p-4 text-center">
                    <span className="text-lg font-black text-purple-600">{s.points}</span>
                  </td>
                  <td className="p-4">
                    <span className={`px-2.5 py-1 text-[10px] font-black uppercase tracking-wider border rounded shadow-sm ${
                      s.status === 'Highly Active' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' :
                      s.status === 'Active' ? 'bg-indigo-50 text-indigo-600 border-indigo-100' :
                      'bg-rose-50 text-rose-600 border-rose-200'
                    }`}>
                      {s.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
