"use client";
import React from "react";
import { Search, Plus, MoreHorizontal, Calendar, Users, MapPin, Clock } from "lucide-react";

const mockEvents = [
  { id: "EVT-001", name: "Science Fair", date: "2026-06-20", time: "09:00 AM", location: "Main Hall", audience: "All Students, Parents", status: "Upcoming" },
  { id: "EVT-002", name: "PTA Meeting", date: "2026-06-15", time: "02:00 PM", location: "Staff Room", audience: "Parents, Teachers", status: "Completed" },
  { id: "EVT-003", name: "Sports Day", date: "2026-07-10", time: "08:00 AM", location: "School Field", audience: "All Students", status: "Upcoming" },
  { id: "EVT-004", name: "Mid-term Break", date: "2026-06-25", time: "All Day", location: "N/A", audience: "School-wide", status: "Upcoming" },
];

export default function EventsPage() {
  const getStatusStyle = (status: string) => {
    switch (status) {
      case "Upcoming": return "bg-blue-100/80 text-blue-700 border-blue-200";
      case "Completed": return "bg-slate-100/80 text-slate-700 border-slate-200";
      default: return "bg-slate-100/80 text-slate-700 border-slate-200";
    }
  };

  return (
    <div className="bg-white/60 backdrop-blur-xl border border-white/60 rounded-3xl shadow-lg overflow-hidden flex flex-col min-h-[400px]">
      
      {/* Toolbar */}
      <div className="p-5 border-b border-slate-200/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative w-full sm:max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search events..." 
            className="w-full pl-10 pr-4 py-2.5 text-sm font-bold bg-white/80 border border-slate-200/60 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-900 focus:border-primary-900 transition-shadow"
          />
        </div>
        <div className="flex items-center gap-3">
          <select className="px-4 py-2.5 bg-white border border-slate-200/60 rounded-xl text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-900 cursor-pointer">
            <option>All Event Types</option>
            <option>Academic</option>
            <option>Sports</option>
            <option>Meetings</option>
          </select>
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-white bg-primary-900 rounded-xl hover:bg-primary-800 transition-colors shadow-sm">
            <Plus className="w-4 h-4" /> Add Event
          </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-x-auto">
        <table className="w-full text-left text-sm text-slate-600">
          <thead className="bg-slate-50/50 text-[10px] uppercase font-black text-slate-500 border-b border-slate-200/60 tracking-wider">
            <tr>
              <th className="px-6 py-4">Event Details</th>
              <th className="px-6 py-4">Date & Time</th>
              <th className="px-6 py-4">Location</th>
              <th className="px-6 py-4">Audience</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200/60">
            {mockEvents.map((row, i) => (
              <tr key={i} className="hover:bg-white/80 transition-colors group">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-primary-50 text-primary-900 rounded-lg group-hover:bg-primary-100 transition-colors">
                      <Calendar className="w-4 h-4" />
                    </div>
                    <div className="flex flex-col">
                      <span className="font-bold text-slate-800">{row.name}</span>
                      <span className="text-xs font-bold text-slate-400">{row.id}</span>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-col gap-1">
                    <span className="font-bold text-slate-700 flex items-center gap-1.5"><Calendar className="w-3 h-3" />{row.date}</span>
                    <span className="text-xs font-bold text-slate-500 flex items-center gap-1.5"><Clock className="w-3 h-3" />{row.time}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="flex items-center gap-1.5 font-bold text-slate-600">
                    <MapPin className="w-4 h-4 text-slate-400" />
                    {row.location}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <span className="flex items-center gap-1.5 font-bold text-slate-600">
                    <Users className="w-4 h-4 text-slate-400" />
                    {row.audience}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold border backdrop-blur-sm ${getStatusStyle(row.status)}`}>
                    {row.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="p-1.5 text-slate-400 hover:text-primary-900 hover:bg-slate-100 rounded-lg transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100">
                    <MoreHorizontal className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}