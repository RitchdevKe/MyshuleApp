import React from "react";
import { BookOpen, Calendar, Download, Trophy, Target, FileText } from "lucide-react";

export default function EngagementPortfolioPage() {
  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl font-black text-slate-800">Student Portfolio Manager</h2>
          <p className="text-sm text-slate-500 font-medium">Manage and export comprehensive student development records.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors shadow-sm">
            <Download className="w-4 h-4" /> Export Batch
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm text-center">
        <div className="w-16 h-16 bg-primary-50 text-primary-900 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <BookOpen className="w-8 h-8" />
        </div>
        <h3 className="text-lg font-black text-slate-800 mb-2">Search for a Student</h3>
        <p className="text-sm text-slate-500 max-w-md mx-auto mb-6">
          Use the search bar in the header to lookup a student's passport and view their full portfolio.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto mt-8">
          <div className="p-5 border border-slate-100 rounded-2xl bg-slate-50 text-left">
            <Trophy className="w-5 h-5 text-amber-500 mb-3" />
            <h4 className="font-bold text-slate-800 text-sm mb-1">Achievements</h4>
            <p className="text-xs text-slate-500">Track academic and extracurricular milestones.</p>
          </div>
          <div className="p-5 border border-slate-100 rounded-2xl bg-slate-50 text-left">
            <Target className="w-5 h-5 text-indigo-500 mb-3" />
            <h4 className="font-bold text-slate-800 text-sm mb-1">Skills Tracking</h4>
            <p className="text-xs text-slate-500">Monitor development of soft and hard skills.</p>
          </div>
          <div className="p-5 border border-slate-100 rounded-2xl bg-slate-50 text-left">
            <FileText className="w-5 h-5 text-emerald-500 mb-3" />
            <h4 className="font-bold text-slate-800 text-sm mb-1">Recommendations</h4>
            <p className="text-xs text-slate-500">Log teacher notes and recommendation letters.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
