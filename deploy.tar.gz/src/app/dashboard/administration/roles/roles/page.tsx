"use client";

import React from "react";
import { Shield, Edit2, ShieldAlert } from "lucide-react";

export default function RolesTab() {
  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden p-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Role Directory */}
        <div className="lg:col-span-2 space-y-4">
          {[
            { name: "School Owner", type: "System Default", users: 2, access: "Full Platform" },
            { name: "Principal", type: "System Default", users: 1, access: "Full School Context" },
            { name: "Bursar", type: "System Default", users: 1, access: "Finance Module (Admin)" },
            { name: "Teacher", type: "System Default", users: 48, access: "Contextual (Assigned Classes)" },
            { name: "Deputy Bursar", type: "Custom Role", users: 2, access: "Finance Module (Restricted)" },
            { name: "Transport Coordinator", type: "Custom Role", users: 1, access: "Operations -> Transport" },
          ].map((role, idx) => (
            <div key={idx} className="bg-white border border-slate-200/60 rounded-2xl p-4 flex items-center justify-between hover:shadow-sm transition-shadow">
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  role.type === 'System Default' ? 'bg-primary-50 text-primary-600' : 'bg-emerald-50 text-emerald-600'
                }`}>
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-slate-800 flex items-center gap-2">
                    {role.name}
                    <span className={`px-2 py-0.5 text-[10px] font-black uppercase tracking-wider rounded ${
                      role.type === 'System Default' ? 'bg-primary-100 text-primary-700' : 'bg-emerald-100 text-emerald-700'
                    }`}>{role.type}</span>
                  </div>
                  <div className="text-xs font-medium text-slate-500 mt-1">
                    {role.users} Users • <span className="text-slate-400">{role.access}</span>
                  </div>
                </div>
              </div>
              <button className="p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700 rounded-lg transition-colors">
                <Edit2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        {/* Context Simulator Tool */}
        <div className="lg:col-span-1 bg-primary-900 rounded-2xl p-6 text-white shadow-lg h-fit border border-primary-800">
          <h3 className="text-sm font-black text-primary-200 uppercase tracking-wider mb-4 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-secondary-500" /> Access Simulator
          </h3>
          <p className="text-xs text-primary-100 mb-6 leading-relaxed">
            Test what a user can see and do based on their assigned roles and specific contexts.
          </p>
          
          <div className="space-y-4">
            <div>
              <label className="text-[10px] font-black uppercase tracking-wider text-primary-300 block mb-1">Select User</label>
              <select className="w-full bg-primary-800/50 border border-primary-700/50 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-secondary-500">
                <option>Jane Wanjiku (Teacher)</option>
              </select>
            </div>
            <div>
              <label className="text-[10px] font-black uppercase tracking-wider text-primary-300 block mb-1">Context</label>
              <select className="w-full bg-primary-800/50 border border-primary-700/50 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-secondary-500">
                <option>Grade 8A</option>
              </select>
            </div>
            <button className="w-full mt-4 bg-secondary-500 hover:bg-secondary-600 text-white font-bold py-2.5 rounded-xl text-sm transition-colors shadow-sm shadow-secondary-500/20">
              Run Simulation
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
