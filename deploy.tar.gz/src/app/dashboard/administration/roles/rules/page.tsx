"use client";

import React from "react";
import { Search, Plus, ArrowRight, CheckSquare } from "lucide-react";

export default function RulesPage() {
  const rules = [
    { id: 1, action: "Leave Request > 3 Days", trigger: "Teacher", approver: "Principal", status: "Active" },
    { id: 2, action: "Budget Reallocation", trigger: "Bursar", approver: "School Board", status: "Active" },
    { id: 3, action: "Final Grade Modification", trigger: "Teacher", approver: "Head of Academics", status: "Active" },
    { id: 4, action: "Asset Disposal", trigger: "Operations Mgr", approver: "Principal", status: "Inactive" },
  ];

  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden min-h-[500px]">
      <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50/50">
         <div className="flex items-center gap-2 w-full md:w-auto relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input type="text" placeholder="Search rules..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
         </div>
         <button className="flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20">
            <Plus className="w-4 h-4" />
            Create Rule
         </button>
      </div>

      <div className="p-6">
         <div className="grid grid-cols-1 gap-4">
            {rules.map((rule) => (
               <div key={rule.id} className="bg-white border border-slate-200 p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-primary-400 hover:shadow-sm transition-all group">
                  <div className="flex items-center gap-6 w-full max-w-2xl">
                     <div className="w-1/3">
                        <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">If (Trigger)</div>
                        <div className="font-bold text-sm text-slate-800 bg-slate-50 px-3 py-2 rounded-lg border border-slate-100">{rule.trigger}</div>
                     </div>
                     <div className="flex flex-col items-center justify-center shrink-0 w-24">
                        <span className="text-[10px] font-black uppercase tracking-wider text-primary-600 mb-1">Requests</span>
                        <ArrowRight className="w-5 h-5 text-slate-300" />
                     </div>
                     <div className="w-1/3">
                        <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">Action</div>
                        <div className="font-bold text-sm text-slate-800 bg-slate-50 px-3 py-2 rounded-lg border border-slate-100 truncate">{rule.action}</div>
                     </div>
                     <div className="flex flex-col items-center justify-center shrink-0 w-24">
                        <span className="text-[10px] font-black uppercase tracking-wider text-emerald-600 mb-1">Then</span>
                        <ArrowRight className="w-5 h-5 text-slate-300" />
                     </div>
                     <div className="w-1/3">
                        <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">Requires Approval</div>
                        <div className="font-bold text-sm text-primary-700 bg-primary-50 px-3 py-2 rounded-lg border border-primary-100">{rule.approver}</div>
                     </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                     <span className={`inline-flex items-center px-2.5 py-1 text-[10px] font-black uppercase tracking-wider rounded-md ${rule.status === 'Active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                        {rule.status}
                     </span>
                     <button className="px-4 py-2 text-xs font-bold bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl transition-colors">
                        Edit
                     </button>
                  </div>
               </div>
            ))}
         </div>
      </div>
    </div>
  );
}
