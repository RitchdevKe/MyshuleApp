"use client";

import React from "react";
import { Plus, Edit2, ShieldAlert } from "lucide-react";

export default function GradingPage() {
  return (
    <div className="p-6 md:p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h3 className="text-xl font-black text-slate-800">Grading Systems</h3>
          <p className="text-sm font-medium text-slate-500">Define how students are evaluated across different phases.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-slate-800 rounded-xl hover:bg-slate-700 transition-colors shadow-sm">
          <Plus className="w-4 h-4" /> New System
        </button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
        {/* CBC System */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden hover:border-slate-300 transition-all">
          <div className="p-5 border-b border-slate-100 flex justify-between items-start bg-slate-50/50">
            <div>
              <h4 className="font-black text-slate-800 text-lg">CBC (Competency Based)</h4>
              <p className="text-xs font-medium text-slate-500 mt-1">Applied to: Early Years & Primary</p>
            </div>
            <span className="bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-md">Default</span>
          </div>
          
          <div className="p-5 space-y-3">
            <div className="flex justify-between p-3 bg-slate-50 border border-slate-100 rounded-xl text-sm hover:bg-white hover:border-emerald-200 transition-colors">
              <span className="font-bold text-emerald-700">4 — Exceeding Expectation</span>
              <span className="font-black text-slate-400">EE</span>
            </div>
            <div className="flex justify-between p-3 bg-slate-50 border border-slate-100 rounded-xl text-sm hover:bg-white hover:border-indigo-200 transition-colors">
              <span className="font-bold text-indigo-700">3 — Meeting Expectation</span>
              <span className="font-black text-slate-400">ME</span>
            </div>
            <div className="flex justify-between p-3 bg-slate-50 border border-slate-100 rounded-xl text-sm hover:bg-white hover:border-amber-200 transition-colors">
              <span className="font-bold text-amber-700">2 — Approaching Expectation</span>
              <span className="font-black text-slate-400">AE</span>
            </div>
            <div className="flex justify-between p-3 bg-slate-50 border border-slate-100 rounded-xl text-sm hover:bg-white hover:border-rose-200 transition-colors">
              <span className="font-bold text-rose-700">1 — Below Expectation</span>
              <span className="font-black text-slate-400">BE</span>
            </div>
          </div>
        </div>

        {/* 8-4-4 Legacy System */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden hover:border-slate-300 transition-all">
          <div className="p-5 border-b border-slate-100 flex justify-between items-start bg-slate-50/50">
            <div>
              <h4 className="font-black text-slate-800 text-lg">8-4-4 (Percentage)</h4>
              <p className="text-xs font-medium text-slate-500 mt-1">Applied to: Secondary</p>
            </div>
            <button className="text-xs font-bold text-slate-400 hover:text-indigo-600 transition-colors flex items-center gap-1">
               <Edit2 className="w-3.5 h-3.5" /> Edit
            </button>
          </div>
          
          <div className="p-5 space-y-3">
            <div className="flex justify-between p-3 bg-slate-50 border border-slate-100 rounded-xl text-sm hover:bg-white transition-colors">
              <span className="font-bold text-slate-700">A (80% - 100%)</span>
              <span className="font-black text-slate-400">12 pts</span>
            </div>
            <div className="flex justify-between p-3 bg-slate-50 border border-slate-100 rounded-xl text-sm hover:bg-white transition-colors">
              <span className="font-bold text-slate-700">A- (75% - 79%)</span>
              <span className="font-black text-slate-400">11 pts</span>
            </div>
            <div className="flex justify-center p-2 text-sm opacity-60">
              <span className="font-bold text-slate-400">... B+, B, B-, C+, C ...</span>
            </div>
            <div className="flex justify-between p-3 bg-slate-50 border border-slate-100 rounded-xl text-sm hover:bg-white transition-colors">
              <span className="font-bold text-slate-700">E (0% - 29%)</span>
              <span className="font-black text-slate-400">1 pt</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3 mb-6">
        <h3 className="text-xl font-black text-slate-800">Term Weightings</h3>
        <div className="h-px bg-slate-200 flex-1 ml-4"></div>
      </div>
      
      <div className="max-w-2xl bg-slate-50 border border-slate-200 rounded-2xl p-6">
         <div className="flex items-start gap-4 mb-6">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center shrink-0">
               <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
               <h4 className="font-bold text-slate-800 text-sm">Strict Weighting Enforced</h4>
               <p className="text-xs text-slate-500 font-medium mt-1">Total weighting must always equal 100%. Adjustments here will affect final report card generation across all classes.</p>
            </div>
         </div>
         
         <div className="space-y-4">
            <div className="flex items-center gap-4">
               <div className="flex-1">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Assessment 1 (CAT 1)</label>
                  <input type="number" defaultValue="20" className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm" />
               </div>
               <div className="text-slate-400 font-black pt-5">%</div>
            </div>
            
            <div className="flex items-center gap-4">
               <div className="flex-1">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Assessment 2 (CAT 2)</label>
                  <input type="number" defaultValue="20" className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm" />
               </div>
               <div className="text-slate-400 font-black pt-5">%</div>
            </div>
            
            <div className="flex items-center gap-4">
               <div className="flex-1">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">End of Term Exam</label>
                  <input type="number" defaultValue="60" className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm" />
               </div>
               <div className="text-slate-400 font-black pt-5">%</div>
            </div>
         </div>
      </div>
    </div>
  );
}
