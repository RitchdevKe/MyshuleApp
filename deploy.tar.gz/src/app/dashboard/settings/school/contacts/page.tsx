"use client";

import React from "react";
import { Users, Mail, Phone, Globe, Plus, MapPin } from "lucide-react";

export default function ContactsPage() {
  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <div className="flex items-center gap-3 mb-8">
         <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center">
            <Users className="w-5 h-5" />
         </div>
         <div>
            <h3 className="text-xl font-black text-slate-800">Contact Information</h3>
            <p className="text-sm font-medium text-slate-500">Official channels for public and internal communications.</p>
         </div>
      </div>
      
      <div className="space-y-10">
        
        {/* Primary Contacts */}
        <div>
           <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">Primary School Contacts</h4>
           
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                 <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">General Email</label>
                 <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                    <input type="email" defaultValue="info@greenvalley.edu" className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 transition-all shadow-sm" />
                 </div>
              </div>
              <div>
                 <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Main Phone Line</label>
                 <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                    <input type="tel" defaultValue="+254 700 123 456" className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 transition-all shadow-sm" />
                 </div>
              </div>
              <div>
                 <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Secondary Phone</label>
                 <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                    <input type="tel" defaultValue="+254 711 987 654" className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 transition-all shadow-sm" />
                 </div>
              </div>
              <div>
                 <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Website URL</label>
                 <div className="relative">
                    <Globe className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                    <input type="url" defaultValue="https://www.greenvalley.edu" className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 transition-all shadow-sm" />
                 </div>
              </div>
           </div>
        </div>

        {/* Departmental Contacts */}
        <div>
           <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-2">
              <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider">Departmental Directory</h4>
              <button className="text-xs font-bold text-sky-600 hover:text-sky-800 flex items-center gap-1 transition-colors">
                 <Plus className="w-3 h-3" /> Add Department
              </button>
           </div>
           
           <div className="space-y-3">
              {[
                 { dept: "Admissions", email: "admissions@greenvalley.edu", phone: "+254 700 123 457", loc: "Block A, Room 101" },
                 { dept: "Finance & Billing", email: "finance@greenvalley.edu", phone: "+254 700 123 458", loc: "Admin Block, 2nd Floor" },
                 { dept: "IT Support", email: "support@greenvalley.edu", phone: "+254 700 123 459", loc: "Library Wing" },
              ].map((contact, i) => (
                 <div key={i} className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-slate-300 hover:bg-slate-100/50 transition-all">
                    <div>
                       <h5 className="font-bold text-slate-800 text-sm mb-1">{contact.dept}</h5>
                       <div className="flex flex-wrap gap-x-4 gap-y-1">
                          <span className="flex items-center gap-1 text-xs font-medium text-slate-600"><Mail className="w-3 h-3 text-slate-400" /> {contact.email}</span>
                          <span className="flex items-center gap-1 text-xs font-medium text-slate-600"><Phone className="w-3 h-3 text-slate-400" /> {contact.phone}</span>
                       </div>
                    </div>
                    <div className="flex items-center gap-1 text-xs font-bold text-slate-500 bg-white px-3 py-1.5 rounded-lg border border-slate-200">
                       <MapPin className="w-3 h-3" /> {contact.loc}
                    </div>
                 </div>
              ))}
           </div>
        </div>

      </div>
    </div>
  );
}
