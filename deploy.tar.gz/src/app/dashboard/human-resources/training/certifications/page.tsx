"use client";

import React from "react";
import { Search, Filter, AlertTriangle, ShieldCheck, Clock, Download, Award, ShieldAlert } from "lucide-react";

export default function CertificationsPage() {
  const certifications = [
    { id: "CERT-001", employee: "John Smith", type: "Health & Safety (OSHA)", status: "Active", expires: "Dec 31, 2025", lastRenewed: "Jan 15, 2024" },
    { id: "CERT-002", employee: "Emily Chen", type: "Pediatric First Aid", status: "Expiring Soon", expires: "Sep 10, 2024", lastRenewed: "Sep 10, 2022" },
    { id: "CERT-003", employee: "Sarah Connor", type: "Advanced Child Protection", status: "Active", expires: "Mar 22, 2026", lastRenewed: "Mar 22, 2024" },
    { id: "CERT-004", employee: "David Kim", type: "Food Handling License", status: "Expired", expires: "Jul 01, 2024", lastRenewed: "Jul 01, 2023" },
    { id: "CERT-005", employee: "Michael Ochieng", type: "ITIL Foundation", status: "Active", expires: "Never", lastRenewed: "Nov 05, 2021" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center justify-between">
           <div className="flex items-center gap-4">
             <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
                <ShieldCheck className="w-6 h-6" />
             </div>
             <div>
               <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Fully Compliant</p>
               <p className="text-2xl font-black text-slate-800">142</p>
             </div>
           </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center justify-between">
           <div className="flex items-center gap-4">
             <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl">
                <Clock className="w-6 h-6" />
             </div>
             <div>
               <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Expiring in 30 Days</p>
               <p className="text-2xl font-black text-slate-800">12</p>
             </div>
           </div>
        </div>
        <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl p-6 shadow-sm flex items-center justify-between">
           <div className="flex items-center gap-4">
             <div className="p-3 bg-rose-50 text-rose-600 rounded-2xl">
                <ShieldAlert className="w-6 h-6" />
             </div>
             <div>
               <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Expired</p>
               <p className="text-2xl font-black text-slate-800">3</p>
             </div>
           </div>
           <button className="text-sm font-bold text-rose-600 hover:bg-rose-50 px-3 py-1.5 rounded-lg transition-colors">Alert All</button>
        </div>
      </div>

      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4">
           <div className="flex items-center gap-2 w-full md:w-auto relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input type="text" placeholder="Search by employee or certification..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-slate-50 border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
           </div>
           <div className="flex gap-2">
              <select className="px-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-900 cursor-pointer">
                 <option>All Statuses</option>
                 <option>Active</option>
                 <option>Expiring Soon</option>
                 <option>Expired</option>
              </select>
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
                 <Filter className="w-4 h-4" />
                 Filter
              </button>
           </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Employee</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Certification Type</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Last Renewed</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Expiration Date</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {certifications.map((cert) => (
                <tr key={cert.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="py-4 px-6">
                    <span className="font-bold text-slate-800 text-sm">{cert.employee}</span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-2">
                       <Award className="w-4 h-4 text-slate-400" />
                       <span className="font-bold text-slate-800 text-sm">{cert.type}</span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm font-medium text-slate-500">{cert.lastRenewed}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`text-sm font-bold ${cert.status === 'Expired' ? 'text-rose-600' : cert.status === 'Expiring Soon' ? 'text-amber-600' : 'text-slate-800'}`}>
                       {cert.expires}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-lg ${
                      cert.status === 'Active' ? 'bg-emerald-50 text-emerald-600' : 
                      cert.status === 'Expiring Soon' ? 'bg-amber-50 text-amber-600' : 
                      'bg-rose-50 text-rose-600'
                    }`}>
                      {cert.status === 'Active' && <ShieldCheck className="w-3.5 h-3.5" />}
                      {cert.status === 'Expiring Soon' && <AlertTriangle className="w-3.5 h-3.5" />}
                      {cert.status === 'Expired' && <ShieldAlert className="w-3.5 h-3.5" />}
                      {cert.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                       <button className="p-2 text-primary-600 hover:bg-primary-50 rounded-lg transition-colors tooltip-trigger" title="Download Document">
                          <Download className="w-4 h-4" />
                       </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
