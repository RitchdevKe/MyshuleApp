import { redirect } from 'next/navigation';

export default function PayrollPage() {
  redirect('/dashboard/human-resources/payroll/runs');
}