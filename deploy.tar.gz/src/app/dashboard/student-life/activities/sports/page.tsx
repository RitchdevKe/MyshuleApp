"use client";

import React, { useState } from "react";
import { Activity, Search, MoreHorizontal, Plus } from "lucide-react";

export default function SportsPage() {
  const [searchTerm, setSearchTerm] = useState("");

  const teams = [
    { name: "Football U16 Boys", category: "Football", members: 22, nextFixture: "vs St. Mary's (Away)", coach: "Coach Waweru", status: "In Season" },
    { name: "Basketball Girls Varsity", category: "Basketball", members: 15, nextFixture: "vs Hillcrest (Home)", coach: "Ms. Njeri", status: "In Season" },
    { name: "Swimming Team", category: "Swimming", members: 30, nextFixture: "Regional Gala", coach: "Coach Otieno", status: "Training" },
    { name: "Rugby First XV", category: "Rugby", members: 28, nextFixture: "TBA", coach: "Coach Kamau", status: "Off Season" },
  ];

  return (
    <div className="p-8 space-y-6 bg-white/30 backdrop-blur-md rounded-3xl min-h-[600px]">
      
      {/* Header & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white/60 p-4 rounded-2xl border border-white/60 shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-slate-800">Sports Teams</h2>
            <p className="text-xs font-bold text-slate-500">Manage athletics, fixtures, and coaching staff</p>
          </div>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 transition-colors shadow-sm">
          <Plus className="w-4 h-4" /> New Team
        </button>
      </div>

      {/* Grid View */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-6 pt-4">
        {teams.map((team, idx) => (
          <div key={idx} className="bg-white/80 border border-slate-200/60 rounded-3xl p-6 shadow-sm hover:shadow-md hover:border-emerald-200 transition-all group">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center font-black text-xl border border-emerald-100">
                  {team.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-black text-slate-800 text-lg group-hover:text-emerald-700 transition-colors">{team.name}</h3>
                  <p className="text-[10px] font-black uppercase tracking-wider text-slate-400">{team.category}</p>
                </div>
              </div>
              <button className="text-slate-400 hover:text-emerald-600">
                <MoreHorizontal className="w-5 h-5" />
              </button>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-5 p-4 bg-slate-50 rounded-2xl border border-slate-100">
              <div>
                <div className="text-[10px] font-black uppercase text-slate-400 tracking-wider mb-1">Squad Size</div>
                <div className="text-xl font-black text-slate-700">{team.members}</div>
              </div>
              <div>
                <div className="text-[10px] font-black uppercase text-slate-400 tracking-wider mb-1">Status</div>
                <div className={`text-xs font-bold px-2 py-1 inline-block rounded-md ${
                  team.status === 'In Season' ? 'bg-emerald-100 text-emerald-700' : 
                  team.status === 'Training' ? 'bg-amber-100 text-amber-700' :
                  'bg-slate-200 text-slate-600'
                }`}>
                  {team.status}
                </div>
              </div>
            </div>

            <div className="space-y-2 text-sm font-medium text-slate-600">
              <div className="flex justify-between">
                <span className="text-slate-400">Next Fixture:</span>
                <span className="text-slate-700">{team.nextFixture}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Head Coach:</span>
                <span className="text-slate-700">{team.coach}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
