import { redirect } from 'next/navigation';

export default function AttendancePage() {
  redirect('/dashboard/human-resources/attendance/daily-log');
}