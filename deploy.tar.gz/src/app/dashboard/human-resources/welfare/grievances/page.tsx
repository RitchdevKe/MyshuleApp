"use client";

import React from "react";
import { Search, Filter, MessageSquareWarning, AlertCircle, AlertTriangle, ShieldCheck, Clock, CheckCircle2 } from "lucide-react";

export default function GrievancesPage() {
  const grievances = [
    { id: "GRV-2024-042", employee: "Anonymous", subject: "Unsafe walkway in South Wing", category: "Workplace Safety", severity: "High", date: "Aug 10, 2024", status: "Investigating" },
    { id: "GRV-2024-043", employee: "Jane Doe", subject: "Dispute over shift scheduling", category: "Management/Policy", severity: "Medium", date: "Aug 09, 2024", status: "Open" },
    { id: "GRV-2024-044", employee: "David Kim", subject: "Broken AC in Room 302", category: "Facilities", severity: "Low", date: "Aug 05, 2024", status: "Resolved" },
    { id: "GRV-2024-045", employee: "Anonymous", subject: "Inappropriate language by staff", category: "Harassment", severity: "High", date: "Aug 02, 2024", status: "Resolved" },
    { id: "GRV-2024-046", employee: "Michael Ochieng", subject: "Delayed expense reimbursement", category: "Finance/Payroll", severity: "Medium", date: "Aug 11, 2024", status: "Open" },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50/50">
           <div className="flex items-center gap-4">
              <div className="p-3 bg-primary-50 text-primary-600 rounded-2xl hidden md:block">
                 <MessageSquareWarning className="w-6 h-6" />
              </div>
              <div>
                 <h2 className="text-lg font-black text-slate-800">Grievance Resolution</h2>
                 <p className="text-sm font-medium text-slate-500">Track, investigate, and resolve employee complaints and workplace issues.</p>
              </div>
           </div>
           <div className="flex gap-4">
              <div className="text-center px-4 border-r border-slate-200">
                 <p className="text-2xl font-black text-slate-800">2</p>
                 <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Open</p>
              </div>
              <div className="text-center px-4 border-r border-slate-200">
                 <p className="text-2xl font-black text-amber-600">1</p>
                 <p className="text-[10px] font-bold text-amber-600 uppercase tracking-wider">Investigating</p>
              </div>
              <div className="text-center px-4">
                 <p className="text-2xl font-black text-emerald-600">12</p>
                 <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider">Resolved YTD</p>
              </div>
           </div>
        </div>

        <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4">
           <div className="flex items-center gap-2 w-full md:w-auto relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input type="text" placeholder="Search grievances..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-slate-50 border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
           </div>
           <div className="flex gap-2">
              <select className="px-4 py-2 bg-white border border-slate-200/60 rounded-xl text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-900 cursor-pointer">
                 <option>All Severities</option>
                 <option>High</option>
                 <option>Medium</option>
                 <option>Low</option>
              </select>
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
                 <Filter className="w-4 h-4" />
                 More Filters
              </button>
           </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">ID & Date</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Reporter</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Subject & Category</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Severity</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {grievances.map((g) => (
                <tr key={g.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="py-4 px-6">
                    <span className="font-bold text-slate-700 text-sm">{g.id}</span>
                    <p className="text-[10px] font-bold text-slate-400 mt-0.5">{g.date}</p>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`font-bold text-sm ${g.employee === 'Anonymous' ? 'text-slate-400 italic' : 'text-slate-800'}`}>{g.employee}</span>
                  </td>
                  <td className="py-4 px-6">
                    <p className="font-bold text-slate-800 text-sm">{g.subject}</p>
                    <p className="text-xs text-slate-500 font-medium">{g.category}</p>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center gap-1.5 px-2 py-1 text-[10px] font-black uppercase tracking-wider rounded-md ${
                      g.severity === 'High' ? 'bg-rose-50 text-rose-600' : 
                      g.severity === 'Medium' ? 'bg-amber-50 text-amber-600' : 
                      'bg-slate-100 text-slate-600'
                    }`}>
                      {g.severity === 'High' && <AlertCircle className="w-3 h-3" />}
                      {g.severity === 'Medium' && <AlertTriangle className="w-3 h-3" />}
                      {g.severity}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-lg ${
                      g.status === 'Resolved' ? 'bg-emerald-50 text-emerald-600' : 
                      g.status === 'Investigating' ? 'bg-amber-50 text-amber-600' : 
                      'bg-blue-50 text-blue-600'
                    }`}>
                      {g.status === 'Resolved' && <CheckCircle2 className="w-3.5 h-3.5" />}
                      {g.status === 'Investigating' && <Search className="w-3.5 h-3.5" />}
                      {g.status === 'Open' && <AlertCircle className="w-3.5 h-3.5" />}
                      {g.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                     <button className="text-sm font-bold text-primary-600 hover:text-primary-800 hover:bg-primary-50 px-3 py-1.5 rounded-lg transition-colors">Manage</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
