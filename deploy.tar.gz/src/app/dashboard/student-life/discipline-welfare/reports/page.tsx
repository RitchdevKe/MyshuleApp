"use client";

import React, { useState } from "react";
import { Download, Filter, FileText, Calendar, PieChart } from "lucide-react";

export default function DisciplineReportsPage() {
  const [reportType, setReportType] = useState("Incident Summary");
  const [dateRange, setDateRange] = useState("Term 1 (Sep - Dec)");

  return (
    <div className="p-8 space-y-8 bg-white/30 backdrop-blur-md rounded-3xl min-h-[600px]">
      
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 bg-white/60 p-6 rounded-3xl border border-white/60 shadow-sm">
        <div className="space-y-4 flex-1">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-slate-800">Generate Reports</h2>
              <p className="text-xs font-bold text-slate-500">Export discipline and welfare data</p>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 space-y-1.5">
              <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Report Type</label>
              <select 
                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
              >
                <option>Incident Summary</option>
                <option>Student Welfare Watchlist</option>
                <option>Intervention Efficacy</option>
                <option>Demographic Analysis</option>
              </select>
            </div>
            <div className="flex-1 space-y-1.5">
              <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 ml-1">Date Range</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <select 
                  className="w-full pl-9 bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  value={dateRange}
                  onChange={(e) => setDateRange(e.target.value)}
                >
                  <option>Term 1 (Sep - Dec)</option>
                  <option>Term 2 (Jan - Apr)</option>
                  <option>Term 3 (May - Jul)</option>
                  <option>Last 30 Days</option>
                  <option>Custom Range...</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-5 py-3 text-sm font-bold text-indigo-700 bg-indigo-50 rounded-xl border border-indigo-200 hover:bg-indigo-100 transition-colors shadow-sm">
            <Filter className="w-4 h-4" /> More Filters
          </button>
          <button className="flex items-center gap-2 px-6 py-3 text-sm font-bold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-sm shadow-indigo-600/20">
            <Download className="w-4 h-4" /> Export PDF
          </button>
        </div>
      </div>

      {/* Preview Area */}
      <div className="bg-white border border-slate-200/60 rounded-3xl p-8 shadow-sm">
        <div className="flex items-center justify-between mb-8 border-b border-slate-100 pb-4">
          <div>
            <h3 className="text-xl font-black text-slate-800">{reportType}</h3>
            <p className="text-sm font-medium text-slate-500 mt-1">{dateRange} • Generated on {new Date().toLocaleDateString()}</p>
          </div>
          <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center border border-slate-100">
            <PieChart className="w-6 h-6 text-slate-400" />
          </div>
        </div>

        {/* Mock Report Content */}
        <div className="space-y-8 opacity-70">
          <div className="grid grid-cols-3 gap-6">
            <div className="h-24 bg-slate-50 rounded-2xl border border-slate-100 p-4">
              <div className="w-16 h-4 bg-slate-200 rounded mb-4"></div>
              <div className="w-24 h-8 bg-slate-200 rounded"></div>
            </div>
            <div className="h-24 bg-slate-50 rounded-2xl border border-slate-100 p-4">
              <div className="w-20 h-4 bg-slate-200 rounded mb-4"></div>
              <div className="w-16 h-8 bg-slate-200 rounded"></div>
            </div>
            <div className="h-24 bg-slate-50 rounded-2xl border border-slate-100 p-4">
              <div className="w-12 h-4 bg-slate-200 rounded mb-4"></div>
              <div className="w-20 h-8 bg-slate-200 rounded"></div>
            </div>
          </div>

          <div className="h-64 bg-slate-50 rounded-3xl border border-slate-100 p-6 flex items-end justify-around pb-12 relative">
            <div className="absolute top-6 left-6 w-32 h-4 bg-slate-200 rounded"></div>
            <div className="w-12 bg-indigo-200 rounded-t-lg h-[40%]"></div>
            <div className="w-12 bg-indigo-300 rounded-t-lg h-[60%]"></div>
            <div className="w-12 bg-indigo-400 rounded-t-lg h-[30%]"></div>
            <div className="w-12 bg-indigo-500 rounded-t-lg h-[80%]"></div>
            <div className="w-12 bg-indigo-600 rounded-t-lg h-[50%]"></div>
            <div className="w-12 bg-indigo-700 rounded-t-lg h-[70%]"></div>
          </div>

          <div className="space-y-3">
            <div className="h-10 bg-slate-100 rounded-xl w-full"></div>
            <div className="h-10 bg-slate-50 rounded-xl w-full"></div>
            <div className="h-10 bg-slate-50 rounded-xl w-full"></div>
            <div className="h-10 bg-slate-50 rounded-xl w-full"></div>
          </div>
        </div>

      </div>
    </div>
  );
}
