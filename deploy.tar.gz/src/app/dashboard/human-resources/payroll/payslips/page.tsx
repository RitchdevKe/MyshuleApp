"use client";

import React from "react";
import { FileText, Search, Filter, Download, Mail, Eye, Calendar } from "lucide-react";

export default function PayslipsPage() {
  const payslips = [
    { id: "PS-2024-07-001", employee: "Jane Doe", period: "July 2024", netPay: "$4,120.00", status: "Generated", date: "Jul 28, 2024" },
    { id: "PS-2024-07-005", employee: "Sarah Connor", period: "July 2024", netPay: "$5,850.00", status: "Sent", date: "Jul 28, 2024" },
    { id: "PS-2024-07-002", employee: "John Smith", period: "July 2024", netPay: "$3,640.00", status: "Sent", date: "Jul 28, 2024" },
    { id: "PS-2024-07-006", employee: "David Kim", period: "July 2024", netPay: "$2,100.00", status: "Generated", date: "Jul 28, 2024" },
    { id: "PS-2024-07-004", employee: "Michael Ochieng", period: "July 2024", netPay: "$2,850.00", status: "Viewed", date: "Jul 28, 2024" },
  ];

  return (
    <div className="space-y-6">
      {/* Top Controls */}
      <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-4">
         <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="p-3 bg-primary-50 text-primary-600 rounded-2xl hidden md:block">
               <FileText className="w-5 h-5" />
            </div>
            <div>
               <h2 className="text-lg font-black text-slate-800">Payslip Archive</h2>
               <p className="text-sm font-medium text-slate-500">View and manage employee payslips</p>
            </div>
         </div>
         <div className="flex gap-2 w-full md:w-auto">
            <select className="px-4 py-2 bg-slate-50 border border-slate-200/60 rounded-xl text-sm font-bold text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-900 cursor-pointer w-full md:w-auto">
               <option>July 2024</option>
               <option>June 2024</option>
               <option>May 2024</option>
            </select>
            <button className="flex items-center justify-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-sm shadow-primary-900/20 whitespace-nowrap">
               <Download className="w-4 h-4" />
               Export All
            </button>
         </div>
      </div>

      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200/60 flex flex-col md:flex-row justify-between items-center gap-4">
           <div className="flex items-center gap-2 w-full md:w-auto relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input type="text" placeholder="Search by employee or ID..." className="w-full md:w-80 pl-9 pr-4 py-2 bg-slate-50 border border-slate-200/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-900" />
           </div>
           <div className="flex gap-2">
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
                 <Filter className="w-4 h-4" />
                 Filter
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
                 <Mail className="w-4 h-4" />
                 Email Selected
              </button>
           </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="py-4 px-6 w-12"><input type="checkbox" className="rounded border-slate-300 text-primary-600 focus:ring-primary-900" /></th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Payslip ID</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Employee</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Period</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Net Pay</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="py-4 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {payslips.map((ps) => (
                <tr key={ps.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="py-4 px-6"><input type="checkbox" className="rounded border-slate-300 text-primary-600 focus:ring-primary-900" /></td>
                  <td className="py-4 px-6">
                    <span className="font-bold text-slate-700 text-sm">{ps.id}</span>
                  </td>
                  <td className="py-4 px-6">
                    <p className="font-bold text-slate-800 text-sm">{ps.employee}</p>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-2 text-sm font-bold text-slate-600">
                       <Calendar className="w-4 h-4 text-slate-400" /> {ps.period}
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm font-black text-slate-800">{ps.netPay}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-lg ${
                      ps.status === 'Sent' ? 'bg-blue-50 text-blue-600' : 
                      ps.status === 'Viewed' ? 'bg-emerald-50 text-emerald-600' : 
                      'bg-slate-100 text-slate-600'
                    }`}>
                      {ps.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                       <button className="p-2 text-primary-600 hover:bg-primary-50 rounded-lg transition-colors tooltip-trigger" title="View Payslip">
                          <Eye className="w-4 h-4" />
                       </button>
                       <button className="p-2 text-primary-600 hover:bg-primary-50 rounded-lg transition-colors tooltip-trigger" title="Download PDF">
                          <Download className="w-4 h-4" />
                       </button>
                       <button className="p-2 text-primary-600 hover:bg-primary-50 rounded-lg transition-colors tooltip-trigger" title="Email to Employee">
                          <Mail className="w-4 h-4" />
                       </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
