"use client";

import React, { useState } from "react";
import { Palette, CheckCircle2, Type, LayoutTemplate } from "lucide-react";

export default function BrandingPage() {
  const [primaryColor, setPrimaryColor] = useState("#0f172a");
  const [secondaryColor, setSecondaryColor] = useState("#6366f1");

  const colorPresets = [
     { p: "#0f172a", s: "#6366f1", name: "Slate & Indigo (Default)" },
     { p: "#065f46", s: "#10b981", name: "Forest & Emerald" },
     { p: "#7f1d1d", s: "#ef4444", name: "Crimson & Red" },
     { p: "#1e3a8a", s: "#3b82f6", name: "Navy & Blue" },
  ];

  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <div className="flex items-center gap-3 mb-8">
         <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
            <Palette className="w-5 h-5" />
         </div>
         <div>
            <h3 className="text-xl font-black text-slate-800">Branding & Colors</h3>
            <p className="text-sm font-medium text-slate-500">Customize the portal theme and document styling.</p>
         </div>
      </div>
      
      <div className="space-y-10">
        
        {/* Brand Colors */}
        <div>
           <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">Brand Colors</h4>
           
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
              {/* Primary Color Picker */}
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100">
                 <div className="flex justify-between items-center mb-3">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Primary Color (Nav & Accents)</label>
                    <span className="text-xs font-mono font-bold text-slate-800 bg-white px-2 py-1 rounded shadow-sm">{primaryColor}</span>
                 </div>
                 <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full shadow-inner border border-black/10" style={{ backgroundColor: primaryColor }}></div>
                    <input 
                       type="color" 
                       value={primaryColor}
                       onChange={(e) => setPrimaryColor(e.target.value)}
                       className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                    />
                 </div>
              </div>

              {/* Secondary Color Picker */}
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100">
                 <div className="flex justify-between items-center mb-3">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-500">Secondary Color (Active States)</label>
                    <span className="text-xs font-mono font-bold text-slate-800 bg-white px-2 py-1 rounded shadow-sm">{secondaryColor}</span>
                 </div>
                 <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full shadow-inner border border-black/10" style={{ backgroundColor: secondaryColor }}></div>
                    <input 
                       type="color" 
                       value={secondaryColor}
                       onChange={(e) => setSecondaryColor(e.target.value)}
                       className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                    />
                 </div>
              </div>
           </div>

           <div>
              <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-3">Quick Presets</label>
              <div className="flex flex-wrap gap-3">
                 {colorPresets.map((preset, i) => (
                    <button 
                       key={i}
                       onClick={() => { setPrimaryColor(preset.p); setSecondaryColor(preset.s); }}
                       className={`flex items-center gap-3 px-4 py-2 bg-white border rounded-xl hover:bg-slate-50 transition-all ${
                          primaryColor === preset.p && secondaryColor === preset.s ? 'border-indigo-500 ring-2 ring-indigo-500/20' : 'border-slate-200'
                       }`}
                    >
                       <div className="flex -space-x-2">
                          <div className="w-5 h-5 rounded-full border-2 border-white" style={{ backgroundColor: preset.p }}></div>
                          <div className="w-5 h-5 rounded-full border-2 border-white" style={{ backgroundColor: preset.s }}></div>
                       </div>
                       <span className="text-xs font-bold text-slate-700">{preset.name}</span>
                       {primaryColor === preset.p && secondaryColor === preset.s && (
                          <CheckCircle2 className="w-4 h-4 text-indigo-500 ml-1" />
                       )}
                    </button>
                 ))}
              </div>
           </div>
        </div>

        {/* Typography */}
        <div>
           <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2 flex items-center gap-2">
              <Type className="w-4 h-4" /> Typography
           </h4>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                 <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Heading Font</label>
                 <select className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm appearance-none">
                    <option value="inter">Inter (Default)</option>
                    <option value="roboto">Roboto</option>
                    <option value="poppins">Poppins</option>
                    <option value="merriweather">Merriweather (Serif)</option>
                 </select>
              </div>
              <div>
                 <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Body Font</label>
                 <select className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm appearance-none">
                    <option value="inter">Inter (Default)</option>
                    <option value="roboto">Roboto</option>
                    <option value="opensans">Open Sans</option>
                 </select>
              </div>
           </div>
        </div>

        {/* Document Templates */}
        <div>
           <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2 flex items-center gap-2">
              <LayoutTemplate className="w-4 h-4" /> Document Templates
           </h4>
           <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                 { name: "Report Cards", active: true },
                 { name: "Fee Invoices", active: true },
                 { name: "Certificates", active: false },
              ].map((doc, i) => (
                 <div key={i} className={`p-4 border rounded-2xl flex items-center justify-between cursor-pointer transition-all ${
                    doc.active ? 'border-indigo-500 bg-indigo-50/30' : 'border-slate-200 bg-white hover:bg-slate-50'
                 }`}>
                    <span className="text-sm font-bold text-slate-700">{doc.name}</span>
                    <div className={`w-10 h-5 rounded-full relative transition-colors ${doc.active ? 'bg-indigo-500' : 'bg-slate-300'}`}>
                       <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${doc.active ? 'right-1' : 'left-1'}`}></div>
                    </div>
                 </div>
              ))}
           </div>
           <p className="text-xs font-medium text-slate-500 mt-3">Enable custom branding overrides on generated PDF documents.</p>
        </div>

      </div>
    </div>
  );
}
