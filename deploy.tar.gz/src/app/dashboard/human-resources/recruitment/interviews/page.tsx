"use client";

import React from "react";
import { CalendarDays, Plus, Clock, MapPin, Video, User, CheckCircle2, XCircle } from "lucide-react";

export default function InterviewsPage() {
  const upcomingInterviews = [
    {
      candidate: "Rachel Green",
      role: "IT Support Technician",
      date: "Today, 10:00 AM",
      type: "Virtual",
      duration: "45 mins",
      interviewers: ["Sarah Palmer", "Mike Tech"],
      status: "Upcoming"
    },
    {
      candidate: "Ahmed Patel",
      role: "Senior Math Teacher",
      date: "Today, 2:30 PM",
      type: "In-Person",
      duration: "60 mins",
      interviewers: ["Dr. James Walker"],
      status: "Upcoming"
    },
    {
      candidate: "Emily Watson",
      role: "School Nurse",
      date: "Tomorrow, 9:00 AM",
      type: "In-Person",
      duration: "30 mins",
      interviewers: ["Nurse Joy", "HR Manager"],
      status: "Confirmed"
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-4">
         <h2 className="text-lg font-black text-slate-800 ml-2">Interview Schedule</h2>
         <div className="flex gap-3">
            <div className="flex bg-slate-100 rounded-xl p-1">
               <button className="px-4 py-1.5 text-sm font-bold bg-white text-slate-800 shadow-sm rounded-lg">Upcoming</button>
               <button className="px-4 py-1.5 text-sm font-bold text-slate-500 hover:text-slate-700 rounded-lg">Past</button>
            </div>
            <button className="inline-flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-md shadow-primary-900/20">
              <Plus className="w-4 h-4" />
              Schedule Interview
            </button>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
         {/* Calendar/Date Picker Placeholder Area */}
         <div className="lg:col-span-1 space-y-6">
            <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-6 text-center">
               <h3 className="font-bold text-slate-800 mb-4">Select Date</h3>
               {/* Mock Calendar Grid */}
               <div className="grid grid-cols-7 gap-1 text-sm mb-2">
                  {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map(day => (
                     <div key={day} className="text-xs font-bold text-slate-400 py-1">{day}</div>
                  ))}
                  {Array.from({length: 31}).map((_, i) => (
                     <button key={i} className={`p-2 rounded-xl flex items-center justify-center font-medium ${i === 14 ? 'bg-secondary-500 text-white shadow-sm' : 'hover:bg-slate-100 text-slate-700'}`}>
                        {i + 1}
                     </button>
                  ))}
               </div>
            </div>
            
            <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-6">
               <h3 className="font-bold text-slate-800 mb-4">Today's Stats</h3>
               <div className="space-y-4">
                  <div className="flex justify-between items-center">
                     <span className="text-sm font-medium text-slate-500">Scheduled</span>
                     <span className="text-sm font-bold text-slate-800">4</span>
                  </div>
                  <div className="flex justify-between items-center">
                     <span className="text-sm font-medium text-slate-500">Completed</span>
                     <span className="text-sm font-bold text-emerald-600">2</span>
                  </div>
                  <div className="flex justify-between items-center">
                     <span className="text-sm font-medium text-slate-500">Cancellations</span>
                     <span className="text-sm font-bold text-rose-500">0</span>
                  </div>
               </div>
            </div>
         </div>

         {/* Schedule List */}
         <div className="lg:col-span-2 space-y-4">
            {upcomingInterviews.map((interview, i) => (
               <div key={i} className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start gap-4">
                     <div className="p-3 bg-primary-50 text-primary-600 rounded-2xl">
                        <User className="w-6 h-6" />
                     </div>
                     <div>
                        <h4 className="text-lg font-black text-slate-800">{interview.candidate}</h4>
                        <p className="text-sm font-bold text-primary-600 mb-2">{interview.role}</p>
                        
                        <div className="flex flex-wrap items-center gap-4 text-xs font-medium text-slate-500">
                           <div className="flex items-center gap-1.5">
                              <Clock className="w-3.5 h-3.5" />
                              {interview.date} ({interview.duration})
                           </div>
                           <div className="flex items-center gap-1.5">
                              {interview.type === 'Virtual' ? <Video className="w-3.5 h-3.5" /> : <MapPin className="w-3.5 h-3.5" />}
                              {interview.type}
                           </div>
                        </div>
                     </div>
                  </div>
                  
                  <div className="flex flex-col md:items-end gap-3 border-t md:border-t-0 md:border-l border-slate-100 pt-4 md:pt-0 md:pl-6">
                     <div className="flex items-center gap-2">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${interview.status === 'Upcoming' ? 'bg-amber-50 text-amber-600' : 'bg-emerald-50 text-emerald-600'}`}>
                           {interview.status}
                        </span>
                     </div>
                     <div className="flex items-center gap-2">
                        <button className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-xl transition-colors tooltip-trigger" title="Mark as Passed">
                           <CheckCircle2 className="w-5 h-5" />
                        </button>
                        <button className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition-colors tooltip-trigger" title="Mark as Rejected">
                           <XCircle className="w-5 h-5" />
                        </button>
                        <button className="px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white text-sm font-bold rounded-xl transition-colors shadow-sm">
                           Join / Details
                        </button>
                     </div>
                  </div>
               </div>
            ))}
         </div>
      </div>
    </div>
  );
}
