import { redirect } from 'next/navigation';

export default function ProcurementPage() {
  redirect('/dashboard/operations/procurement/requests');
}