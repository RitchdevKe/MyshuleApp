import React from "react";
import { Heart, Search, Filter, Plus, Clock, CheckCircle2 } from "lucide-react";

export default function EngagementServicePage() {
  const serviceRecords = [
    { id: 1, student: "John Kamau", grade: "11A", activity: "Tree Planting Initiative", hours: 24, status: "Verified", date: "Oct 12, 2025" },
    { id: 2, student: "Jane Doe", grade: "10A", activity: "Local Orphanage Visit", hours: 8, status: "Pending", date: "Nov 02, 2025" },
    { id: 3, student: "Peter Otieno", grade: "11C", activity: "Beach Clean-up", hours: 12, status: "Verified", date: "Sep 28, 2025" },
  ];

  return (
    <div className="p-6">
      
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search service records..." 
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-secondary-500/20 focus:border-secondary-500 transition-all shadow-sm"
          />
        </div>
        
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors shadow-sm">
            <Filter className="w-4 h-4" /> Filter
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-white bg-primary-900 rounded-xl hover:bg-primary-800 transition-colors shadow-sm">
            <Plus className="w-4 h-4" /> Log Hours
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="px-6 py-4">Student</th>
                <th className="px-6 py-4">Activity</th>
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4">Hours</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {serviceRecords.map((record) => (
                <tr key={record.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary-50 flex items-center justify-center text-primary-900 font-bold text-xs">
                        {record.student.charAt(0)}
                      </div>
                      <div>
                        <div className="font-bold text-slate-800">{record.student}</div>
                        <div className="text-[10px] text-slate-500">{record.grade}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 font-medium text-slate-700">{record.activity}</td>
                  <td className="px-6 py-4 text-slate-500">{record.date}</td>
                  <td className="px-6 py-4">
                    <span className="flex items-center gap-1.5 font-bold text-slate-700">
                      <Clock className="w-4 h-4 text-slate-400" /> {record.hours}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    {record.status === 'Verified' ? (
                      <span className="px-2.5 py-1 bg-green-50 text-green-700 text-[10px] font-black uppercase tracking-wider rounded-lg border border-green-200 flex items-center gap-1 w-max">
                        <CheckCircle2 className="w-3 h-3" /> Verified
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 bg-amber-50 text-amber-700 text-[10px] font-black uppercase tracking-wider rounded-lg border border-amber-200 w-max inline-block">
                        Pending
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="text-secondary-600 hover:text-secondary-700 font-bold text-xs">View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
