import React from "react";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";
import CommandPalette from "@/components/layout/CommandPalette";
import { SidebarProvider } from "@/contexts/SidebarContext";
import { SchoolLevelProvider } from "@/contexts/SchoolLevelContext";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <SchoolLevelProvider>
      <SidebarProvider>
        <div className="flex flex-col h-screen min-h-screen overflow-hidden bg-slate-100 dark:bg-slate-900">
          <Header />
          <div className="flex flex-1 overflow-hidden relative">
            <Sidebar />
            <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 transition-all duration-300">
              {children}
            </main>
          </div>
          <CommandPalette />
        </div>
      </SidebarProvider>
    </SchoolLevelProvider>
  );
}
