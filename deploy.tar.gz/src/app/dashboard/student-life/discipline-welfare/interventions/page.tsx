"use client";

import React from "react";
import { HeartHandshake, CheckCircle2, Search, Filter, Plus, Clock } from "lucide-react";

export default function InterventionsPage() {
  const interventions = [
    { student: "Brian Mwangi", grade: "Grade 10", issue: "Repeated absenteeism", goal: "Attendance > 90%", action: "Mentor Assigned", status: "Active", progress: 60, nextReview: "Oct 15, 2026", staff: "Mr. Omondi" },
    { student: "Mary Wanjiku", grade: "Grade 9", issue: "Academic concern", goal: "Improve Math scores", action: "Counselling Referral", status: "Monitoring", progress: 30, nextReview: "Oct 20, 2026", staff: "Mrs. Kariuki" },
    { student: "John Kamau", grade: "Grade 11", issue: "Disruptive behavior", goal: "0 incidents in 4 weeks", action: "Behavior Contract", status: "Active", progress: 85, nextReview: "Oct 12, 2026", staff: "Mr. Kiprono" },
    { student: "Alice Wambui", grade: "Grade 8", issue: "Peer conflicts", goal: "Mediation sessions completed", action: "Group Therapy", status: "Completed", progress: 100, nextReview: "Completed", staff: "Ms. Achieng" },
  ];

  return (
    <div className="p-8 space-y-6 bg-white/30 backdrop-blur-md rounded-3xl min-h-[600px]">
      
      {/* Header & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white/60 p-4 rounded-2xl border border-white/60 shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center">
            <HeartHandshake className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-slate-800">Support Interventions</h2>
            <p className="text-xs font-bold text-slate-500">Track student behavioral and welfare support plans</p>
          </div>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-sm">
          <Plus className="w-4 h-4" /> New Intervention
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {interventions.map((inv, idx) => (
          <div key={idx} className="bg-white/80 border border-slate-200/60 rounded-3xl p-5 shadow-sm hover:shadow-md hover:border-indigo-200 transition-all group">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-black text-slate-800 text-lg group-hover:text-indigo-700 transition-colors">{inv.student}</h3>
                <p className="text-xs font-bold text-slate-500">{inv.grade} • {inv.staff}</p>
              </div>
              <span className={`px-2.5 py-1 text-[10px] font-black uppercase tracking-wider border rounded shadow-sm ${
                inv.status === 'Completed' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' :
                inv.status === 'Monitoring' ? 'bg-amber-50 text-amber-600 border-amber-200' :
                'bg-indigo-50 text-indigo-600 border-indigo-100'
              }`}>
                {inv.status}
              </span>
            </div>
            
            <div className="space-y-3 mb-5">
              <div>
                <div className="text-[10px] font-black uppercase text-slate-400 tracking-wider mb-0.5">Issue</div>
                <div className="text-sm font-medium text-slate-700 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100">{inv.issue}</div>
              </div>
              <div>
                <div className="text-[10px] font-black uppercase text-slate-400 tracking-wider mb-0.5">Goal</div>
                <div className="text-sm font-medium text-slate-700 bg-emerald-50/50 px-3 py-1.5 rounded-lg border border-emerald-100/50 flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                  {inv.goal}
                </div>
              </div>
            </div>

            <div className="mb-4">
              <div className="flex justify-between items-center text-xs font-bold mb-1">
                <span className="text-slate-500 uppercase tracking-wider">Progress</span>
                <span className="text-indigo-600">{inv.progress}%</span>
              </div>
              <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full ${inv.progress === 100 ? 'bg-emerald-500' : 'bg-indigo-500'}`}
                  style={{ width: `${inv.progress}%` }}
                ></div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-100">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600 bg-slate-50 px-2 py-1 rounded-md border border-slate-100">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                Review: {inv.nextReview}
              </div>
              <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors">
                View Details
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
