"use client";

import React, { useState } from "react";
import { Search, Plus, Filter, Users, ShieldCheck, UserCheck, Activity, MoreHorizontal, Settings, Building2, Key } from "lucide-react";

const USERS = [
  { id: "USR-001", name: "David Omondi",    initials: "DO", role: "Super Admin",   email: "david@myshule.com",  branch: "All Branches",  lastActive: "Today, 08:30 EAT", status: "Active",    accessLevel: "Full" },
  { id: "USR-002", name: "Jane Kariuki",    initials: "JK", role: "Head Teacher",  email: "jane@myshule.com",   branch: "Main Campus",   lastActive: "Today, 07:15 EAT", status: "Active",    accessLevel: "Branch Admin" },
  { id: "USR-003", name: "Mary Wanjiku",    initials: "MW", role: "Secretary",     email: "mary@myshule.com",   branch: "West Wing",     lastActive: "Yesterday",        status: "Active",    accessLevel: "Standard" },
  { id: "USR-004", name: "Peter Kamau",     initials: "PK", role: "Teacher",       email: "peter@myshule.com",  branch: "Main Campus",   lastActive: "2 days ago",       status: "Inactive",  accessLevel: "Standard" },
  { id: "USR-005", name: "Fatuma Ali",      initials: "FA", role: "Head Teacher",  email: "fatuma@myshule.com", branch: "Eastleigh Prep",lastActive: "Today, 09:00 EAT", status: "Active",    accessLevel: "Branch Admin" },
  { id: "USR-006", name: "Finance Dept",    initials: "FD", role: "Bursar",        email: "finance@myshule.com",branch: "All Branches",  lastActive: "Today, 10:45 EAT", status: "Active",    accessLevel: "Finance Admin" },
];

const roleColors: Record<string, string> = {
  "Super Admin":   "bg-rose-50 text-rose-700 border-rose-200",
  "Head Teacher":  "bg-indigo-50 text-indigo-700 border-indigo-200",
  "Secretary":     "bg-sky-50 text-sky-700 border-sky-200",
  "Teacher":       "bg-emerald-50 text-emerald-700 border-emerald-200",
  "Bursar":        "bg-amber-50 text-amber-700 border-amber-200",
};

const avatarGrads = [
  "from-primary-700 to-primary-900", "from-secondary-500 to-secondary-700",
  "from-indigo-500 to-violet-600",   "from-emerald-500 to-teal-600",
  "from-amber-500 to-orange-500",    "from-sky-500 to-blue-600",
];

export default function UsersPage() {
  const [search, setSearch] = useState("");

  const filtered = USERS.filter(u => 
    u.name.toLowerCase().includes(search.toLowerCase()) || 
    u.role.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Users",      value: "156",   icon: Users,       color: "from-primary-600 to-primary-800" },
          { label: "Active Today",     value: "84",    icon: Activity,    color: "from-emerald-500 to-teal-600" },
          { label: "Super Admins",     value: "3",     icon: ShieldCheck, color: "from-rose-500 to-red-600" },
          { label: "Pending Invites",  value: "12",    icon: UserCheck,   color: "from-amber-500 to-orange-500" },
        ].map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className={`bg-gradient-to-br ${c.color} rounded-2xl p-4 text-white shadow-md flex items-center gap-3`}>
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-black leading-tight">{c.value}</p>
                <p className="text-xs font-bold text-white/80">{c.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Table Card */}
      <div className="bg-white/60 backdrop-blur-xl border border-white/80 rounded-3xl shadow-lg overflow-hidden">
        {/* Toolbar */}
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-white/80">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search users or roles..."
              className="pl-9 pr-4 py-2 text-sm font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-400 transition-all w-64 placeholder:text-slate-400"
            />
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 shadow-sm">
              <Filter className="w-4 h-4" /> Filter
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-primary-900 hover:bg-primary-800 rounded-xl shadow-md shadow-primary-900/20 hover:-translate-y-0.5 transition-all">
              <Plus className="w-4 h-4" /> Add User
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-primary-900 to-primary-800 text-white">
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">User Details</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Role & Access</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Branch</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Last Active</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider">Status</th>
                <th className="px-5 py-3.5 text-[11px] font-black uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((u, i) => {
                const isActive = u.status === "Active";
                
                return (
                  <tr key={u.id} className="hover:bg-primary-50/40 border-l-4 border-transparent hover:border-l-secondary-500 transition-all group">
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${avatarGrads[i % avatarGrads.length]} flex items-center justify-center text-white text-xs font-black shadow-sm flex-shrink-0`}>
                          {u.initials}
                        </div>
                        <div>
                          <p className="font-bold text-slate-800 text-sm">{u.name}</p>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <span className="text-[10px] font-black text-primary-700 bg-primary-50 px-1.5 py-0.5 rounded">{u.id}</span>
                            <span className="text-[10px] font-bold text-slate-500">{u.email}</span>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex flex-col gap-1.5 items-start">
                        <span className={`px-2 py-0.5 rounded-lg text-xs font-bold border ${roleColors[u.role] || 'bg-slate-50 text-slate-700 border-slate-200'}`}>
                          {u.role}
                        </span>
                        <span className="flex items-center gap-1 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                          <Key className="w-3 h-3" /> {u.accessLevel}
                        </span>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <span className="flex items-center gap-1.5 text-xs font-bold text-slate-700 bg-slate-100 border border-slate-200 px-2.5 py-1 rounded-lg w-fit">
                        <Building2 className="w-3.5 h-3.5 text-slate-400" /> {u.branch}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-xs font-bold text-slate-600">{u.lastActive}</span>
                    </td>
                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-black border ${
                        isActive ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-50 text-slate-600 border-slate-200'
                      }`}>
                        {isActive && <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />}
                        {u.status}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-primary-600 bg-primary-50 hover:bg-primary-100 border border-primary-100 rounded-lg">
                          <ShieldCheck className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 text-slate-400 hover:bg-slate-100 rounded-lg">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}