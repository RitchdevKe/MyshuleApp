"use client";

import React from "react";
import { HeartHandshake, AlertTriangle, CheckCircle2, FileWarning } from "lucide-react";

export default function DisciplineWelfareOverview() {
  return (
    <div className="p-8 space-y-8 bg-white/30 backdrop-blur-md rounded-3xl min-h-[600px]">
      
      {/* Enhanced Premium KPI Dashboard */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <div className="p-6 bg-gradient-to-br from-indigo-500/10 to-indigo-600/5 border border-indigo-200/60 rounded-3xl shadow-sm hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 bg-indigo-500/20 text-indigo-700 rounded-xl flex items-center justify-center">
              <FileWarning className="w-5 h-5" />
            </div>
          </div>
          <div className="text-4xl font-black text-indigo-700">28</div>
          <div className="text-sm font-bold text-indigo-600/70 uppercase tracking-wider mt-1">Open Cases</div>
        </div>

        <div className="p-6 bg-gradient-to-br from-slate-100/60 to-white border border-slate-200 rounded-3xl shadow-sm hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 bg-slate-200/50 text-slate-700 rounded-xl flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
          <div className="text-4xl font-black text-slate-800">9</div>
          <div className="text-sm font-bold text-slate-500 uppercase tracking-wider mt-1">New This Week</div>
        </div>

        <div className="p-6 bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 border border-emerald-200/60 rounded-3xl shadow-sm hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 bg-emerald-500/20 text-emerald-700 rounded-xl flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>
          <div className="text-4xl font-black text-emerald-700">17</div>
          <div className="text-sm font-bold text-emerald-600/70 uppercase tracking-wider mt-1">Resolved</div>
        </div>

        <div className="p-6 bg-gradient-to-br from-rose-500/10 to-rose-600/5 border border-rose-200/60 rounded-3xl shadow-sm hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 bg-rose-500/20 text-rose-700 rounded-xl flex items-center justify-center animate-pulse">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
          <div className="text-4xl font-black text-rose-700">3</div>
          <div className="text-sm font-bold text-rose-600/70 uppercase tracking-wider mt-1">Serious Cases</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Recent Cases - Glassmorphic Enhancement */}
        <div className="bg-white/60 border border-white rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow">
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-6">Recent Discipline Cases</h3>
          <div className="space-y-4">
            {[
              { id: "INC-2026-00182", type: "Bullying", student: "Brian Mwangi", status: "Investigation", severity: "High" },
              { id: "INC-2026-00181", type: "Late Arrival", student: "Peter Otieno", status: "Parent Communication", severity: "Low" },
              { id: "INC-2026-00180", type: "Academic Misconduct", student: "John Kamau", status: "Resolved", severity: "Medium" },
            ].map((inc, idx) => (
              <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-white/80 border border-slate-100 rounded-2xl hover:border-indigo-200 transition-colors cursor-pointer group">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-black text-slate-400 group-hover:text-indigo-400 transition-colors">{inc.id}</span>
                    <span className={`w-2 h-2 rounded-full ${inc.severity === 'High' ? 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.6)]' : inc.severity === 'Medium' ? 'bg-amber-500' : 'bg-slate-400'}`}></span>
                  </div>
                  <div className="text-sm font-bold text-slate-700">{inc.student} <span className="text-slate-400 font-medium ml-1">• {inc.type}</span></div>
                </div>
                <span className={`px-3 py-1.5 text-[10px] font-black uppercase tracking-wider border rounded-lg shadow-sm ${
                  inc.status === 'Resolved' 
                    ? 'bg-emerald-50 text-emerald-600 border-emerald-200'
                    : 'bg-indigo-50 text-indigo-600 border-indigo-100'
                }`}>
                  {inc.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Welfare Interventions - Glassmorphic Enhancement */}
        <div className="bg-gradient-to-br from-indigo-50/80 to-purple-50/50 border border-indigo-100/80 rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow">
          <h3 className="text-sm font-black text-indigo-900 uppercase tracking-wider mb-6 flex items-center gap-2">
            <HeartHandshake className="w-4 h-4 text-indigo-600" /> Active Interventions
          </h3>
          <div className="space-y-4">
            {[
              { student: "Brian Mwangi", issue: "Repeated absenteeism", goal: "Attendance above 90%", action: "Mentor Assigned" },
              { student: "Mary Wanjiku", issue: "Academic concern", goal: "Improve Math scores", action: "Counselling Referral" },
            ].map((intv, idx) => (
              <div key={idx} className="p-5 bg-white border border-indigo-100/50 rounded-2xl shadow-sm hover:-translate-y-1 hover:shadow-md transition-all duration-300">
                <div className="flex justify-between items-start mb-3">
                  <span className="font-bold text-slate-800 text-sm">{intv.student}</span>
                  <span className="text-[10px] font-black uppercase tracking-wider bg-indigo-100/50 text-indigo-700 px-2.5 py-1 rounded-md">Review: 2wks</span>
                </div>
                <p className="text-xs text-slate-500 mb-4 bg-slate-50 p-2.5 rounded-lg border border-slate-100 font-medium">Issue: {intv.issue}</p>
                <div className="flex items-center gap-2 text-xs font-bold text-indigo-600 bg-indigo-50/50 p-2 rounded-lg inline-flex border border-indigo-100/50">
                  <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></span>
                  {intv.action}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
