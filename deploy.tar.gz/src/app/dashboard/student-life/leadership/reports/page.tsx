import React from "react";
import { BarChart3, Download, TrendingUp, Users, Vote } from "lucide-react";

export default function LeadershipReportsPage() {
  const metrics = [
    { label: "Overall Election Turnout", value: "78%", trend: "+5%", positive: true },
    { label: "Leadership Diversity", value: "45%", trend: "+12%", positive: true },
    { label: "Initiative Success Rate", value: "92%", trend: "+2%", positive: true },
    { label: "Disciplinary Incidents", value: "3", trend: "-2", positive: true },
  ];

  return (
    <div className="p-6">
      
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-lg font-black text-slate-800">Leadership Analytics</h2>
          <p className="text-sm text-slate-500 font-medium">Data-driven insights into student leadership performance.</p>
        </div>
        
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors shadow-sm">
            <Download className="w-4 h-4" /> Export PDF
          </button>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {metrics.map((metric, idx) => (
          <div key={idx} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{metric.label}</div>
            <div className="flex items-end justify-between">
              <div className="text-3xl font-black text-slate-800">{metric.value}</div>
              <div className={`text-xs font-bold flex items-center gap-1 ${metric.positive ? 'text-green-600' : 'text-rose-600'}`}>
                 <TrendingUp className="w-3.5 h-3.5" /> {metric.trend}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts / Data Area Placeholder */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Election Turnout Trends */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
           <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-slate-800 flex items-center gap-2">
                <Vote className="w-5 h-5 text-indigo-500" /> Election Turnout Trends
              </h3>
              <select className="bg-slate-50 border border-slate-200 text-xs font-bold text-slate-700 rounded-lg px-2 py-1 outline-none">
                 <option>Last 3 Years</option>
                 <option>Last 5 Years</option>
              </select>
           </div>
           <div className="h-48 flex items-end justify-between gap-2 px-4">
              {/* Fake bars */}
              {[60, 65, 78].map((h, i) => (
                <div key={i} className="w-full flex flex-col justify-end items-center gap-2 h-full">
                  <div className="w-full bg-indigo-100 rounded-t-lg relative group h-full flex items-end">
                     <div className="w-full bg-indigo-500 rounded-t-lg transition-all duration-500" style={{ height: `${h}%` }}></div>
                     <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] font-bold py-1 px-2 rounded whitespace-nowrap transition-opacity">
                       {h}%
                     </div>
                  </div>
                  <div className="text-xs font-bold text-slate-500">202{i+4}</div>
                </div>
              ))}
           </div>
        </div>

        {/* Demographics */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm flex flex-col">
           <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-slate-800 flex items-center gap-2">
                <Users className="w-5 h-5 text-emerald-500" /> Grade Representation
              </h3>
           </div>
           <div className="flex-1 flex flex-col justify-center gap-4">
              {[
                { label: "Grade 11", pct: 45, color: "bg-emerald-500" },
                { label: "Grade 10", pct: 35, color: "bg-teal-500" },
                { label: "Grade 9", pct: 20, color: "bg-cyan-500" },
              ].map((item, idx) => (
                <div key={idx}>
                  <div className="flex justify-between text-xs font-bold mb-1">
                    <span className="text-slate-600">{item.label}</span>
                    <span className="text-slate-800">{item.pct}%</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2">
                    <div className={`${item.color} h-2 rounded-full`} style={{ width: `${item.pct}%` }}></div>
                  </div>
                </div>
              ))}
           </div>
        </div>
      </div>

    </div>
  );
}
