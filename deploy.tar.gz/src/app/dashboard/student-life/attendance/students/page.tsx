"use client";
import React, { useState } from "react";
import { Search, User, Phone, Mail, MapPin, Calendar, Clock, AlertTriangle } from "lucide-react";

export default function StudentAttendanceTab() {
  const [search, setSearch] = useState("");
  const [selectedStudent, setSelectedStudent] = useState<boolean>(true);

  return (
    <div className="p-6 h-full flex flex-col md:flex-row gap-6">
      
      {/* Sidebar: Student Search */}
      <div className="w-full md:w-1/3 bg-white/40 backdrop-blur-md rounded-3xl border border-white/60 shadow-sm p-4 flex flex-col min-h-[500px]">
        <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4">Find Student</h3>
        
        <div className="relative mb-6">
          <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search by name or ADM..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-bold focus:outline-none focus:border-indigo-500 shadow-sm"
          />
        </div>

        <div className="flex-1 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
          {/* Mock list of students */}
          {[
            { id: "ADM-2023-001", name: "John Kamau", grade: "Grade 8A", rate: 96, active: true },
            { id: "ADM-2023-087", name: "Brian Mwangi", grade: "Grade 8A", rate: 72, active: false },
            { id: "ADM-2023-112", name: "Peter Otieno", grade: "Grade 8B", rate: 84, active: false },
          ].map(student => (
            <div 
              key={student.id} 
              className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                student.active 
                ? 'bg-white border-indigo-200 shadow-md ring-2 ring-indigo-500/20' 
                : 'bg-white/60 border-transparent hover:bg-white/80 hover:border-slate-200'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black ${student.active ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-100 text-slate-500'}`}>
                  {student.name.charAt(0)}
                </div>
                <div>
                  <div className="font-bold text-slate-800 text-sm">{student.name}</div>
                  <div className="text-[10px] font-bold text-slate-400">{student.id}</div>
                </div>
              </div>
              <div className={`text-xs font-black px-2 py-1 rounded-lg ${
                student.rate > 90 ? 'bg-emerald-50 text-emerald-600' :
                student.rate > 80 ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'
              }`}>
                {student.rate}%
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Content: Student Details */}
      <div className="w-full md:w-2/3 flex flex-col gap-6">
        {selectedStudent ? (
          <>
            <div className="bg-white/60 backdrop-blur-md border border-white rounded-3xl p-6 shadow-sm flex flex-col md:flex-row items-start gap-6">
              <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-indigo-700 text-white rounded-3xl shadow-lg flex items-center justify-center text-4xl font-black">
                J
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-2xl font-black text-slate-800 tracking-tight">John Kamau</h2>
                    <p className="text-sm font-bold text-indigo-600">Grade 8A • ADM-2023-001</p>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-black text-emerald-600">96%</div>
                    <div className="text-[10px] font-black uppercase tracking-wider text-slate-500">Yearly Attendance</div>
                  </div>
                </div>

                <div className="mt-6 flex flex-wrap gap-4">
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-600 bg-slate-100/50 px-3 py-1.5 rounded-xl border border-slate-200/50">
                    <Phone className="w-4 h-4 text-slate-400" /> +254 712 345 678
                  </div>
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-600 bg-slate-100/50 px-3 py-1.5 rounded-xl border border-slate-200/50">
                    <User className="w-4 h-4 text-slate-400" /> Mary Kamau (Mother)
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white/40 backdrop-blur-md rounded-3xl border border-white/60 p-6 shadow-sm">
                <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4">Recent Records</h3>
                <div className="space-y-3">
                  {[
                    { date: "Oct 12 (Today)", status: "Present", color: "text-emerald-600 bg-emerald-50" },
                    { date: "Oct 11 (Yesterday)", status: "Present", color: "text-emerald-600 bg-emerald-50" },
                    { date: "Oct 10 (Monday)", status: "Late", color: "text-amber-600 bg-amber-50" },
                    { date: "Oct 07 (Friday)", status: "Present", color: "text-emerald-600 bg-emerald-50" },
                  ].map((record, i) => (
                    <div key={i} className="flex justify-between items-center p-3 bg-white/80 border border-slate-100 rounded-xl shadow-sm">
                      <span className="text-sm font-bold text-slate-700">{record.date}</span>
                      <span className={`text-xs font-black uppercase tracking-wider px-3 py-1 rounded-lg ${record.color}`}>{record.status}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-amber-50/50 backdrop-blur-md rounded-3xl border border-amber-100 p-6 shadow-sm">
                <h3 className="text-sm font-black text-amber-800 uppercase tracking-wider mb-4 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600" /> Attendance Patterns
                </h3>
                <div className="space-y-4">
                  <div className="p-4 bg-white/80 border border-amber-200 rounded-2xl shadow-sm">
                    <p className="text-sm font-bold text-slate-700">John frequently arrives <span className="text-amber-600">Late</span> on Mondays.</p>
                    <p className="text-xs text-slate-500 mt-2 font-medium">Recorded 4 times in the past 2 months.</p>
                  </div>
                  
                  <button className="w-full py-3 bg-indigo-600 text-white text-sm font-bold rounded-xl shadow-md shadow-indigo-600/20 hover:bg-indigo-700 transition-colors">
                    Send Notice to Parent
                  </button>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-400 bg-white/30 rounded-3xl border border-white/50 backdrop-blur-sm">
            <Search className="w-12 h-12 mb-4 text-slate-300" />
            <p className="font-bold">Select a student to view details.</p>
          </div>
        )}
      </div>

    </div>
  );
}
