"use client";

import React from "react";
import { UserPlus, Plus, Mail, ShieldCheck, FileText, CheckCircle2, ChevronRight, Laptop } from "lucide-react";

export default function OnboardingPage() {
  const newHires = [
    {
      name: "Jessica Taylor",
      role: "School Nurse",
      startDate: "Sep 1, 2026",
      department: "Health & Welfare",
      progress: 75,
      steps: [
        { name: "Offer Accepted", completed: true, icon: CheckCircle2 },
        { name: "Documents", completed: true, icon: FileText },
        { name: "Background Check", completed: true, icon: ShieldCheck },
        { name: "IT Setup", completed: false, icon: Laptop },
      ]
    },
    {
      name: "Brian O'Connor",
      role: "Maintenance Supervisor",
      startDate: "Aug 15, 2026",
      department: "Operations",
      progress: 100,
      steps: [
        { name: "Offer Accepted", completed: true, icon: CheckCircle2 },
        { name: "Documents", completed: true, icon: FileText },
        { name: "Background Check", completed: true, icon: ShieldCheck },
        { name: "IT Setup", completed: true, icon: Laptop },
      ]
    },
    {
      name: "Aisha Mohammed",
      role: "Mathematics Dept Head",
      startDate: "Sep 15, 2026",
      department: "Academics",
      progress: 25,
      steps: [
        { name: "Offer Accepted", completed: true, icon: CheckCircle2 },
        { name: "Documents", completed: false, icon: FileText },
        { name: "Background Check", completed: false, icon: ShieldCheck },
        { name: "IT Setup", completed: false, icon: Laptop },
      ]
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-4">
         <h2 className="text-lg font-black text-slate-800 ml-2">Onboarding Pipelines</h2>
         <div className="flex gap-2">
            <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200/60 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm transition-all shadow-sm">
               <Mail className="w-4 h-4" />
               Send Reminders
            </button>
            <button className="inline-flex items-center gap-2 px-4 py-2 bg-primary-900 hover:bg-primary-800 text-white rounded-xl font-bold text-sm transition-all shadow-md shadow-primary-900/20">
              <Plus className="w-4 h-4" />
              New Hire Flow
            </button>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
         <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-6 text-center">
            <div className="inline-flex p-3 bg-amber-50 text-amber-600 rounded-2xl mb-3">
               <FileText className="w-6 h-6" />
            </div>
            <h3 className="text-2xl font-black text-slate-800">4</h3>
            <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Pending Docs</p>
         </div>
         <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-6 text-center">
            <div className="inline-flex p-3 bg-blue-50 text-blue-600 rounded-2xl mb-3">
               <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-2xl font-black text-slate-800">2</h3>
            <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Awaiting Checks</p>
         </div>
         <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-6 text-center">
            <div className="inline-flex p-3 bg-emerald-50 text-emerald-600 rounded-2xl mb-3">
               <UserPlus className="w-6 h-6" />
            </div>
            <h3 className="text-2xl font-black text-slate-800">1</h3>
            <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Ready to Start</p>
         </div>
      </div>

      <div className="space-y-4">
         {newHires.map((hire, i) => (
            <div key={i} className="bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-sm p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 hover:shadow-md transition-shadow">
               
               <div className="md:w-1/4">
                  <h4 className="text-lg font-black text-slate-800">{hire.name}</h4>
                  <p className="text-sm font-bold text-primary-600">{hire.role}</p>
                  <p className="text-xs font-medium text-slate-500 mt-1">Starts: {hire.startDate}</p>
               </div>

               <div className="md:w-2/4">
                  <div className="flex items-center justify-between mb-2">
                     <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Progress</span>
                     <span className="text-xs font-black text-slate-700">{hire.progress}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden mb-4">
                     <div className={`h-full ${hire.progress === 100 ? 'bg-emerald-500' : 'bg-primary-500'}`} style={{ width: `${hire.progress}%` }}></div>
                  </div>
                  
                  <div className="flex items-center justify-between relative">
                     {/* Connecting Line */}
                     <div className="absolute top-1/2 left-4 right-4 h-0.5 bg-slate-100 -z-10 -translate-y-1/2"></div>
                     
                     {hire.steps.map((step, j) => {
                        const StepIcon = step.icon;
                        return (
                           <div key={j} className="flex flex-col items-center gap-2 bg-white px-2">
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${step.completed ? 'bg-emerald-500 border-emerald-500 text-white' : 'bg-white border-slate-200 text-slate-400'}`}>
                                 <StepIcon className="w-4 h-4" />
                              </div>
                              <span className={`text-[10px] font-bold ${step.completed ? 'text-slate-800' : 'text-slate-400'}`}>{step.name}</span>
                           </div>
                        )
                     })}
                  </div>
               </div>

               <div className="md:w-1/4 flex justify-end">
                  <button className="flex items-center gap-2 px-5 py-2.5 bg-primary-900 hover:bg-primary-800 text-white text-sm font-bold rounded-xl transition-colors shadow-sm shadow-primary-900/20">
                     Manage
                     <ChevronRight className="w-4 h-4" />
                  </button>
               </div>

            </div>
         ))}
      </div>
    </div>
  );
}
