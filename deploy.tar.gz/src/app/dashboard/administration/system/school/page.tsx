"use client";

import React from "react";
import { Building2 } from "lucide-react";

export default function SchoolPage() {
  return (
    <div className="bg-white/80 backdrop-blur-xl border border-slate-200/80 rounded-3xl shadow-sm overflow-hidden p-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Branding Preview */}
        <div className="lg:col-span-1">
          <div className="bg-slate-50 border border-slate-200/60 rounded-2xl p-6 text-center">
            <div className="w-24 h-24 mx-auto bg-primary-900 rounded-2xl shadow-lg shadow-primary-900/30 flex items-center justify-center mb-6">
              <Building2 className="w-12 h-12 text-white" />
            </div>
            <h3 className="font-black text-slate-800 text-lg">Green Valley Academy</h3>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Nairobi, Kenya</p>
            
            <div className="mt-8 pt-6 border-t border-slate-200">
              <h4 className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-3 text-left">Brand Colors</h4>
              <div className="flex gap-2 justify-center">
                <div className="w-8 h-8 rounded-full bg-primary-900 border-2 border-white shadow-sm" title="Primary"></div>
                <div className="w-8 h-8 rounded-full bg-emerald-500 border-2 border-white shadow-sm" title="Secondary"></div>
                <div className="w-8 h-8 rounded-full bg-slate-900 border-2 border-white shadow-sm" title="Accent"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Settings Form */}
        <div className="lg:col-span-2">
          <div className="bg-white border border-slate-200/60 rounded-2xl p-6 shadow-sm">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-6">General Information</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">School Name</label>
                <input type="text" defaultValue="Green Valley Academy" className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-primary-900 focus:ring-1 focus:ring-primary-900" />
              </div>
              <div>
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Registration Number</label>
                <input type="text" defaultValue="REG-2015-0042" className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-primary-900 focus:ring-1 focus:ring-primary-900" />
              </div>
              <div className="md:col-span-2">
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Motto</label>
                <input type="text" defaultValue="Excellence through discipline and hard work" className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-primary-900 focus:ring-1 focus:ring-primary-900" />
              </div>
            </div>

            <hr className="my-8 border-slate-100" />

            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-6">Localization</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Country</label>
                <select className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-primary-900 focus:ring-1 focus:ring-primary-900">
                  <option>Kenya</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Currency</label>
                <select className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-primary-900 focus:ring-1 focus:ring-primary-900">
                  <option>KES (KSh)</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">Timezone</label>
                <select className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm font-bold text-slate-800 focus:outline-none focus:border-primary-900 focus:ring-1 focus:ring-primary-900">
                  <option>Africa/Nairobi</option>
                </select>
              </div>
            </div>
            
            <div className="mt-8 flex justify-end">
              <button className="bg-primary-900 hover:bg-primary-800 text-white font-bold py-2.5 px-6 rounded-xl transition-colors text-sm shadow-sm shadow-primary-900/20">
                Save Changes
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
